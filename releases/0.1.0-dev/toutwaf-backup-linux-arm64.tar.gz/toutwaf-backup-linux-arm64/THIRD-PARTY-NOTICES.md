# Third-party notices

ToutWAF Backup is written in Go and links a small number of well-known libraries, all under the BSD-3-Clause license (or the MIT license for one
file inside klauspost/compress). The binaries are built with `CGO_ENABLED=0`: no C library is linked. The full license texts are in
`third_party/licenses/` and are shipped in every release archive.

| Module | Version | License | Used for | Where |
|---|---|---|---|---|
| `github.com/klauspost/compress` (package `zstd`) | v1.18.0 | BSD-3-Clause | Zstandard compression of chunks, of the file-change cache | `internal/format`, `internal/client` |
| `github.com/klauspost/compress/zstd/internal/xxhash` (part of the above, originally `github.com/cespare/xxhash`) | v1.18.0 | MIT | checksum inside the zstd frames | indirect |
| `golang.org/x/crypto` (`argon2`, `chacha20poly1305`, `chacha20`, `hkdf`, `blake2b`, `internal/poly1305`) | v0.44.0 | BSD-3-Clause | Argon2id passphrase derivation, XChaCha20-Poly1305 authenticated encryption, HKDF subkey derivation | `internal/crypto`, `internal/format` |
| `golang.org/x/sys` (`unix`, `windows`, `windows/svc`, `cpu`) | v0.38.0 | BSD-3-Clause | extended attributes, `SEEK_DATA`/`SEEK_HOLE`, `utimensat`, `mknod` on Linux; Windows service, security descriptors, disk space | `internal/client`, `internal/store`, `internal/cli` |
| `golang.org/x/term` | v0.37.0 | BSD-3-Clause | reading a passphrase without echo | `internal/cli` |
| `github.com/hanwen/go-fuse/v2` (`fs`, `fuse`) | v2.7.2 | BSD-3-Clause | the read-only FUSE mount of a snapshot (`client mount`), Linux builds only; pure Go, no libfuse; `go build -tags nofuse` leaves it out | `internal/mountfs` |
| Go standard library and runtime (`crypto/*`, `net/http` with HTTP/2, `archive/tar`, ...) | go1.24.7 | BSD-3-Clause | everything else: TLS 1.2/1.3, X.509, Ed25519, SHA-2, HTTP/2, SMTP | all |

No database engine is used: the catalogue is plain files and JSON (see `docs/ARCHITECTURE.md`). The web interface has no third-party code (no
framework, no font, no icon set, no external request).

To regenerate this list: `go list -deps ./cmd/toutwaf-backup | grep '\.'` and `go mod graph`. Adding a dependency requires adding it here and its
license file to `third_party/licenses/` in the same commit.

## Test-only tooling (not shipped, not linked)

`tools/smoke.sh` installs `jsdom` (MIT) into a temporary directory to render the web interface in a test; nothing from it is kept in the repository.
