[English](../en/TOUTWAF-LINK.md) | [Français](../fr/TOUTWAF-LINK.md) | **Español** | [Deutsch](../de/TOUTWAF-LINK.md) | [Italiano](../it/TOUTWAF-LINK.md) | [Português](../pt/TOUTWAF-LINK.md) | [Nederlands](../nl/TOUTWAF-LINK.md) | [Русский](../ru/TOUTWAF-LINK.md) | [中文](../zh/TOUTWAF-LINK.md) | [العربية](../ar/TOUTWAF-LINK.md)

# El enlace con ToutWAF

ToutWAF Backup funciona por sí solo. El enlace permite que una consola ToutWAF use un servidor de copias: crea el datastore y los tokens restringidos de cada máquina ToutWAF, programa copias, las comprueba y las restaura, y recibe las alertas de fallo. El contrato está versionado (`toutwaf-backup-link/1`) y documentado en detalle en el `docs/TOUTWAF-LINK.md` en inglés; esta página es la vista del usuario. **La clave se queda en la máquina ToutWAF**: el servidor de copias y el token del enlace no pueden descifrar nada.

## Emparejamiento

En la consola de ToutWAF cree un **token de emparejamiento** de un solo uso («añadir un servidor de copias») y ejecute en el servidor de copias:

```sh
toutwaf-backup link --toutwaf https://waf.example.net --token <pairing token> --url https://backup.example.net:8007
toutwaf-backup link --status
toutwaf-backup link --remove
```

El comando crea un token de enlace con alcance de administrador, lo envía a ToutWAF junto con la dirección del servidor y la huella de su certificado, y registra el emparejamiento; si ToutWAF lo rechaza, el token se revoca de nuevo y no queda nada. El emparejamiento se rechaza cuando el servidor de copias y ToutWAF están en la misma máquina. ToutWAF debe verificar la huella por otra vía la primera vez.

## Lo que la consola de ToutWAF puede hacer entonces

* Crear, para cada máquina ToutWAF, un datastore y un token **escritor** (solo añadir, limitado a un datastore y un espacio de nombres) y un token **lector** opcional para las restauraciones.
* Fijar cuotas y límites de ancho de banda en los tokens que aprovisiona, y leer el uso.
* Leer el estado del servidor (salud, uso, alertas, última copia de cada grupo), listar e inspeccionar instantáneas.
* Iniciar la verificación de una instantánea o de un datastore (sin clave) y seguirla como una tarea.
* Recibir eventos firmados: tarea fallida, verificación fallida, copia atrasada, aviso de cuota. Las restauraciones se ejecutan en la máquina ToutWAF, que tiene la clave.

## Datastore local o S3, a elegir por máquina

La consola elige dónde viven las copias de cada máquina con los campos `backend`, `s3` y `s3_auth` de `POST /api/v1/link/provision`, y también puede programar una copia externa a un bucket con `offsite_s3`. Solo `name` es obligatorio; `backend` es por defecto un datastore local. Las claves de `s3_auth` son de solo escritura: se guardan en el servidor y nunca se devuelven ni se registran.

```json
POST /api/v1/link/provision
{"name":"toutwaf-prod","datastore":"toutwaf","namespace":"toutwaf-prod","append_only":true,"require_encryption":true,
 "backend":"s3",
 "s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-backups","prefix":"toutwaf-prod","addressing":"auto",
       "object_lock_mode":"","object_lock_days":0,"storage_class":""},
 "s3_auth":{"access_key_id":"...","secret_access_key":"...","session_token":"","ca_pem":""},
 "offsite_s3":{"s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-offsite","prefix":"toutwaf-prod"},"s3_auth":{"access_key_id":"...","secret_access_key":"..."},
               "schedule":"every 6h","bandwidth_bps":0,"verify_after":true}}
```

* `backend`: `files` (local, el valor por defecto) o `s3`.
* `s3`: proveedor, región, bucket, prefijo, direccionamiento, modo y días de Object Lock, clase de almacenamiento; `s3_auth`: clave de acceso, clave secreta, token de sesión opcional y CA privada.
* `offsite_s3`: los mismos `s3` y `s3_auth` para el bucket de destino, más `schedule`, `bandwidth_bps` y `verify_after` (verdadero por defecto); crea una tarea `offsite-<datastore>`.
* La respuesta incluye `backend`, `s3` (lo que se muestra, nunca un secreto) y `offsite_job`. Un bucket erróneo o unas claves incorrectas dan un `400` y no se crea nada; pedir otro backend distinto del de un datastore existente con el mismo nombre da un `409`. `POST /api/v1/storage/test` permite a la consola probar antes un bucket, y `POST /api/v1/datastores/import-s3` reconstruye un datastore desde un bucket tras una pérdida total.

## Estado, con franqueza

El emparejamiento, el aprovisionamiento, el estado, los eventos firmados y los campos S3 se prueban de extremo a extremo contra una consola ToutWAF simulada. **Sin probar: una consola ToutWAF real**, que aún no implementa su parte; y S3 solo contra un simulado en memoria, no un proveedor real.
