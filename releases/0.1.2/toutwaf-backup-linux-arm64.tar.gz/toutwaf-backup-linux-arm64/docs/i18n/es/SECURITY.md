[English](../en/SECURITY.md) | [Français](../fr/SECURITY.md) | **Español** | [Deutsch](../de/SECURITY.md) | [Italiano](../it/SECURITY.md) | [Português](../pt/SECURITY.md) | [Nederlands](../nl/SECURITY.md) | [Русский](../ru/SECURITY.md) | [中文](../zh/SECURITY.md) | [العربية](../ar/SECURITY.md)

# Modelo de seguridad (resumen)

Esto es un resumen. El modelo de amenazas completo, la criptografía y el formato del repositorio están en la documentación en inglés (`docs/SECURITY.md`, `docs/ARCHITECTURE.md`). **Ningún tercero ha auditado este software.**

## Lo que el servidor puede y no puede ver

| El servidor puede ver | El servidor no puede ver |
|---|---|
| que existe un cliente con un token válido, su dirección, cuándo se conecta | la clave, la frase de contraseña, el contenido de cualquier archivo |
| el nombre del grupo de copia (por ejemplo `host/web1`), el espacio de nombres, las fechas de las instantáneas, los tamaños totales y el número de archivos, el tamaño y el número de fragmentos almacenados | los nombres de archivo, la estructura de directorios, el tamaño de cada archivo, los propietarios, los permisos, qué fragmento pertenece a qué archivo, si dos archivos comparten contenido |
| que dos instantáneas comparten fragmentos (misma clave) | nada que le permita comprobar una suposición sobre sus datos en claro: los ids de fragmento llevan clave (HMAC) y los límites de fragmento también |

El tamaño y los tiempos se filtran por diseño: un observador del servidor o de la red sabe cuánto cambió y cuándo. Con `--no-encrypt` el servidor puede leerlo todo; un datastore puede configurarse con `require_encryption` para rechazar datos en claro.

## Modelo de amenazas

| Adversario | Qué obtiene y por qué |
|---|---|
| Observador de red o intermediario | solo tamaños y tiempos: TLS, y el cliente fija la huella del certificado del servidor; otro certificado se rechaza antes de enviar un solo byte |
| Disco de copias robado, o acceso de lectura al servidor | texto cifrado, nombres de grupo, tamaños y tiempos: la clave nunca llega al servidor |
| Compromiso del servidor con acceso de escritura | puede borrar u ocultar copias (disponibilidad); no puede falsificar, alterar ni empalmar instantáneas sin ser detectado: cada fragmento se autentica con su id y cada manifiesto se sella con la clave |
| Cliente comprometido | puede subir basura, pero no puede borrar ni sobrescribir copias existentes si su token es de escritura (o el datastore es de solo añadir); un cliente que tiene la clave puede leer sus propias copias |
| Token de administración comprometido | puede cambiar ajustes y tokens, pero no puede borrar en un datastore de solo añadir, desactivar el modo solo añadir ni acortar el periodo de inmutabilidad: esos ajustes solo cambian en la propia máquina del servidor; cada acción queda en el registro de auditoría encadenado por hash |
| Ransomware, o root en la máquina del servidor | el ransomware en un cliente cifra los datos vivos, no las copias; root en el servidor puede borrarlo todo (disponibilidad): mantenga una copia externa (un segundo servidor, un disco o un bucket S3 con Object Lock) para tener garantías frente al ransomware |

**No cubierto:** un servidor que oculta sus instantáneas más recientes (compare `client snapshots` con sus propios registros, o alerte sobre copias atrasadas); la pérdida de la clave; un cliente malicioso que habla con un datastore que no exige cifrado; un escritor que llena el disco (fije una cuota); el acceso físico a la máquina que guarda a la vez el archivo de clave y la frase de contraseña.

## Criptografía

De frase de contraseña a clave: **Argon2id**. Cifrado autenticado: **XChaCha20-Poly1305** (nonce aleatorio de 192 bits). Subclaves: **HKDF-SHA-256**. Ids de fragmento: HMAC-SHA-256 con una subclave (SHA-256 si no hay cifrado). TLS 1.2 o posterior con un certificado ECDSA P-256 autofirmado; las firmas de versiones son Ed25519. Nada es de fabricación propia; el formato está descrito para que pueda auditarse.

## Gestión de claves

* `client key create` crea el archivo de clave y muestra la **clave en papel**. El archivo de clave se puede copiar sin riesgo (no revela nada sin la frase de contraseña); la clave en papel es la clave maestra en claro: imprímala, guárdela en una caja fuerte, nunca en la misma máquina que los datos.
* `client key change-passphrase` vuelve a envolver la misma clave maestra (las copias antiguas del archivo de clave aún se abren con la frase antigua: destrúyalas). `client key escrow` escribe la clave protegida con una segunda frase de contraseña distinta para una persona de confianza.
* Archivo de clave y frase de contraseña perdidos pero clave en papel conservada: `client key import-paper` reconstruye un archivo de clave. **Perdidos los tres: las copias son ilegibles, por diseño.**
* Para sustituir la clave maestra (tras una sospecha de compromiso), cree una clave nueva y haga copias nuevas: no se deduplican con las antiguas, que siguen siendo legibles con la clave antigua hasta que se depuren. Pruebe la recuperación, no solo la copia: el simulacro está en [RESTORE.md](RESTORE.md).

## Tokens de API y roles

| Rol | Puede / no puede |
|---|---|
| **admin** | todo, incluidos tokens, datastores, tareas y ajustes; no puede desactivar el modo solo añadir ni acortar el periodo de inmutabilidad (solo en la máquina del servidor) |
| **writer** | comprueba y sube fragmentos, confirma instantáneas, lista; no puede leer fragmentos, borrar ni depurar (salvo autorización, y entonces solo sus propias instantáneas, nunca en solo añadir) |
| **reader** | lista, lee fragmentos e índices, explora y descarga instantáneas sin cifrar; no puede escribir |
| **audit** | lee los metadatos de las instantáneas, el registro de auditoría, las métricas, las alertas y el estado de las tareas; no puede leer los datos de los fragmentos ni cambiar nada |

## Operación

* **El servidor nunca se ejecuta en la máquina que protege, ni junto a ToutWAF.** Los instaladores y `server run` lo rechazan, y el contrato de emparejamiento lleva un hash del identificador de máquina para que ToutWAF y el servidor rechacen un emparejamiento en la misma máquina. Existe una excepción de laboratorio; no debe usarse en producción.
* Las cuotas (límites de bytes estrictos y flexibles, número de instantáneas y de fragmentos, límites de ancho de banda) por token y por espacio de nombres son una herramienta de equidad, no una frontera de seguridad frente a un token que tiene su propia clave de cliente.
* Las credenciales S3 viven en el entorno del servidor, en un archivo que solo el servicio puede leer, o (escritas en la interfaz o enviadas por la consola de ToutWAF) en `<estado>/secrets/s3/` con modo 0600. Son de solo escritura: nunca en un archivo de configuración, un espejo en el bucket, una respuesta de la API, una página, el registro de auditoría, una línea de registro ni un argumento de línea de comandos. El directorio de estado es, por tanto, un secreto. Con Object Lock en modo Cumplimiento y un datastore de solo añadir, ni siquiera una clave S3 robada puede borrar fragmentos antes de que termine su retención. Véase [S3.md](S3.md).
* El servicio se ejecuta como usuario sin privilegios con una unidad systemd reforzada; el puerto se abre solo a sus clientes. La limitación por dirección y el bloqueo tras fallos de autenticación están activos por defecto; el registro de auditoría está encadenado por hash (`server audit-verify` detecta cualquier edición). La interfaz web aplica una Content-Security-Policy estricta, sin script en línea ni origen externo.

## Informar de una vulnerabilidad

Informe de una vulnerabilidad en privado al propietario del proyecto ToutWAF (véase el contacto del repositorio); no abra una incidencia pública.
