[English](../en/RESTORE.md) | [Français](../fr/RESTORE.md) | **Español** | [Deutsch](../de/RESTORE.md) | [Italiano](../it/RESTORE.md) | [Português](../pt/RESTORE.md) | [Nederlands](../nl/RESTORE.md) | [Русский](../ru/RESTORE.md) | [中文](../zh/RESTORE.md) | [العربية](../ar/RESTORE.md)

# Restauración y procedimiento de recuperación ante desastres

Una copia que nunca ha restaurado es solo una esperanza. Lea esto una vez **antes** de necesitarlo y haga el simulacro final al menos cada trimestre.

## Qué debe tener y dónde guardarlo

| Elemento | Por qué y dónde guardarlo |
|---|---|
| El **archivo de clave** y su **frase de contraseña** | descifran todo; guárdelos en un gestor de contraseñas o una caja fuerte, no solo en la máquina de la que se hace copia |
| La **clave en papel** impresa por `client key create` | reconstruye el archivo de clave si se pierde el archivo o la frase de contraseña; imprímalo y guárdelo en una caja fuerte |
| La **huella del servidor** y un token *lector* (o admin) | para llegar al servidor; un token lector puede volver a crearse en el servidor |
| Esta página y el binario `toutwaf-backup` de su sistema | la herramienta; guarde una copia en una memoria USB, es un único archivo estático |

Si no tiene ni el archivo de clave, ni la frase de contraseña, ni la clave en papel, **nadie puede recuperar los datos.** Ese es el precio de un servidor que nunca tiene una clave.

## Restaurar un archivo o un directorio (a diario)

```sh
toutwaf-backup client snapshots --type host --id web1                         # find the snapshot
toutwaf-backup client ls host/web1/latest etc/nginx                            # look inside, no restore needed
toutwaf-backup client find host/web1/latest '*.conf'
toutwaf-backup client restore host/web1/20261023T023000Z --path etc/nginx --target /tmp/restore --verify
toutwaf-backup client cat host/web1/latest etc/hostname                        # one file to standard output
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop                 # a database dump straight into its importer
```

Las rutas son las que muestra `ls` (sin barra inicial); una ruta de origen `/etc/nginx` se restaura en `<destino>/etc/nginx`. Los archivos existentes **nunca se sobrescriben** salvo que indique `--overwrite`. `client browse` abre una página web local (127.0.0.1) para explorar y descargar.

## Restaurar una máquina entera

La herramienta copia **archivos e información del sistema, no imágenes de disco**: no recrea particiones, cargadores de arranque ni el sistema operativo. Reconstruya primero el sistema base y luego restaure los datos.

1. Instale el sistema operativo (la misma distribución si puede) y configure el nombre del host y la red.
2. Instale el cliente (`install.sh --role client`, o copie el binario).
3. Recree la conexión y la clave: con solo la clave en papel use `client key import-paper` (comprueba cada línea y pide una frase de contraseña nueva), y luego `client init`.
4. Mire cómo era el host (`.twb-meta/system.json`: nombre del host, kernel, montajes, paquetes instalados).
5. Restaure primero en un directorio de pruebas, o directamente sobre la raíz; ejecute como root para restaurar propietarios, atributos extendidos, ACL, nodos de dispositivo y FIFO.
6. Reinstale el cargador de arranque y los paquetes si la raíz es nueva, reinicie, compruebe los servicios y haga una copia nueva: se deduplica con las anteriores.

```sh
toutwaf-backup client key import-paper --keyfile /root/key.json < paper.txt        # only if the key file or the passphrase is lost
toutwaf-backup client init --server https://backup.example.net:8007 --fingerprint <hex> --token <reader token> --datastore main --namespace hosts/web1 --keyfile /root/key.json
toutwaf-backup client cat host/web1/latest .twb-meta/system.json                   # what the host was (when saved with --system-info)
toutwaf-backup client restore host/web1/latest --target /mnt/newroot --verify      # a new root mounted at /mnt/newroot
toutwaf-backup client restore host/web1/latest --target / --overwrite --verify     # in place, replaces files
```

## Se ha perdido el archivo de clave o la frase de contraseña

* Frase de contraseña perdida, **clave en papel conservada**: `client key import-paper --keyfile new.json < paper.txt`, defina una frase nueva y actualice el perfil.
* Archivo de clave perdido, frase de contraseña conservada: use la clave en papel como arriba. Sin ella no se puede hacer nada. Una **copia de custodia** (`client key escrow`) se abre con su propia frase de contraseña.
* Después, cambie la frase de contraseña con `client key change-passphrase`. **Si se pierden las tres cosas, las copias son ilegibles, por diseño.**

## Se ha perdido el servidor de copias

1. Recupere los datos: el disco, una copia restaurada o la **copia externa** que una tarea de sincronización envió a un segundo servidor o disco. El directorio del datastore se describe a sí mismo.
2. En una máquina nueva: `install.sh --role server --no-init`, luego `toutwaf-backup server init --state /var/lib/toutwaf-backup --listen :8007 --external-url https://... --datastore main=/ruta/al/datastore/recuperado` (un directorio existente se adopta, no se reescribe nada). Anote el nuevo token de administración y la **nueva huella del certificado**.
3. Cree tokens para sus clientes (`server token create`) y vuelva a ejecutar `client init` con la huella nueva.
4. Compruebe con `toutwaf-backup server verify --datastore main --scrub`, restaure un archivo con un cliente y cree de nuevo la tarea de copia externa.

## Se han perdido el servidor y su disco, y la copia está en un bucket S3

Si se ejecutó una tarea *Copia externa a S3* (o el propio datastore vive en un bucket), el bucket contiene todo salvo la clave: los fragmentos y, en `meta/`, los ajustes y la lista de instantáneas. Necesita el bucket, el prefijo de la copia (`offsite-<id de la tarea>` salvo que haya elegido otro), claves S3 que puedan leerlo y su archivo de clave o su **clave en papel**. En el servidor nuevo, en la interfaz web (Datastores, *Crear un datastore*, **Reanudar desde S3**) o en la línea de comandos:

```sh
printf '{"access_key_id":"...","secret_access_key":"..."}' | toutwaf-backup datastore import-s3 main \
  --s3-credentials-stdin --s3-bucket my-backups --s3-provider wasabi --s3-region eu-central-1 --s3-prefix offsite-main
```

Un prefijo equivocado o vacío se rechaza («el bucket no contiene ningún espejo de metadatos») y no se crea nada. Después cree los tokens, vuelva a ejecutar `client init`, restaure con `client restore` y cree de nuevo la tarea de copia externa (adopta la copia que ya está en el bucket si indica el mismo bucket y prefijo). [S3.md](S3.md) describe las tres funciones de S3.

## El datastore está dañado (corrupción silenciosa, fallo parcial del disco)

```sh
toutwaf-backup server verify --datastore main --scrub     # reads every snapshot and chunk file; damaged chunks are moved aside, never deleted
toutwaf-backup client verify host/web1/latest --read-data  # needs the key: proves every chunk decrypts and matches its id
```

Un fragmento **ausente o dañado** hace que fallen en la verificación las instantáneas que lo usan. La siguiente copia de los mismos datos vuelve a subir el fragmento y el datastore se repara solo; las instantáneas antiguas que necesitaban un fragmento que los datos actuales ya no contienen siguen dañadas: restáurelas desde la réplica (una sincronización `pull` copia solo lo que falta) o acepte la pérdida de esos archivos. La restauración le dice exactamente qué archivos no pudo restaurar (código de salida 1); el resto se restaura.

## El simulacro (hágalo y anote la fecha)

1. En una máquina de repuesto (o un directorio temporal) con **solo** los secretos documentados: archivo de clave o clave en papel, frase de contraseña, token, huella.
2. `client restore <grupo importante>/latest --target /tmp/drill --verify`, abra algunos archivos; para una base de datos, importe el volcado en una instancia de prueba.
3. `client verify <instantánea> --read-data` demuestra que cada fragmento se descifra y coincide con su id.
4. Cronométrelo (una restauración a 70 MiB/s tarda unas 4 horas por terabyte), anote todo lo que le haya sorprendido y corrija este procedimiento.
