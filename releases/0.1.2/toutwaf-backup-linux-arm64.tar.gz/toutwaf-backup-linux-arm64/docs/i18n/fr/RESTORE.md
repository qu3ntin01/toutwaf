[English](../en/RESTORE.md) | **Français** | [Español](../es/RESTORE.md) | [Deutsch](../de/RESTORE.md) | [Italiano](../it/RESTORE.md) | [Português](../pt/RESTORE.md) | [Nederlands](../nl/RESTORE.md) | [Русский](../ru/RESTORE.md) | [中文](../zh/RESTORE.md) | [العربية](../ar/RESTORE.md)

# Restauration et procédure de reprise après sinistre

Une sauvegarde que vous n'avez jamais restaurée n'est qu'un espoir. Lisez ceci une fois **avant** d'en avoir besoin, et faites l'exercice final au moins chaque trimestre.

## Ce qu'il faut avoir, et où le garder

| Élément | Pourquoi, et où le garder |
|---|---|
| Le **fichier de clé** et sa **phrase secrète** | déchiffrent tout ; gardez-les dans un gestionnaire de mots de passe ou un coffre, pas seulement sur la machine sauvegardée |
| La **clé papier** imprimée par `client key create` | reconstruit le fichier de clé si le fichier ou la phrase secrète est perdu ; imprimez-le et gardez-le dans un coffre |
| L'**empreinte du serveur** et un jeton *lecteur* (ou admin) | pour joindre le serveur ; un jeton lecteur peut être recréé sur le serveur |
| Cette page et le binaire `toutwaf-backup` de votre système | l'outil ; gardez-en une copie sur une clé USB, c'est un seul fichier statique |

Si vous n'avez ni le fichier de clé, ni la phrase secrète, ni la clé papier, **personne ne peut récupérer les données.** C'est le prix d'un serveur qui ne détient jamais de clé.

## Restaurer un fichier ou un répertoire (au quotidien)

```sh
toutwaf-backup client snapshots --type host --id web1                         # find the snapshot
toutwaf-backup client ls host/web1/latest etc/nginx                            # look inside, no restore needed
toutwaf-backup client find host/web1/latest '*.conf'
toutwaf-backup client restore host/web1/20261023T023000Z --path etc/nginx --target /tmp/restore --verify
toutwaf-backup client cat host/web1/latest etc/hostname                        # one file to standard output
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop                 # a database dump straight into its importer
```

Les chemins sont ceux affichés par `ls` (sans barre oblique initiale) ; un chemin source `/etc/nginx` est restauré dans `<cible>/etc/nginx`. Les fichiers existants ne sont **jamais écrasés** sans `--overwrite`. `client browse` ouvre une page web locale (127.0.0.1) pour parcourir et télécharger.

## Restaurer une machine entière

L'outil sauvegarde les **fichiers et les informations système, pas des images disque** : il ne recrée ni les partitions, ni les chargeurs de démarrage, ni le système d'exploitation. Reconstruisez d'abord le système de base, puis restaurez les données.

1. Installez le système d'exploitation (la même distribution si possible) et réglez le nom d'hôte et le réseau.
2. Installez le client (`install.sh --role client`, ou copiez le binaire).
3. Recréez la connexion et la clé : avec la seule clé papier, utilisez `client key import-paper` (elle vérifie chaque ligne et demande une nouvelle phrase secrète), puis `client init`.
4. Regardez ce qu'était l'hôte (`.twb-meta/system.json` : nom d'hôte, noyau, montages, paquets installés).
5. Restaurez d'abord dans un répertoire de travail, ou directement sur la racine ; exécutez en root pour restaurer propriétaires, attributs étendus, ACL, fichiers spéciaux et FIFO.
6. Réinstallez le chargeur de démarrage et les paquets si la racine est neuve, redémarrez, vérifiez les services, puis lancez une nouvelle sauvegarde : elle se déduplique avec les anciennes.

```sh
toutwaf-backup client key import-paper --keyfile /root/key.json < paper.txt        # only if the key file or the passphrase is lost
toutwaf-backup client init --server https://backup.example.net:8007 --fingerprint <hex> --token <reader token> --datastore main --namespace hosts/web1 --keyfile /root/key.json
toutwaf-backup client cat host/web1/latest .twb-meta/system.json                   # what the host was (when saved with --system-info)
toutwaf-backup client restore host/web1/latest --target /mnt/newroot --verify      # a new root mounted at /mnt/newroot
toutwaf-backup client restore host/web1/latest --target / --overwrite --verify     # in place, replaces files
```

## Le fichier de clé ou la phrase secrète est perdu

* Phrase secrète perdue, **clé papier conservée** : `client key import-paper --keyfile new.json < paper.txt`, définissez une nouvelle phrase secrète, mettez le profil à jour.
* Fichier de clé perdu, phrase secrète conservée : utilisez la clé papier comme ci-dessus. Sans elle, rien n'est possible. Une **copie de séquestre** (`client key escrow`) s'ouvre avec sa propre phrase secrète.
* Ensuite, changez la phrase secrète avec `client key change-passphrase`. **Si les trois sont perdus, les sauvegardes sont illisibles, par conception.**

## Le serveur de sauvegarde est perdu

1. Récupérez les données : le disque, une copie restaurée, ou la **copie hors site** qu'une tâche de synchronisation a poussée vers un second serveur ou disque. Le répertoire du datastore est autodescriptif.
2. Sur une nouvelle machine : `install.sh --role server --no-init`, puis `toutwaf-backup server init --state /var/lib/toutwaf-backup --listen :8007 --external-url https://... --datastore main=/chemin/vers/le/datastore/recupere` (un répertoire existant est adopté, rien n'est réécrit). Notez le nouveau jeton d'administration et la **nouvelle empreinte du certificat**.
3. Créez des jetons pour vos clients (`server token create`) et relancez `client init` avec la nouvelle empreinte.
4. Vérifiez avec `toutwaf-backup server verify --datastore main --scrub`, restaurez un fichier avec un client, et recréez la tâche de copie hors site.

## Le serveur et son disque sont perdus, et la copie est dans un bucket S3

Si une tâche *Copie hors site vers S3* a tourné (ou si le datastore vit lui-même dans un bucket), le bucket contient tout sauf la clé : les fragments, et dans `meta/` les paramètres et la liste des instantanés. Il vous faut le bucket, le préfixe de la copie (`offsite-<id de la tâche>` sauf choix contraire), des clés S3 qui peuvent le lire, et votre fichier de clé ou votre **clé papier**. Sur le nouveau serveur, dans l'interface web (Datastores, *Créer un datastore*, **Reprendre depuis S3**) ou en ligne de commande :

```sh
printf '{"access_key_id":"...","secret_access_key":"..."}' | toutwaf-backup datastore import-s3 main \
  --s3-credentials-stdin --s3-bucket my-backups --s3-provider wasabi --s3-region eu-central-1 --s3-prefix offsite-main
```

Un préfixe erroné ou vide est refusé (« le bucket ne contient aucun miroir de métadonnées ») et rien n'est créé. Créez ensuite les jetons, relancez `client init`, restaurez avec `client restore`, et recréez la tâche de copie hors site (elle reprend la copie déjà présente dans le bucket si vous donnez le même bucket et le même préfixe). [S3.md](S3.md) décrit les trois fonctions S3.

## Le datastore est endommagé (corruption silencieuse, panne partielle de disque)

```sh
toutwaf-backup server verify --datastore main --scrub     # reads every snapshot and chunk file; damaged chunks are moved aside, never deleted
toutwaf-backup client verify host/web1/latest --read-data  # needs the key: proves every chunk decrypts and matches its id
```

Un fragment **manquant ou endommagé** fait échouer la vérification des instantanés qui l'utilisent. La prochaine sauvegarde des mêmes données renvoie le fragment et le datastore se répare ; les instantanés plus anciens qui avaient besoin d'un fragment que les données actuelles ne contiennent plus restent endommagés : restaurez-les depuis la réplique (une synchronisation `pull` ne copie que ce qui manque) ou acceptez la perte pour ces fichiers. La restauration indique exactement quels fichiers n'ont pas pu être restaurés (code de sortie 1) ; le reste est restauré.

## L'exercice (faites-le, puis notez la date)

1. Sur une machine de rechange (ou un répertoire temporaire) avec **uniquement** les secrets documentés : fichier de clé ou clé papier, phrase secrète, jeton, empreinte.
2. `client restore <groupe important>/latest --target /tmp/drill --verify`, ouvrez quelques fichiers ; pour une base de données, importez le dump dans une instance de test.
3. `client verify <instantané> --read-data` prouve que chaque fragment se déchiffre et correspond à son identifiant.
4. Chronométrez (une restauration à 70 Mio/s prend environ 4 heures par téraoctet), notez tout ce qui vous a surpris, et corrigez cette procédure.
