[English](../en/SECURITY.md) | **Français** | [Español](../es/SECURITY.md) | [Deutsch](../de/SECURITY.md) | [Italiano](../it/SECURITY.md) | [Português](../pt/SECURITY.md) | [Nederlands](../nl/SECURITY.md) | [Русский](../ru/SECURITY.md) | [中文](../zh/SECURITY.md) | [العربية](../ar/SECURITY.md)

# Modèle de sécurité (résumé)

Ceci est un résumé. Le modèle de menaces complet, la cryptographie et le format du dépôt sont dans la documentation anglaise (`docs/SECURITY.md`, `docs/ARCHITECTURE.md`). **Aucun tiers n'a audité ce logiciel.**

## Ce que le serveur peut et ne peut pas voir

| Le serveur peut voir | Le serveur ne peut pas voir |
|---|---|
| qu'un client muni d'un jeton valide existe, son adresse, quand il se connecte | la clé, la phrase secrète, le contenu de n'importe quel fichier |
| le nom du groupe de sauvegarde (par exemple `host/web1`), l'espace de noms, les dates des instantanés, les tailles totales et le nombre de fichiers, la taille et le nombre des fragments stockés | les noms de fichiers, l'arborescence, la taille de chaque fichier, les propriétaires, les permissions, quel fragment appartient à quel fichier, si deux fichiers partagent du contenu |
| que deux instantanés partagent des fragments (même clé) | rien qui lui permette de tester une hypothèse sur vos données en clair : les identifiants de fragments sont à clé (HMAC), les frontières de fragments aussi |

La taille et le calendrier fuient par conception : un observateur du serveur ou du réseau apprend combien de données ont changé et quand. Avec `--no-encrypt`, tout est lisible par le serveur ; un datastore peut être réglé sur `require_encryption` pour refuser le texte en clair.

## Modèle de menaces

| Adversaire | Ce qu'il obtient, et pourquoi |
|---|---|
| Observateur réseau ou homme du milieu | seulement les tailles et le calendrier : TLS, et le client épingle l'empreinte du certificat du serveur ; un autre certificat est refusé avant l'envoi du moindre octet |
| Disque de sauvegarde volé, ou accès en lecture au serveur | du texte chiffré, des noms de groupes, des tailles et du calendrier : la clé n'atteint jamais le serveur |
| Compromission du serveur avec accès en écriture | peut supprimer ou retenir des sauvegardes (disponibilité) ; ne peut pas falsifier, modifier ou raccorder des instantanés sans être détecté : chaque fragment est authentifié avec son identifiant et chaque manifeste est scellé avec la clé |
| Client compromis | peut envoyer du déchet, mais ne peut ni supprimer ni écraser les sauvegardes existantes si son jeton est un jeton d'écriture (ou si le datastore est en ajout seul) ; un client qui détient la clé peut lire ses propres sauvegardes |
| Jeton d'administration compromis | peut modifier les paramètres et les jetons, mais ne peut ni supprimer dans un datastore en ajout seul, ni désactiver l'ajout seul, ni raccourcir la période d'immuabilité : ces réglages ne changent que sur la machine du serveur elle-même ; chaque action figure dans le journal d'audit chaîné par hachage |
| Rançongiciel, ou root sur la machine du serveur | un rançongiciel sur un client chiffre les données vivantes, pas les sauvegardes ; root sur le serveur peut tout supprimer (disponibilité) : gardez une copie hors site (second serveur, disque ou bucket S3 avec Object Lock) pour des garanties contre les rançongiciels |

**Non couvert :** un serveur qui cache vos instantanés les plus récents (comparez `client snapshots` avec vos propres relevés, ou alertez sur les sauvegardes en retard) ; la perte de la clé ; un client malveillant qui parle à un datastore n'exigeant pas le chiffrement ; un écrivain qui remplit le disque (fixez un quota) ; l'accès physique à la machine qui détient à la fois le fichier de clé et la phrase secrète.

## Cryptographie

Phrase secrète vers clé : **Argon2id**. Chiffrement authentifié : **XChaCha20-Poly1305** (nonce aléatoire de 192 bits). Sous-clés : **HKDF-SHA-256**. Identifiants de fragments : HMAC-SHA-256 sous une sous-clé (SHA-256 sans chiffrement). TLS 1.2 ou plus récent avec un certificat ECDSA P-256 autosigné ; les signatures de versions sont en Ed25519. Rien n'est fait maison ; le format est décrit pour pouvoir être audité.

## Gestion des clés

* `client key create` crée le fichier de clé et affiche la **clé papier**. Le fichier de clé peut être copié sans risque (il ne révèle rien sans la phrase secrète) ; la clé papier est la clé maîtresse en clair : imprimez-la, mettez-la dans un coffre, jamais sur la même machine que les données.
* `client key change-passphrase` ré-enveloppe la même clé maîtresse (les anciennes copies du fichier de clé s'ouvrent encore avec l'ancienne phrase secrète : détruisez-les). `client key escrow` écrit la clé protégée par une seconde phrase secrète distincte pour un tiers de confiance.
* Fichier de clé et phrase secrète perdus mais clé papier conservée : `client key import-paper` reconstruit un fichier de clé. **Les trois perdus : les sauvegardes sont illisibles, par conception.**
* Pour remplacer la clé maîtresse (après une compromission présumée), créez une nouvelle clé et faites de nouvelles sauvegardes : elles ne se dédupliquent pas avec les anciennes, qui restent lisibles avec l'ancienne clé jusqu'à leur élagage. Testez la reprise, pas seulement la sauvegarde : l'exercice est dans [RESTORE.md](RESTORE.md).

## Jetons d'API et rôles

| Rôle | Peut / ne peut pas |
|---|---|
| **admin** | tout, y compris jetons, datastores, tâches et paramètres ; ne peut pas désactiver l'ajout seul ni raccourcir la période d'immuabilité (machine du serveur uniquement) |
| **writer** | vérifie et envoie des fragments, valide des instantanés, liste ; ne peut ni lire des fragments, ni supprimer, ni élaguer (sauf autorisation, et alors seulement ses propres instantanés, jamais en ajout seul) |
| **reader** | liste, lit fragments et index, parcourt et télécharge les instantanés non chiffrés ; ne peut pas écrire |
| **audit** | lit les métadonnées des instantanés, le journal d'audit, les métriques, les alertes et l'état des tâches ; ne peut ni lire les données des fragments ni rien modifier |

## Exploitation

* **Le serveur ne tourne jamais sur la machine qu'il protège, ni à côté de ToutWAF.** Les installeurs et `server run` le refusent, et le contrat d'appairage porte une empreinte de l'identifiant de machine pour que ToutWAF et le serveur refusent tous deux un appairage sur la même machine. Une dérogation de laboratoire existe ; elle ne doit pas servir en production.
* Les quotas (limites d'octets dures et douces, nombre d'instantanés et de fragments, plafonds de débit) par jeton et par espace de noms sont un outil d'équité, pas une frontière de sécurité face à un jeton qui détient sa propre clé de client.
* Les identifiants S3 vivent dans l'environnement du serveur, dans un fichier que seul le service peut lire, ou (saisis dans l'interface ou envoyés par la console ToutWAF) dans `<état>/secrets/s3/` avec le mode 0600. Ils sont en écriture seule : jamais dans un fichier de configuration, un miroir dans le bucket, une réponse d'API, une page, le journal d'audit, une ligne de journal ni un argument de ligne de commande. Le répertoire d'état est donc un secret. Avec Object Lock en mode Conformité et un datastore en ajout seul, même une clé S3 volée ne peut pas supprimer des fragments avant la fin de leur rétention. Voir [S3.md](S3.md).
* Le service tourne sous un utilisateur non privilégié avec une unité systemd durcie ; le port n'est ouvert qu'à vos clients. La limitation de débit par adresse et le verrouillage après échecs d'authentification sont actifs par défaut ; le journal d'audit est chaîné par hachage (`server audit-verify` détecte toute modification). L'interface web applique une Content-Security-Policy stricte, sans script en ligne ni origine externe.

## Signaler une vulnérabilité

Signalez une vulnérabilité en privé au propriétaire du projet ToutWAF (voir le contact du dépôt) ; n'ouvrez pas de ticket public.
