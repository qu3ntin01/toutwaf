[English](../en/TOUTWAF-LINK.md) | **Français** | [Español](../es/TOUTWAF-LINK.md) | [Deutsch](../de/TOUTWAF-LINK.md) | [Italiano](../it/TOUTWAF-LINK.md) | [Português](../pt/TOUTWAF-LINK.md) | [Nederlands](../nl/TOUTWAF-LINK.md) | [Русский](../ru/TOUTWAF-LINK.md) | [中文](../zh/TOUTWAF-LINK.md) | [العربية](../ar/TOUTWAF-LINK.md)

# La liaison avec ToutWAF

ToutWAF Backup fonctionne seul. La liaison permet à une console ToutWAF d'utiliser un serveur de sauvegarde : elle crée le datastore et les jetons restreints de chaque machine ToutWAF, planifie les sauvegardes, les vérifie et les restaure, et reçoit les alertes d'échec. Le contrat est versionné (`toutwaf-backup-link/1`) et documenté en détail dans le `docs/TOUTWAF-LINK.md` anglais ; cette page est la vue de l'utilisateur. **La clé reste sur la machine ToutWAF** : le serveur de sauvegarde et le jeton de liaison ne peuvent rien déchiffrer.

## Appairage

Dans la console ToutWAF, créez un **jeton d'appairage** à usage unique (« ajouter un serveur de sauvegarde »), puis lancez sur le serveur de sauvegarde :

```sh
toutwaf-backup link --toutwaf https://waf.example.net --token <pairing token> --url https://backup.example.net:8007
toutwaf-backup link --status
toutwaf-backup link --remove
```

La commande crée un jeton de liaison de portée administrateur, l'envoie à ToutWAF avec l'adresse du serveur et l'empreinte de son certificat, et enregistre l'appairage ; si ToutWAF refuse, le jeton est révoqué et rien ne reste. L'appairage est refusé quand le serveur de sauvegarde et ToutWAF tournent sur la même machine. ToutWAF doit vérifier l'empreinte par un autre canal la première fois.

## Ce que la console ToutWAF peut alors faire

* Créer, pour chaque machine ToutWAF, un datastore et un jeton **écrivain** (ajout seul, limité à un datastore et un espace de noms) et un jeton **lecteur** facultatif pour les restaurations.
* Fixer des quotas et des plafonds de débit sur les jetons qu'elle provisionne, et lire l'utilisation.
* Lire l'état du serveur (santé, utilisation, alertes, dernière sauvegarde de chaque groupe), lister et inspecter les instantanés.
* Lancer la vérification d'un instantané ou d'un datastore (sans clé) et la suivre comme une tâche.
* Recevoir des événements signés : tâche en échec, vérification en échec, sauvegarde en retard, alerte de quota. Les restaurations s'exécutent sur la machine ToutWAF, qui détient la clé.

## Datastore local ou S3, au choix pour chaque machine

La console choisit où vivent les sauvegardes de chaque machine avec les champs `backend`, `s3` et `s3_auth` de `POST /api/v1/link/provision`, et peut aussi planifier une copie hors site vers un bucket avec `offsite_s3`. Seul `name` est obligatoire ; `backend` vaut par défaut un datastore local. Les clés de `s3_auth` sont en écriture seule : gardées sur le serveur, jamais renvoyées ni journalisées.

```json
POST /api/v1/link/provision
{"name":"toutwaf-prod","datastore":"toutwaf","namespace":"toutwaf-prod","append_only":true,"require_encryption":true,
 "backend":"s3",
 "s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-backups","prefix":"toutwaf-prod","addressing":"auto",
       "object_lock_mode":"","object_lock_days":0,"storage_class":""},
 "s3_auth":{"access_key_id":"...","secret_access_key":"...","session_token":"","ca_pem":""},
 "offsite_s3":{"s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-offsite","prefix":"toutwaf-prod"},"s3_auth":{"access_key_id":"...","secret_access_key":"..."},
               "schedule":"every 6h","bandwidth_bps":0,"verify_after":true}}
```

* `backend` : `files` (local, par défaut) ou `s3`.
* `s3` : fournisseur, région, bucket, préfixe, adressage, mode et durée d'Object Lock, classe de stockage ; `s3_auth` : clé d'accès, clé secrète, jeton de session facultatif et autorité privée.
* `offsite_s3` : les mêmes `s3` et `s3_auth` pour le bucket de destination, plus `schedule`, `bandwidth_bps` et `verify_after` (vrai par défaut) ; cela crée une tâche `offsite-<datastore>`.
* La réponse porte `backend`, `s3` (ce qui est affiché, jamais un secret) et `offsite_job`. Un bucket invalide ou de mauvaises clés donnent une erreur `400` et rien n'est créé ; demander un autre backend que celui d'un datastore existant du même nom donne une erreur `409`. `POST /api/v1/storage/test` permet à la console de tester d'abord un bucket, et `POST /api/v1/datastores/import-s3` reconstruit un datastore depuis un bucket après une perte totale.

## État, en toute franchise

L'appairage, la provision, l'état, les événements signés et les champs S3 sont testés de bout en bout contre une fausse console ToutWAF. **Non testé : une vraie console ToutWAF**, qui n'implémente pas encore son côté ; et S3 uniquement contre un faux en mémoire, pas un vrai fournisseur.
