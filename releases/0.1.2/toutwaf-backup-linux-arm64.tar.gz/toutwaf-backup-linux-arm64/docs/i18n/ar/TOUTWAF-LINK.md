[English](../en/TOUTWAF-LINK.md) | [Français](../fr/TOUTWAF-LINK.md) | [Español](../es/TOUTWAF-LINK.md) | [Deutsch](../de/TOUTWAF-LINK.md) | [Italiano](../it/TOUTWAF-LINK.md) | [Português](../pt/TOUTWAF-LINK.md) | [Nederlands](../nl/TOUTWAF-LINK.md) | [Русский](../ru/TOUTWAF-LINK.md) | [中文](../zh/TOUTWAF-LINK.md) | **العربية**

<div dir="rtl">

# الربط مع ToutWAF

يعمل ToutWAF Backup بمفرده. يتيح الربط لوحدة تحكم ToutWAF استخدام خادم نسخ احتياطي: فتنشئ مخزن البيانات والرموز المقيَّدة لكل جهاز ToutWAF، وتجدول النسخ وتتحقق منها وتستعيدها، وتتلقى تنبيهات الفشل. العقد له إصدار (`toutwaf-backup-link/1`) وموثَّق بالكامل في `docs/TOUTWAF-LINK.md` الإنجليزي؛ وهذه الصفحة هي منظور المستخدم. **يبقى المفتاح على جهاز ToutWAF**: لا يستطيع خادم النسخ الاحتياطي ولا رمز الربط فك أي تشفير.

## الاقتران

في وحدة تحكم ToutWAF أنشئ **رمز اقتران** لمرة واحدة («إضافة خادم نسخ احتياطي») ثم شغّل على خادم النسخ الاحتياطي:

```sh
toutwaf-backup link --toutwaf https://waf.example.net --token <pairing token> --url https://backup.example.net:8007
toutwaf-backup link --status
toutwaf-backup link --remove
```

ينشئ الأمر رمز ربط بنطاق المسؤول ويرسله إلى ToutWAF مع عنوان الخادم وبصمة شهادته ويسجّل الاقتران؛ وإذا رفض ToutWAF أُلغي الرمز مجددًا ولا يبقى شيء. يُرفض الاقتران عندما يعمل خادم النسخ الاحتياطي وToutWAF على الجهاز نفسه. ويجب على ToutWAF التحقق من البصمة عبر قناة أخرى في المرة الأولى.

## ما تستطيع وحدة تحكم ToutWAF فعله بعد ذلك

* إنشاء مخزن بيانات ورمز **writer** لكل جهاز ToutWAF (للإضافة فقط ومحصور في مخزن بيانات واحد ومساحة أسماء واحدة) ورمز **reader** اختياري للاستعادة.
* ضبط الحصص وحدود عرض النطاق على الرموز التي تجهّزها وقراءة الاستخدام.
* قراءة حالة الخادم (الصحة والاستخدام والتنبيهات وآخر نسخة لكل مجموعة) وسرد اللقطات وفحصها.
* بدء التحقق من لقطة أو مخزن بيانات (دون مفتاح) ومتابعته كمهمة.
* تلقي أحداث موقَّعة: فشل مهمة أو تحقق أو تأخر نسخة أو تحذير حصة. تجري الاستعادة على جهاز ToutWAF الذي يملك المفتاح.

## مخزن بيانات محلي أو S3 يُختار لكل جهاز

تختار وحدة التحكم مكان نسخ كل جهاز بالحقول `backend` و`s3` و`s3_auth` في `POST /api/v1/link/provision`، ويمكنها أيضًا جدولة نسخة خارج الموقع إلى حاوية بالحقل `offsite_s3`. المطلوب فقط `name`؛ وقيمة `backend` الافتراضية مخزن بيانات محلي. مفاتيح `s3_auth` للكتابة فقط: تُحفظ على الخادم ولا تُعاد ولا تُسجَّل أبدًا.

```json
POST /api/v1/link/provision
{"name":"toutwaf-prod","datastore":"toutwaf","namespace":"toutwaf-prod","append_only":true,"require_encryption":true,
 "backend":"s3",
 "s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-backups","prefix":"toutwaf-prod","addressing":"auto",
       "object_lock_mode":"","object_lock_days":0,"storage_class":""},
 "s3_auth":{"access_key_id":"...","secret_access_key":"...","session_token":"","ca_pem":""},
 "offsite_s3":{"s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-offsite","prefix":"toutwaf-prod"},"s3_auth":{"access_key_id":"...","secret_access_key":"..."},
               "schedule":"every 6h","bandwidth_bps":0,"verify_after":true}}
```

* `backend`: ‏`files` (محلي، الافتراضي) أو `s3`.
* `s3`: المزوّد والمنطقة والحاوية والبادئة والعنونة ووضع Object Lock وأيامه وفئة التخزين؛ `s3_auth`: مفتاح الوصول والمفتاح السري ورمز الجلسة الاختياري وCA الخاصة.
* `offsite_s3`: نفس `s3` و`s3_auth` للحاوية الهدف، إضافة إلى `schedule` و`bandwidth_bps` و`verify_after` (صحيح افتراضيًا)؛ وينشئ مهمة `offsite-<datastore>`.
* تحمل الاستجابة `backend` و`s3` (ما يُعرض وليس سرًّا أبدًا) و`offsite_job`. الحاوية غير الصالحة أو المفاتيح الخاطئة تعطي `400` ولا يُنشأ شيء؛ وطلب backend مختلف عن backend مخزن بيانات موجود بالاسم نفسه يعطي `409`. يتيح `POST /api/v1/storage/test` للوحدة اختبار حاوية أولًا، ويعيد `POST /api/v1/datastores/import-s3` بناء مخزن بيانات من حاوية بعد فقدان كلي.

## الحالة بصراحة

اختُبرت عمليات الاقتران والتجهيز والحالة والأحداث الموقَّعة وحقول S3 من البداية إلى النهاية مقابل وحدة تحكم ToutWAF محاكاة. **لم تُختبر وحدة تحكم ToutWAF حقيقية** إذ لم تنفّذ جانبها بعد؛ ولم يُختبر S3 إلا مقابل محاكاة داخل العملية وليس مزوّدًا حقيقيًا.

</div>
