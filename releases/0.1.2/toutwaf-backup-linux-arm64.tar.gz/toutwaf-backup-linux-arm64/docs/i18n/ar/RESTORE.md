[English](../en/RESTORE.md) | [Français](../fr/RESTORE.md) | [Español](../es/RESTORE.md) | [Deutsch](../de/RESTORE.md) | [Italiano](../it/RESTORE.md) | [Português](../pt/RESTORE.md) | [Nederlands](../nl/RESTORE.md) | [Русский](../ru/RESTORE.md) | [中文](../zh/RESTORE.md) | **العربية**

<div dir="rtl">

# دليل الاستعادة والتعافي من الكوارث

النسخة التي لم تستعدها قط مجرد أمل. اقرأ هذا مرة واحدة **قبل** أن تحتاجه، ونفّذ التمرين الأخير مرة كل ثلاثة أشهر على الأقل.

## ما يجب أن يكون لديك وأين تحتفظ به

| العنصر | السبب ومكان الحفظ |
|---|---|
| **ملف المفتاح** و**عبارته السرية** | تفك تشفير كل شيء؛ احفظهما في مدير كلمات مرور أو خزنة وليس على الجهاز المنسوخ فقط |
| **المفتاح الورقي** الذي يطبعه `client key create` | يعيد بناء ملف المفتاح إذا ضاع الملف أو العبارة السرية؛ اطبعه واحفظه في خزنة |
| **بصمة الخادم** ورمز *reader* (أو admin) | للوصول إلى الخادم؛ ويمكن إنشاء رمز reader من جديد على الخادم |
| هذه الصفحة والملف التنفيذي `toutwaf-backup` لنظامك | الأداة نفسها؛ احتفظ بنسخة على ذاكرة USB فهي ملف ثابت واحد |

إذا لم يكن لديك ملف المفتاح ولا العبارة السرية ولا المفتاح الورقي فـ**لا يستطيع أحد استرجاع البيانات.** هذا هو ثمن خادم لا يملك مفتاحًا أبدًا.

## استعادة ملف أو دليل (يوميًا)

```sh
toutwaf-backup client snapshots --type host --id web1                         # find the snapshot
toutwaf-backup client ls host/web1/latest etc/nginx                            # look inside, no restore needed
toutwaf-backup client find host/web1/latest '*.conf'
toutwaf-backup client restore host/web1/20261023T023000Z --path etc/nginx --target /tmp/restore --verify
toutwaf-backup client cat host/web1/latest etc/hostname                        # one file to standard output
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop                 # a database dump straight into its importer
```

المسارات هي التي يعرضها `ls` (بلا شرطة مائلة أولى)؛ ويُستعاد مسار المصدر `/etc/nginx` إلى `<الوجهة>/etc/nginx`. **لا تُستبدل** الملفات الموجودة أبدًا إلا مع `--overwrite`. يفتح `client browse` صفحة ويب محلية (127.0.0.1) للتصفح والتنزيل.

## استعادة جهاز كامل

تنسخ الأداة **الملفات ومعلومات النظام وليس صور الأقراص**: فهي لا تعيد إنشاء الأقسام ولا مُحمِّلات الإقلاع ولا نظام التشغيل. أعد بناء النظام الأساسي أولًا ثم استعد البيانات.

1. ثبّت نظام التشغيل (التوزيعة نفسها إن أمكن) واضبط اسم المضيف والشبكة.
2. ثبّت العميل (`install.sh --role client` أو انسخ الملف التنفيذي).
3. أعد إنشاء الاتصال والمفتاح: إذا كان لديك المفتاح الورقي فقط فاستخدم `client key import-paper` (يتحقق من كل سطر ويطلب عبارة سرية جديدة) ثم `client init`.
4. اطّلع على ما كان عليه المضيف (`.twb-meta/system.json`: اسم المضيف والنواة ونقاط التركيب والحزم المثبّتة).
5. استعد أولًا إلى دليل مؤقت أو مباشرة إلى الجذر؛ شغّل بصلاحيات root لاستعادة المالكين والسمات الممتدة وACL وعقد الأجهزة وFIFO.
6. أعد تثبيت مُحمِّل الإقلاع والحزم إذا كان الجذر جديدًا، ثم أعد التشغيل وافحص الخدمات، ثم خذ نسخة جديدة: ستُزال مكرراتها مقارنة بالقديمة.

```sh
toutwaf-backup client key import-paper --keyfile /root/key.json < paper.txt        # only if the key file or the passphrase is lost
toutwaf-backup client init --server https://backup.example.net:8007 --fingerprint <hex> --token <reader token> --datastore main --namespace hosts/web1 --keyfile /root/key.json
toutwaf-backup client cat host/web1/latest .twb-meta/system.json                   # what the host was (when saved with --system-info)
toutwaf-backup client restore host/web1/latest --target /mnt/newroot --verify      # a new root mounted at /mnt/newroot
toutwaf-backup client restore host/web1/latest --target / --overwrite --verify     # in place, replaces files
```

## ضاع ملف المفتاح أو العبارة السرية

* ضاعت العبارة السرية و**المفتاح الورقي موجود**: نفّذ `client key import-paper --keyfile new.json < paper.txt` وعيّن عبارة سرية جديدة وحدّث الملف الشخصي.
* ضاع ملف المفتاح والعبارة السرية موجودة: استخدم المفتاح الورقي كما سبق. بدونه لا يمكن فعل شيء. **نسخة الإيداع** (`client key escrow`) تُفتح بعبارتها السرية الخاصة.
* بعد ذلك غيّر العبارة السرية بـ `client key change-passphrase`. **إذا ضاعت الثلاثة معًا تصبح النسخ غير قابلة للقراءة، وهذا مقصود في التصميم.**

## فُقد خادم النسخ الاحتياطي

1. استرجع البيانات: القرص أو نسخة مستعادة أو **النسخة خارج الموقع** التي دفعتها مهمة المزامنة إلى خادم أو قرص ثانٍ. دليل مخزن البيانات يصف نفسه.
2. على جهاز جديد: `install.sh --role server --no-init` ثم `toutwaf-backup server init --state /var/lib/toutwaf-backup --listen :8007 --external-url https://... --datastore main=/مسار/مخزن/البيانات/المسترجع` (يُتبنى الدليل الموجود ولا يُعاد كتابة شيء). دوّن رمز المسؤول الجديد و**بصمة الشهادة الجديدة**.
3. أنشئ رموزًا لعملائك (`server token create`) ونفّذ `client init` مجددًا بالبصمة الجديدة.
4. تحقق بالأمر `toutwaf-backup server verify --datastore main --scrub` واستعد ملفًا بواسطة عميل وأنشئ مهمة النسخة خارج الموقع من جديد.

## فُقد الخادم وقرصه والنسخة في حاوية S3

إذا عملت مهمة *نسخة خارج الموقع إلى S3* (أو كان مخزن البيانات نفسه في حاوية) فإن الحاوية تحوي كل شيء عدا المفتاح: الأجزاء، وفي `meta/` الإعدادات وقائمة اللقطات. تحتاج إلى الحاوية وبادئة النسخة (`offsite-<معرّف المهمة>` ما لم تختر غيرها) ومفاتيح S3 قادرة على قراءتها وملف المفتاح أو **المفتاح الورقي**. على الخادم الجديد، في واجهة الويب (مخازن البيانات، *إنشاء مخزن بيانات*، **الاستئناف من S3**) أو في سطر الأوامر:

```sh
printf '{"access_key_id":"...","secret_access_key":"..."}' | toutwaf-backup datastore import-s3 main \
  --s3-credentials-stdin --s3-bucket my-backups --s3-provider wasabi --s3-region eu-central-1 --s3-prefix offsite-main
```

تُرفض البادئة الخاطئة أو الفارغة («لا تحتوي الحاوية على مرآة بيانات وصفية») ولا يُنشأ شيء. بعدها أنشئ الرموز ونفّذ `client init` مجددًا واستعد بـ `client restore` وأنشئ مهمة النسخة خارج الموقع من جديد (فهي تتبنى النسخة الموجودة في الحاوية إذا أعطيت الحاوية والبادئة نفسيهما). يصف [S3.md](S3.md) ميزات S3 الثلاث.

## مخزن البيانات تالف (تلف صامت أو عطل جزئي في القرص)

```sh
toutwaf-backup server verify --datastore main --scrub     # reads every snapshot and chunk file; damaged chunks are moved aside, never deleted
toutwaf-backup client verify host/web1/latest --read-data  # needs the key: proves every chunk decrypts and matches its id
```

يؤدي جزء **مفقود أو تالف** إلى فشل التحقق من اللقطات التي تستخدمه. تعيد النسخة التالية للبيانات نفسها رفع الجزء فيشفى مخزن البيانات ذاتيًا؛ أما اللقطات الأقدم التي احتاجت جزءًا لم تعد البيانات الحالية تحتويه فتبقى تالفة: استعدها من النسخة المكررة (مزامنة `pull` تنسخ الناقص فقط) أو تقبّل خسارة تلك الملفات. تخبرك الاستعادة بالضبط بالملفات التي تعذّرت استعادتها (حالة الخروج 1)؛ ويُستعاد الباقي.

## التمرين (نفّذه ثم دوّن التاريخ)

1. على جهاز احتياطي (أو دليل مؤقت) مع **الأسرار الموثَّقة فقط**: ملف المفتاح أو المفتاح الورقي والعبارة السرية والرمز والبصمة.
2. نفّذ `client restore <مجموعة مهمة>/latest --target /tmp/drill --verify` وافتح بعض الملفات؛ وبالنسبة لقاعدة بيانات استورد التفريغ في نسخة تجريبية.
3. يثبت `client verify <لقطة> --read-data` أن كل جزء يُفك تشفيره ويطابق معرّفه.
4. قِس الوقت (استعادة بسرعة 70 MiB/s تستغرق نحو 4 ساعات لكل تيرابايت)، ودوّن كل ما فاجأك، وصحّح هذا الدليل.

</div>
