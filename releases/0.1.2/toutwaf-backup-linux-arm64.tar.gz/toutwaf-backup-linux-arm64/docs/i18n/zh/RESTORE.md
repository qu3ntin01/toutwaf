[English](../en/RESTORE.md) | [Français](../fr/RESTORE.md) | [Español](../es/RESTORE.md) | [Deutsch](../de/RESTORE.md) | [Italiano](../it/RESTORE.md) | [Português](../pt/RESTORE.md) | [Nederlands](../nl/RESTORE.md) | [Русский](../ru/RESTORE.md) | **中文** | [العربية](../ar/RESTORE.md)

# 恢复与灾难恢复手册

从未恢复过的备份只是一种期望。请在需要**之前**阅读一遍，并且至少每季度做一次末尾的演练。

## 必须准备的东西及存放位置

| 项目 | 用途与存放位置 |
|---|---|
| **密钥文件**及其**口令** | 用于解密一切；请保存在密码管理器或保险库中，不要只放在被备份的机器上 |
| `client key create` 打印出的**纸质密钥** | 在密钥文件或口令丢失时重建密钥文件；请打印出来存放在保险箱里 |
| **服务器指纹**和一个 *reader*（或 admin）令牌 | 用于连接服务器；reader 令牌可以在服务器上重新创建 |
| 本页以及适合您系统的 `toutwaf-backup` 可执行文件 | 工具本身；请在 U 盘上留一份，它只是一个静态文件 |

如果密钥文件、口令和纸质密钥都没有，**任何人都无法找回数据。** 这就是服务器从不持有密钥所付出的代价。

## 恢复文件或目录（日常）

```sh
toutwaf-backup client snapshots --type host --id web1                         # find the snapshot
toutwaf-backup client ls host/web1/latest etc/nginx                            # look inside, no restore needed
toutwaf-backup client find host/web1/latest '*.conf'
toutwaf-backup client restore host/web1/20261023T023000Z --path etc/nginx --target /tmp/restore --verify
toutwaf-backup client cat host/web1/latest etc/hostname                        # one file to standard output
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop                 # a database dump straight into its importer
```

路径与 `ls` 显示的一致（不带开头的斜杠）；源路径 `/etc/nginx` 会恢复到 `<目标>/etc/nginx`。除非加 `--overwrite`，否则**绝不覆盖**已有文件。`client browse` 会打开一个本地网页（127.0.0.1）用于浏览和下载。

## 恢复整台机器

该工具备份的是**文件和系统信息，而不是磁盘镜像**：它不会重建分区、引导程序或操作系统。请先重建基础系统，再恢复数据。

1. 安装操作系统（尽量使用相同的发行版），并设置主机名和网络。
2. 安装客户端（`install.sh --role client`，或直接复制可执行文件）。
3. 重建连接和密钥：如果只有纸质密钥，使用 `client key import-paper`（它会检查每一行并要求设置新口令），然后运行 `client init`。
4. 查看这台主机原来的样子（`.twb-meta/system.json`：主机名、内核、挂载点、已安装的软件包）。
5. 先恢复到一个暂存目录，或直接恢复到根目录；以 root 运行才能恢复所有者、扩展属性、ACL、设备节点和 FIFO。
6. 如果根文件系统是新的，请重新安装引导程序和软件包，重启，检查各项服务，然后做一次新的备份：它会与旧备份去重。

```sh
toutwaf-backup client key import-paper --keyfile /root/key.json < paper.txt        # only if the key file or the passphrase is lost
toutwaf-backup client init --server https://backup.example.net:8007 --fingerprint <hex> --token <reader token> --datastore main --namespace hosts/web1 --keyfile /root/key.json
toutwaf-backup client cat host/web1/latest .twb-meta/system.json                   # what the host was (when saved with --system-info)
toutwaf-backup client restore host/web1/latest --target /mnt/newroot --verify      # a new root mounted at /mnt/newroot
toutwaf-backup client restore host/web1/latest --target / --overwrite --verify     # in place, replaces files
```

## 密钥文件或口令丢失

* 口令丢失但**纸质密钥还在**：运行 `client key import-paper --keyfile new.json < paper.txt`，设置新口令，更新配置档案。
* 密钥文件丢失但口令还在：像上面那样使用纸质密钥。没有它就无能为力。**托管副本**（`client key escrow`）用它自己的口令打开。
* 之后用 `client key change-passphrase` 更换口令。**三者全部丢失时，备份将无法读取，这是设计使然。**

## 备份服务器丢失

1. 取回数据：磁盘、已恢复的副本，或同步作业推送到第二台服务器/磁盘上的**异地副本**。数据存储目录是自描述的。
2. 在新机器上：`install.sh --role server --no-init`，然后运行 `toutwaf-backup server init --state /var/lib/toutwaf-backup --listen :8007 --external-url https://... --datastore main=/已恢复数据存储的路径`（会接管已有目录，不重写任何内容）。记下新的管理员令牌和**新的证书指纹**。
3. 为您的客户端创建令牌（`server token create`），并用新指纹重新运行 `client init`。
4. 用 `toutwaf-backup server verify --datastore main --scrub` 检查，用客户端恢复一个文件，并重新创建异地副本作业。

## 服务器及其磁盘丢失，副本在 S3 存储桶中

如果运行过*到 S3 的异地副本*作业（或数据存储本身就在存储桶中），存储桶里除了密钥之外应有一切：数据块，以及 `meta/` 中的设置和快照列表。您需要存储桶、副本的前缀（除非另行选择，否则为 `offsite-<作业 ID>`）、可读取它的 S3 密钥，以及您的密钥文件或**纸质密钥**。在新服务器上，通过网页界面（数据存储，*创建数据存储*，**从 S3 恢复**）或命令行：

```sh
printf '{"access_key_id":"...","secret_access_key":"..."}' | toutwaf-backup datastore import-s3 main \
  --s3-credentials-stdin --s3-bucket my-backups --s3-provider wasabi --s3-region eu-central-1 --s3-prefix offsite-main
```

错误或为空的前缀会被拒绝（“存储桶中没有元数据镜像”），且不会创建任何内容。随后创建令牌，重新运行 `client init`，用 `client restore` 恢复，并重新创建异地副本作业（如果给出相同的存储桶和前缀，它会接管存储桶中已有的副本）。三项 S3 功能的说明见 [S3.md](S3.md)。

## 数据存储损坏（比特腐烂、磁盘部分故障）

```sh
toutwaf-backup server verify --datastore main --scrub     # reads every snapshot and chunk file; damaged chunks are moved aside, never deleted
toutwaf-backup client verify host/web1/latest --read-data  # needs the key: proves every chunk decrypts and matches its id
```

**缺失或损坏**的数据块会使用到它的快照验证失败。再次备份相同的数据会重新上传该数据块，数据存储随之自愈；而需要某个现有数据中已不存在的数据块的较旧快照仍会处于损坏状态：请从副本恢复它们（`pull` 同步只复制缺失的部分），或接受这些文件的损失。恢复会准确告诉您哪些文件未能恢复（退出状态 1），其余的会正常恢复。

## 演练（做一遍，并记下日期）

1. 在备用机器（或临时目录）上，**只**使用文档中记录的机密：密钥文件或纸质密钥、口令、令牌、指纹。
2. 运行 `client restore <重要分组>/latest --target /tmp/drill --verify`，打开几个文件；对数据库，把转储导入到一个临时实例。
3. `client verify <快照> --read-data` 可证明每个数据块都能解密且与其 ID 相符。
4. 给整个过程计时（70 MiB/s 的恢复速度下，每 TB 约需 4 小时），记下任何出乎意料的地方，并修正这份手册。
