[English](../en/TOUTWAF-LINK.md) | [Français](../fr/TOUTWAF-LINK.md) | [Español](../es/TOUTWAF-LINK.md) | [Deutsch](../de/TOUTWAF-LINK.md) | [Italiano](../it/TOUTWAF-LINK.md) | [Português](../pt/TOUTWAF-LINK.md) | [Nederlands](../nl/TOUTWAF-LINK.md) | [Русский](../ru/TOUTWAF-LINK.md) | **中文** | [العربية](../ar/TOUTWAF-LINK.md)

# 与 ToutWAF 的关联

ToutWAF Backup 可独立运行。关联让 ToutWAF 控制台能够使用备份服务器：为每台 ToutWAF 机器创建数据存储和受限令牌，安排备份，对其进行检查和恢复，并接收故障告警。该契约带版本号（`toutwaf-backup-link/1`），完整说明见英文的 `docs/TOUTWAF-LINK.md`；本页是面向用户的视角。**密钥留在 ToutWAF 机器上**：备份服务器和关联令牌都无法解密任何内容。

## 配对

在 ToutWAF 控制台中创建一次性的**配对令牌**（“添加备份服务器”），然后在备份服务器上运行：

```sh
toutwaf-backup link --toutwaf https://waf.example.net --token <pairing token> --url https://backup.example.net:8007
toutwaf-backup link --status
toutwaf-backup link --remove
```

该命令会创建一个管理员范围的关联令牌，连同服务器地址和证书指纹一起发送给 ToutWAF，并记录配对；如果 ToutWAF 拒绝，令牌会被再次吊销，不留任何痕迹。当备份服务器与 ToutWAF 运行在同一台机器上时，配对会被拒绝。ToutWAF 第一次必须通过另一条渠道核实该指纹。

## ToutWAF 控制台随后可以做什么

* 为每台 ToutWAF 机器创建数据存储和 **writer** 令牌（仅追加，限定在一个数据存储和一个命名空间内），以及用于恢复的可选 **reader** 令牌。
* 为其创建的令牌设置配额和带宽上限，并读取用量。
* 读取服务器状态（健康、用量、告警、每个分组最近一次备份），列出并查看快照。
* 启动对快照或数据存储的验证（无需密钥），并作为任务跟踪。
* 接收已签名的事件：作业失败、验证失败、备份延迟、配额告警。恢复在持有密钥的 ToutWAF 机器上执行。

## 本地或 S3 数据存储，按机器选择

控制台通过 `POST /api/v1/link/provision` 的 `backend`、`s3` 和 `s3_auth` 字段选择每台机器的备份存放位置，还可以通过 `offsite_s3` 安排到存储桶的异地副本。只有 `name` 是必填项；`backend` 默认为本地数据存储。`s3_auth` 中的密钥是只写的：保存在服务器上，永不返回，也不写入日志。

```json
POST /api/v1/link/provision
{"name":"toutwaf-prod","datastore":"toutwaf","namespace":"toutwaf-prod","append_only":true,"require_encryption":true,
 "backend":"s3",
 "s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-backups","prefix":"toutwaf-prod","addressing":"auto",
       "object_lock_mode":"","object_lock_days":0,"storage_class":""},
 "s3_auth":{"access_key_id":"...","secret_access_key":"...","session_token":"","ca_pem":""},
 "offsite_s3":{"s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-offsite","prefix":"toutwaf-prod"},"s3_auth":{"access_key_id":"...","secret_access_key":"..."},
               "schedule":"every 6h","bandwidth_bps":0,"verify_after":true}}
```

* `backend`：`files`（本地，默认）或 `s3`。
* `s3`：提供商、区域、存储桶、前缀、寻址方式、Object Lock 模式和天数、存储类别；`s3_auth`：访问密钥、秘密密钥、可选的会话令牌和私有 CA。
* `offsite_s3`：目标存储桶的 `s3` 和 `s3_auth`，外加 `schedule`、`bandwidth_bps` 和 `verify_after`（默认为 true）；它会创建作业 `offsite-<datastore>`。
* 响应包含 `backend`、`s3`（显示用的内容，绝不含密钥）和 `offsite_job`。存储桶无效或密钥错误会返回 `400` 且不创建任何内容；对同名的现有数据存储请求不同的 backend 会返回 `409`。`POST /api/v1/storage/test` 让控制台先测试存储桶，`POST /api/v1/datastores/import-s3` 则在完全丢失后从存储桶重建数据存储。

## 实际状况

配对、资源创建、状态、已签名事件和 S3 字段都已针对模拟的 ToutWAF 控制台做了端到端测试。**未测试：真实的 ToutWAF 控制台**（它尚未实现自己这一侧）；S3 也只针对进程内的模拟服务测试，而非真实提供商。
