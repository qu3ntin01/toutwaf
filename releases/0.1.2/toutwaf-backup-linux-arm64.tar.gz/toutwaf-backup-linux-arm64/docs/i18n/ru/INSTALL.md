[English](../en/INSTALL.md) | [Français](../fr/INSTALL.md) | [Español](../es/INSTALL.md) | [Deutsch](../de/INSTALL.md) | [Italiano](../it/INSTALL.md) | [Português](../pt/INSTALL.md) | [Nederlands](../nl/INSTALL.md) | **Русский** | [中文](../zh/INSTALL.md) | [العربية](../ar/INSTALL.md)

# Установка

Поддерживаются: Linux (amd64 и arm64, с systemd) и Windows (amd64, **не проверялось на настоящей машине Windows**). Установщику для Linux нужны `bash`, `curl` или `wget`, `tar`, `sha256sum`, `base64` и **OpenSSL 3** для проверки подписи. Сам исполняемый файл — один статический файл.

## Куда ставить сервер (прочитайте сначала)

Установка ToutWAF Backup **необязательна**. **Сервер должен работать на другой машине, чем ToutWAF**: копия, хранящаяся на защищаемой машине, не переживёт её потерю (отказ диска, вымогатель, пожар, кража). `install.sh --role server` и `install.ps1 -Role server` ищут ToutWAF на хосте и **отказываются** (код возврата 3), если находят его; `toutwaf-backup server run` делает ту же проверку при запуске. Роль клиента никогда не отклоняется.

## Установка в Linux

```sh
# server (the machine that stores the backups)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role server \
    --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start

# client (every machine to protect)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role client
```

Установщик скачивает `channel.json`, затем `SHA256SUMS` и его подпись; он **проверяет подпись Ed25519** встроенным в скрипт открытым ключом, затем **SHA-256 архива** по подписанному списку и отказывается от отозванной версии. Он атомарно устанавливает `toutwaf-backup` (предыдущий файл сохраняется как `toutwaf-backup.prev`). Для роли сервера он также создаёт системного пользователя, каталог состояния, юнит systemd и при первой установке конфигурацию: выводит первый токен администратора (один раз) и отпечаток сертификата. Без `--start` ничего не запускается. Установщик идемпотентен: для обновления запустите его снова.

**Язык установщиков.** `install.sh` и `install.ps1` говорят на десяти языках: они следуют `--lang fr` (или `--fr`, `--es`, `--de` ...; в Windows `-Lang fr`), затем `TWB_LANG`, затем языку системы (`LC_ALL`, `LANG`; язык интерфейса Windows), затем английскому. Для диакритических знаков и нелатинских письменностей нужен терминал UTF-8, иначе установщик говорит по-английски. Имена параметров, команды и имена файлов не переводятся.

## Сервер: первые шаги

```sh
systemctl enable --now toutwaf-backup-server       # if you did not pass --start
toutwaf-backup server token create --name web1 --role writer --datastore main --namespace hosts/web1 --append-only
toutwaf-backup server datastore set main --require-encryption=true --quota 2T --immutable-days 7
```

* Откройте порт (по умолчанию 8007) только для ваших клиентов. Веб-интерфейс — `https://HOST:8007/` (вход по токену администратора). Сертификат самоподписанный, поэтому браузеры предупреждают: сверьте отпечаток в разделе **Настройки** с выводом `toutwaf-backup server fingerprint`.
* Создавайте по токену на каждого клиента и никогда не передавайте токен администратора. Токен `writer` может создавать копии, но не может ни читать, ни удалять.
* Режим *только добавление* для datastore означает, что через API никто не может удалять; чтобы выключить его, нужно выполнить `toutwaf-backup server datastore set main --append-only=false` на самой машине сервера.
* Планируйте собственные задачи сервера в веб-интерфейсе (**Задания**): еженедельная проверка, ежедневная очистка (не для datastore в режиме «только добавление»), еженедельная сборка мусора и внешняя копия на второй сервер, диск или бакет S3. Уведомления (почта, подписанные webhook) находятся в разделе **Настройки**.
* Копируйте собственное состояние сервера (`/var/lib/toutwaf-backup`: конфигурация, токены, ключ TLS, журнал аудита) клиентом на другой сервер. Потеря ключа TLS заставит каждого клиента закрепить новый отпечаток.

## Клиент: первые шаги

```sh
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --namespace hosts/web1 --create-key
toutwaf-backup client backup --path /etc --path /var/www --id $(hostname) --one-file-system --exclude '*.tmp'
toutwaf-backup client snapshots
toutwaf-backup client schedule --daily 02:30 --id $(hostname) --path /etc --path /var/www --install
systemctl daemon-reload && systemctl enable --now toutwaf-backup-$(hostname).timer
```

`client init --create-key` показывает отпечаток сервера для подтверждения, записывает профиль и создаёт файл ключа, затем выводит **бумажный ключ**. **Храните файл ключа, его парольную фразу и бумажный ключ вне этой машины**: без них никто не сможет восстановить данные (см. `RESTORE.md`). Для запусков без присмотра поместите парольную фразу в файл, доступный для чтения только root, и укажите его в профиле. Код возврата: 0 — успех, 1 — сбой (ничего не зафиксировано), 2 — зафиксировано с предупреждениями. Для баз данных временный файл не нужен:

```sh
mysqldump --single-transaction shop | toutwaf-backup client backup --type db --id shop --stdin --stdin-name shop.sql
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop
```

## Объектное хранилище S3

Datastore может хранить фрагменты в S3-совместимом бакете (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO), а любой datastore можно по расписанию копировать в бакет. В веб-интерфейсе: «Datastore», *Создать datastore*, **Объектное хранилище S3**, затем *Проверить соединение*. Полное руководство, командная строка и порядок восстановления — в [S3.md](S3.md).

## Монтирование снимка (Linux)

```sh
toutwaf-backup client mount host/web1/latest /mnt/snap        # read-only; Ctrl-C or: fusermount3 -u /mnt/snap
```

Снимок виден как дерево каталогов только для чтения: ничего не восстанавливается; фрагменты файла скачиваются, расшифровываются и проверяются, только когда программа их читает. Фрагмент, не прошедший проверку подлинности, даёт ошибку ввода-вывода, но никогда не неверные данные. Обычному пользователю для монтирования нужен пакет `fuse3`.

## Windows

> **В этом релизе НЕ проверялось на настоящей машине Windows.** Бинарный файл для Windows собран кросс-компиляцией, а движок копирования и восстановления — тот же код, что проверяется в Linux, но всё специфичное для Windows написано по документации и никогда не запускалось. Сначала попробуйте на некритичной машине.

```powershell
# in an elevated PowerShell
irm https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.ps1 -OutFile install.ps1    # read it, then:
.\install.ps1 -Role server -ExternalUrl https://backup.example.net:8007 -Datastore main=D:\Backups\main -Start
.\install.ps1 -Role client
```

Те же параметры есть и здесь (`-Channel`, `-Version`, `-BaseUrl`, `-InstallDir`, `-StateDir`, `-Listen`, `-NoInit`, `-Start`, `-NoFirewall`, `-Uninstall`, `-Purge`, `-Force`, `-Yes`, `-Lang`). Скрипт проверяет подпись Ed25519 на чистом PowerShell, устанавливает `toutwaf-backup.exe`, добавляет его в системный PATH, а для сервера ограничивает доступ к каталогу состояния, устанавливает службу Windows и правило брандмауэра (только профили «Домен» и «Частный»). Отличия от Linux:

* `client mount` есть только в Linux; в Windows используйте `client ls`, `client find`, `client cat` и `client restore`.
* Копирование из теневой копии тома (`--vss`) **не проверялось и отключено**, если не задана переменная окружения `TWB_ENABLE_UNTESTED_VSS=1`.
* Дескрипторы безопасности NTFS записываются в каждую копию, но их **восстановление** не проверялось и отключено, если не задано `TWB_ENABLE_UNTESTED_WIN_ACL=1`. Длинные пути, точки соединения, альтернативные потоки данных и EFS не проверялись или не поддерживаются.
* `install.ps1`, его проверка подписи на чистом PowerShell, служба Windows, правило брандмауэра и файл планировщика заданий, создаваемый `client schedule --target windows`, никогда не запускались в Windows.

## Обновление, откат, удаление

```sh
sudo ./install.sh --role server                         # run it again with the same options: upgrade
sudo mv /usr/local/bin/toutwaf-backup.prev /usr/local/bin/toutwaf-backup && sudo systemctl restart toutwaf-backup-server    # rollback
sudo ./install.sh --role server --uninstall            # keeps the data; add --purge to remove the configuration, the state and the user
```

Формат 1 и API 1 стабильны, поэтому серверы и клиенты разных версий 0.x совместимы. Удаление сохраняет данные, если не добавить `--purge`; datastore вне каталога состояния никогда не удаляются.
