[English](../en/SECURITY.md) | [Français](../fr/SECURITY.md) | [Español](../es/SECURITY.md) | [Deutsch](../de/SECURITY.md) | [Italiano](../it/SECURITY.md) | [Português](../pt/SECURITY.md) | **Nederlands** | [Русский](../ru/SECURITY.md) | [中文](../zh/SECURITY.md) | [العربية](../ar/SECURITY.md)

# Beveiligingsmodel (samenvatting)

Dit is een samenvatting. Het volledige bedreigingsmodel, de cryptografie en het repositoryformaat staan in de Engelse documentatie (`docs/SECURITY.md`, `docs/ARCHITECTURE.md`). **Geen enkele derde partij heeft deze software geaudit.**

## Wat de server wel en niet kan zien

| De server kan zien | De server kan niet zien |
|---|---|
| dat er een client met een geldig token bestaat, zijn adres, wanneer hij verbinding maakt | de sleutel, de wachtzin, de inhoud van enig bestand |
| de naam van de back-upgroep (bijvoorbeeld `host/web1`), de naamruimte, de tijden van snapshots, totale groottes en bestandsaantallen, de grootte en het aantal opgeslagen chunks | bestandsnamen, de mapstructuur, de grootte van afzonderlijke bestanden, eigenaars, rechten, welke chunk bij welk bestand hoort, of twee bestanden inhoud delen |
| dat twee snapshots chunks delen (zelfde sleutel) | niets waarmee het een vermoeden over uw leesbare gegevens kan toetsen: chunk-id's zijn gesleuteld (HMAC), de chunkgrenzen ook |

Grootte en timing lekken per ontwerp: een waarnemer van de server of het netwerk leert hoeveel er veranderde en wanneer. Met `--no-encrypt` kan de server alles lezen; een datastore kan op `require_encryption` worden gezet zodat leesbare gegevens worden geweigerd.

## Bedreigingsmodel

| Aanvaller | Wat hij krijgt en waarom |
|---|---|
| Netwerkwaarnemer of man-in-the-middle | alleen groottes en timing: TLS, en de client pint de vingerafdruk van het servercertificaat; een ander certificaat wordt geweigerd voordat er een byte is verzonden |
| Gestolen back-upschijf, of leestoegang tot de server | versleutelde tekst, groepsnamen, groottes en timing: de sleutel bereikt de server nooit |
| Serverinbraak met schrijftoegang | kan back-ups verwijderen of achterhouden (beschikbaarheid); kan snapshots niet ongemerkt vervalsen, wijzigen of aaneenplakken: elke chunk is geauthenticeerd met zijn id en elk manifest is verzegeld met de sleutel |
| Gecompromitteerde client | kan rommel uploaden, maar kan bestaande back-ups niet verwijderen of overschrijven als zijn token een writer-token is (of de datastore alleen-toevoegen is); een client met de sleutel kan zijn eigen back-ups lezen |
| Gecompromitteerd beheerderstoken | kan instellingen en tokens wijzigen, maar kan niet verwijderen uit een alleen-toevoegen-datastore, alleen toevoegen niet uitschakelen en de onveranderlijkheidsperiode niet verkorten: die instellingen veranderen alleen op de servermachine zelf; elke actie staat in het hashgeketende auditlog |
| Ransomware, of root op de servermachine | ransomware op een client versleutelt de live gegevens, niet de back-ups; root op de server kan alles verwijderen (beschikbaarheid): bewaar een externe kopie (tweede server, schijf of S3-bucket met Object Lock) voor garanties tegen ransomware |

**Niet afgedekt:** een server die uw nieuwste snapshots verbergt (vergelijk `client snapshots` met uw eigen administratie, of waarschuw bij te late back-ups); verlies van de sleutel; een kwaadaardige client die praat met een datastore zonder versleutelingsplicht; een writer die de schijf vult (stel een quotum in); fysieke toegang tot de machine die zowel het sleutelbestand als de wachtzin bevat.

## Cryptografie

Wachtzin naar sleutel: **Argon2id**. Geauthenticeerde versleuteling: **XChaCha20-Poly1305** (willekeurige 192-bits nonce). Subsleutels: **HKDF-SHA-256**. Chunk-id's: HMAC-SHA-256 onder een subsleutel (SHA-256 zonder versleuteling). TLS 1.2 of nieuwer met een zelfondertekend ECDSA P-256-certificaat; releasehandtekeningen zijn Ed25519. Niets is zelfbedacht; het formaat is beschreven zodat het kan worden geaudit.

## Sleutelbeheer

* `client key create` maakt het sleutelbestand en toont de **papieren sleutel**. Het sleutelbestand kan veilig worden gekopieerd (het onthult niets zonder de wachtzin); de papieren sleutel is de hoofdsleutel in leesbare vorm: druk hem af, bewaar hem in een kluis, nooit op dezelfde machine als de gegevens.
* `client key change-passphrase` verpakt dezelfde hoofdsleutel opnieuw (oude kopieën van het sleutelbestand openen nog met de oude wachtzin: vernietig ze). `client key escrow` schrijft de sleutel verpakt onder een tweede, aparte wachtzin voor een vertrouwenspersoon.
* Sleutelbestand en wachtzin verloren maar papieren sleutel bewaard: `client key import-paper` bouwt een sleutelbestand opnieuw op. **Alle drie verloren: de back-ups zijn onleesbaar, per ontwerp.**
* Om de hoofdsleutel te vervangen (na een vermoedelijke compromittering) maakt u een nieuwe sleutel en nieuwe back-ups: die worden niet ontdubbeld ten opzichte van de oude, die leesbaar blijven met de oude sleutel tot ze worden opgeschoond. Test het herstel, niet alleen de back-up: de oefening staat in [RESTORE.md](RESTORE.md).

## API-tokens en rollen

| Rol | Kan / kan niet |
|---|---|
| **admin** | alles, inclusief tokens, datastores, taken en instellingen; kan alleen toevoegen niet uitschakelen en de onveranderlijkheidsperiode niet verkorten (alleen op de servermachine) |
| **writer** | controleert en uploadt chunks, legt snapshots vast, toont lijsten; kan chunks niet lezen, verwijderen of opschonen (tenzij toegestaan, en dan alleen eigen snapshots, nooit bij alleen toevoegen) |
| **reader** | toont lijsten, leest chunks en indexen, bladert door en downloadt niet-versleutelde snapshots; kan niet schrijven |
| **audit** | leest snapshotmetadata, het auditlog, metrieken, meldingen en de taakstatus; kan geen chunkgegevens lezen of iets wijzigen |

## Beheer

* **De server draait nooit op de machine die hij beschermt, noch naast ToutWAF.** De installatieprogramma's en `server run` weigeren dat, en het koppelcontract bevat een hash van de machine-id zodat ToutWAF en de server beide een koppeling op dezelfde machine weigeren. Er bestaat een laboratoriumuitzondering; die mag niet in productie worden gebruikt.
* Quota (harde en zachte bytelimieten, aantallen snapshots en chunks, bandbreedtelimieten) per token en per naamruimte zijn een eerlijkheidsinstrument, geen beveiligingsgrens tegen een token dat een eigen clientsleutel heeft.
* S3-inloggegevens staan in de omgeving van de server, in een bestand dat alleen de service kan lezen, of (ingevoerd in de interface of verstuurd door de ToutWAF-console) in `<status>/secrets/s3/` met modus 0600. Ze zijn alleen schrijfbaar: nooit in een configuratiebestand, een spiegel in de bucket, een API-antwoord, een pagina, het auditlog, een logregel of een opdrachtregelargument. De statusmap is dus een geheim. Met Object Lock in Compliance-modus en een alleen-toevoegen-datastore kan zelfs een gestolen S3-sleutel chunks niet vóór het einde van hun retentie verwijderen. Zie [S3.md](S3.md).
* De service draait als gebruiker zonder privileges met een verharde systemd-unit; de poort wordt alleen voor uw clients geopend. Ratebeperking per adres en vergrendeling na mislukte aanmeldingen staan standaard aan; het auditlog is hashgeketend (`server audit-verify` vindt elke wijziging). De webinterface stelt een strikte Content-Security-Policy in, zonder inline-script en zonder externe herkomst.

## Een kwetsbaarheid melden

Meld een kwetsbaarheid privé aan de eigenaar van het ToutWAF-project (zie het contact in de repository); open geen openbaar issue.
