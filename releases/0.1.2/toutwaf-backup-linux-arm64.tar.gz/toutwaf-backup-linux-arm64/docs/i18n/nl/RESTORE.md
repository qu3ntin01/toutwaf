[English](../en/RESTORE.md) | [Français](../fr/RESTORE.md) | [Español](../es/RESTORE.md) | [Deutsch](../de/RESTORE.md) | [Italiano](../it/RESTORE.md) | [Português](../pt/RESTORE.md) | **Nederlands** | [Русский](../ru/RESTORE.md) | [中文](../zh/RESTORE.md) | [العربية](../ar/RESTORE.md)

# Herstel en noodherstelprocedure

Een back-up die u nooit hebt hersteld is slechts een hoop. Lees dit eenmaal **voordat** u het nodig hebt en doe de oefening aan het eind minstens elk kwartaal.

## Wat u moet hebben en waar u het bewaart

| Onderdeel | Waarom en waar bewaren |
|---|---|
| Het **sleutelbestand** en de **wachtzin** | ontsleutelen alles; bewaar ze in een wachtwoordbeheerder of kluis, niet alleen op de machine waarvan een back-up wordt gemaakt |
| De door `client key create` afgedrukte **papieren sleutel** | bouwt het sleutelbestand opnieuw op als het bestand of de wachtzin verloren gaat; druk hem af en bewaar hem in een kluis |
| De **vingerafdruk van de server** en een *reader*- (of admin-)token | om de server te bereiken; een reader-token kan op de server opnieuw worden aangemaakt |
| Deze pagina en het `toutwaf-backup`-programma voor uw systeem | het gereedschap; bewaar een kopie op een USB-stick, het is één statisch bestand |

Als u geen van het sleutelbestand, de wachtzin en de papieren sleutel hebt, **kan niemand de gegevens terughalen.** Dat is de prijs van een server die nooit een sleutel heeft.

## Een bestand of map herstellen (dagelijks)

```sh
toutwaf-backup client snapshots --type host --id web1                         # find the snapshot
toutwaf-backup client ls host/web1/latest etc/nginx                            # look inside, no restore needed
toutwaf-backup client find host/web1/latest '*.conf'
toutwaf-backup client restore host/web1/20261023T023000Z --path etc/nginx --target /tmp/restore --verify
toutwaf-backup client cat host/web1/latest etc/hostname                        # one file to standard output
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop                 # a database dump straight into its importer
```

Paden zijn zoals getoond door `ls` (zonder beginslash); een bronpad `/etc/nginx` wordt hersteld naar `<doel>/etc/nginx`. Bestaande bestanden worden **nooit overschreven** zonder `--overwrite`. `client browse` opent een lokale webpagina (127.0.0.1) om te bladeren en te downloaden.

## Een hele machine herstellen

Het gereedschap maakt een back-up van **bestanden en systeeminformatie, geen schijfimages**: het maakt geen partities, bootloaders of besturingssysteem opnieuw aan. Bouw eerst het basissysteem opnieuw op en herstel dan de gegevens.

1. Installeer het besturingssysteem (zo mogelijk dezelfde distributie) en stel de hostnaam en het netwerk in.
2. Installeer de client (`install.sh --role client`, of kopieer het programma).
3. Maak de verbinding en de sleutel opnieuw aan: met alleen de papieren sleutel gebruikt u `client key import-paper` (controleert elke regel en vraagt om een nieuwe wachtzin), daarna `client init`.
4. Bekijk wat de host was (`.twb-meta/system.json`: hostnaam, kernel, koppelpunten, geïnstalleerde pakketten).
5. Herstel eerst naar een werkmap, of direct naar de root; voer uit als root om eigenaars, uitgebreide attributen, ACL's, apparaatbestanden en FIFO's te herstellen.
6. Installeer bij een nieuwe root de bootloader en pakketten opnieuw, herstart, controleer de services en maak dan een nieuwe back-up: die wordt ontdubbeld ten opzichte van de oude.

```sh
toutwaf-backup client key import-paper --keyfile /root/key.json < paper.txt        # only if the key file or the passphrase is lost
toutwaf-backup client init --server https://backup.example.net:8007 --fingerprint <hex> --token <reader token> --datastore main --namespace hosts/web1 --keyfile /root/key.json
toutwaf-backup client cat host/web1/latest .twb-meta/system.json                   # what the host was (when saved with --system-info)
toutwaf-backup client restore host/web1/latest --target /mnt/newroot --verify      # a new root mounted at /mnt/newroot
toutwaf-backup client restore host/web1/latest --target / --overwrite --verify     # in place, replaces files
```

## Het sleutelbestand of de wachtzin is verloren

* Wachtzin verloren, **papieren sleutel bewaard**: `client key import-paper --keyfile new.json < paper.txt`, stel een nieuwe wachtzin in, werk het profiel bij.
* Sleutelbestand verloren, wachtzin bewaard: gebruik de papieren sleutel zoals hierboven. Zonder die kan niets. Een **escrowkopie** (`client key escrow`) opent met een eigen wachtzin.
* Wijzig daarna de wachtzin met `client key change-passphrase`. **Als alle drie verloren zijn, zijn de back-ups onleesbaar, per ontwerp.**

## De back-upserver is verloren

1. Haal de gegevens terug: de schijf, een hersteld exemplaar of de **externe kopie** die een synchronisatietaak naar een tweede server of schijf heeft gestuurd. De datastoremap beschrijft zichzelf.
2. Op een nieuwe machine: `install.sh --role server --no-init`, daarna `toutwaf-backup server init --state /var/lib/toutwaf-backup --listen :8007 --external-url https://... --datastore main=/pad/naar/herstelde/datastore` (een bestaande map wordt overgenomen, er wordt niets herschreven). Noteer het nieuwe beheerderstoken en de **nieuwe vingerafdruk van het certificaat**.
3. Maak tokens voor uw clients (`server token create`) en voer `client init` opnieuw uit met de nieuwe vingerafdruk.
4. Controleer met `toutwaf-backup server verify --datastore main --scrub`, herstel een bestand met een client en maak de taak voor de externe kopie opnieuw aan.

## De server en zijn schijf zijn verloren en de kopie staat in een S3-bucket

Als een taak *Externe kopie naar S3* heeft gedraaid (of de datastore zelf in een bucket staat), bevat de bucket alles behalve de sleutel: de chunks en in `meta/` de instellingen en de snapshotlijst. U hebt de bucket nodig, het prefix van de kopie (`offsite-<taak-id>` tenzij u een ander koos), S3-sleutels die hem kunnen lezen en uw sleutelbestand of **papieren sleutel**. Op de nieuwe server, in de webinterface (Datastores, *Een datastore aanmaken*, **Hervatten vanuit S3**) of op de opdrachtregel:

```sh
printf '{"access_key_id":"...","secret_access_key":"..."}' | toutwaf-backup datastore import-s3 main \
  --s3-credentials-stdin --s3-bucket my-backups --s3-provider wasabi --s3-region eu-central-1 --s3-prefix offsite-main
```

Een onjuist of leeg prefix wordt geweigerd ("de bucket bevat geen metadataspiegel") en er wordt niets aangemaakt. Maak daarna tokens aan, voer `client init` opnieuw uit, herstel met `client restore` en maak de taak voor de externe kopie opnieuw aan (die neemt de kopie die al in de bucket staat over als u dezelfde bucket en hetzelfde prefix opgeeft). [S3.md](S3.md) beschrijft de drie S3-functies.

## De datastore is beschadigd (bitrot, gedeeltelijk schijfdefect)

```sh
toutwaf-backup server verify --datastore main --scrub     # reads every snapshot and chunk file; damaged chunks are moved aside, never deleted
toutwaf-backup client verify host/web1/latest --read-data  # needs the key: proves every chunk decrypts and matches its id
```

Een **ontbrekende of beschadigde** chunk laat de controle mislukken van de snapshots die hem gebruiken. De volgende back-up van dezelfde gegevens uploadt de chunk opnieuw en de datastore herstelt zichzelf; oudere snapshots die een chunk nodig hadden die de huidige gegevens niet meer bevatten, blijven beschadigd: herstel ze vanaf de replica (een `pull`-synchronisatie kopieert alleen wat ontbreekt) of accepteer het verlies van die bestanden. Het herstel meldt precies welke bestanden het niet kon herstellen (afsluitstatus 1); de rest wordt hersteld.

## De oefening (doe hem en noteer de datum)

1. Op een reservemachine (of in een tijdelijke map) met **alleen** de gedocumenteerde geheimen: sleutelbestand of papieren sleutel, wachtzin, token, vingerafdruk.
2. `client restore <belangrijke groep>/latest --target /tmp/drill --verify`, open enkele bestanden; importeer bij een database de dump in een testinstantie.
3. `client verify <snapshot> --read-data` bewijst dat elke chunk ontsleutelt en bij zijn id past.
4. Neem de tijd op (een herstel met 70 MiB/s duurt ongeveer 4 uur per terabyte), noteer alles wat u verraste en verbeter deze procedure.
