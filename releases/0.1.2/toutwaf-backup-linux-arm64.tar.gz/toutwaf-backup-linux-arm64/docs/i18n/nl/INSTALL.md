[English](../en/INSTALL.md) | [Français](../fr/INSTALL.md) | [Español](../es/INSTALL.md) | [Deutsch](../de/INSTALL.md) | [Italiano](../it/INSTALL.md) | [Português](../pt/INSTALL.md) | **Nederlands** | [Русский](../ru/INSTALL.md) | [中文](../zh/INSTALL.md) | [العربية](../ar/INSTALL.md)

# Installatie

Ondersteund: Linux (amd64 en arm64, met systemd) en Windows (amd64, **niet getest op een echte Windows-machine**). Het Linux-installatieprogramma heeft `bash`, `curl` of `wget`, `tar`, `sha256sum`, `base64` en **OpenSSL 3** nodig om de handtekening te controleren. Het programma zelf is één statisch bestand.

## Waar de server hoort (eerst lezen)

Het installeren van ToutWAF Backup is **optioneel**. De **server moet op een andere machine dan ToutWAF draaien**: een back-up op de machine die hij beschermt overleeft het verlies van die machine niet (schijfdefect, ransomware, brand, diefstal). `install.sh --role server` en `install.ps1 -Role server` zoeken ToutWAF op de host en **weigeren** (afsluitstatus 3) als ze het vinden; `toutwaf-backup server run` doet dezelfde controle bij het starten. De clientrol wordt nooit geweigerd.

## Installatie onder Linux

```sh
# server (the machine that stores the backups)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role server \
    --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start

# client (every machine to protect)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role client
```

Het installatieprogramma downloadt `channel.json`, daarna `SHA256SUMS` en de handtekening ervan; het **controleert de Ed25519-handtekening** met de in het script ingebouwde publieke sleutel, daarna de **SHA-256 van het archief** tegen de ondertekende lijst, en weigert een ingetrokken versie. Het installeert `toutwaf-backup` atomair (het vorige programma blijft bewaard als `toutwaf-backup.prev`). Voor de serverrol maakt het ook de systeemgebruiker, de statusmap, de systemd-unit en bij de eerste installatie de configuratie aan: het toont het eerste beheerderstoken (eenmalig) en de vingerafdruk van het certificaat. Zonder `--start` start er niets. Het is idempotent: voer het opnieuw uit om bij te werken.

**Taal van de installatieprogramma's.** `install.sh` en `install.ps1` spreken de tien talen: ze volgen `--lang fr` (of `--fr`, `--es`, `--de` ...; `-Lang fr` onder Windows), dan `TWB_LANG`, dan de systeemtaal (`LC_ALL`, `LANG`; de weergavetaal van Windows), dan Engels. Accenten en niet-Latijnse schriften vereisen een UTF-8-terminal; anders spreekt het installatieprogramma Engels. Optienamen, opdrachten en bestandsnamen worden nooit vertaald.

## Server: eerste stappen

```sh
systemctl enable --now toutwaf-backup-server       # if you did not pass --start
toutwaf-backup server token create --name web1 --role writer --datastore main --namespace hosts/web1 --append-only
toutwaf-backup server datastore set main --require-encryption=true --quota 2T --immutable-days 7
```

* Open de poort (standaard 8007) alleen voor uw clients. De webinterface is `https://HOST:8007/` (aanmelden met het beheerderstoken). Het certificaat is zelfondertekend, dus browsers waarschuwen: vergelijk de vingerafdruk in **Instellingen** met `toutwaf-backup server fingerprint`.
* Maak per client een token aan en deel het beheerderstoken nooit. Een `writer`-token kan back-ups maken maar niet lezen of verwijderen.
* *Alleen toevoegen* op een datastore betekent dat niemand via de API kan verwijderen; uitschakelen vereist `toutwaf-backup server datastore set main --append-only=false` op de servermachine zelf.
* Plan de eigen taken van de server in de webinterface (**Taken**): een wekelijkse controle, een dagelijkse opschoning (niet op een alleen-toevoegen-datastore), een wekelijkse ruimte-vrijgave en een externe kopie naar een tweede server, een schijf of een S3-bucket. Meldingen (e-mail, ondertekende webhooks) staan onder **Instellingen**.
* Maak met een client een back-up van de eigen status van de server (`/var/lib/toutwaf-backup`: configuratie, tokens, TLS-sleutel, auditlog) naar een andere server. Verlies van de TLS-sleutel dwingt elke client de nieuwe vingerafdruk vast te pinnen.

## Client: eerste stappen

```sh
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --namespace hosts/web1 --create-key
toutwaf-backup client backup --path /etc --path /var/www --id $(hostname) --one-file-system --exclude '*.tmp'
toutwaf-backup client snapshots
toutwaf-backup client schedule --daily 02:30 --id $(hostname) --path /etc --path /var/www --install
systemctl daemon-reload && systemctl enable --now toutwaf-backup-$(hostname).timer
```

`client init --create-key` toont de vingerafdruk van de server ter bevestiging, schrijft het profiel en maakt het sleutelbestand aan, en toont daarna de **papieren sleutel**. **Bewaar het sleutelbestand, de wachtzin en de papieren sleutel buiten de machine**: zonder die kan niemand herstellen (zie `RESTORE.md`). Zet de wachtzin voor onbeheerde uitvoeringen in een bestand dat alleen root kan lezen en verwijs ernaar in het profiel. Afsluitstatus: 0 geslaagd, 1 mislukt (niets vastgelegd), 2 vastgelegd met waarschuwingen. Databases hebben geen tijdelijk bestand nodig:

```sh
mysqldump --single-transaction shop | toutwaf-backup client backup --type db --id shop --stdin --stdin-name shop.sql
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop
```

## S3-objectopslag

Een datastore kan zijn chunks bewaren in een S3-compatibele bucket (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO), en elke datastore kan volgens schema naar een bucket worden gekopieerd. In de webinterface: Datastores, *Een datastore aanmaken*, **S3-objectopslag**, daarna *De verbinding testen*. De volledige handleiding, de opdrachtregel en de herstelprocedure staan in [S3.md](S3.md).

## Een snapshot koppelen (Linux)

```sh
toutwaf-backup client mount host/web1/latest /mnt/snap        # read-only; Ctrl-C or: fusermount3 -u /mnt/snap
```

De snapshot verschijnt als alleen-lezen mapstructuur: er wordt niets hersteld; de chunks van een bestand worden pas gedownload, ontsleuteld en geauthenticeerd wanneer een programma ze leest. Een chunk die niet te authenticeren is geeft een I/O-fout, nooit verkeerde gegevens. Als gewone gebruiker heeft het koppelen het pakket `fuse3` nodig.

## Windows

> **In deze release NIET getest op een echte Windows-machine.** Het Windows-programma is cross-gecompileerd en de back-up- en herstel-engine is dezelfde code die onder Linux wordt getest, maar alles wat specifiek is voor Windows is naar de documentatie geschreven en heeft nooit gedraaid. Probeer het eerst op een niet-kritieke machine.

```powershell
# in an elevated PowerShell
irm https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.ps1 -OutFile install.ps1    # read it, then:
.\install.ps1 -Role server -ExternalUrl https://backup.example.net:8007 -Datastore main=D:\Backups\main -Start
.\install.ps1 -Role client
```

Dezelfde opties bestaan als parameters (`-Channel`, `-Version`, `-BaseUrl`, `-InstallDir`, `-StateDir`, `-Listen`, `-NoInit`, `-Start`, `-NoFirewall`, `-Uninstall`, `-Purge`, `-Force`, `-Yes`, `-Lang`). Het script controleert de Ed25519-handtekening in pure PowerShell, installeert `toutwaf-backup.exe`, voegt het toe aan het systeem-PATH en beperkt voor de server de statusmap, installeert de Windows-service en een firewallregel (alleen profielen Domein en Privé). Wat verschilt van Linux:

* `client mount` bestaat alleen onder Linux; gebruik onder Windows `client ls`, `client find`, `client cat` en `client restore`.
* Een back-up vanaf een Volume Shadow Copy (`--vss`) is **niet getest en uitgeschakeld** tenzij de omgevingsvariabele `TWB_ENABLE_UNTESTED_VSS=1` is ingesteld.
* NTFS-beveiligingsdescriptors worden in elke back-up vastgelegd, maar het **herstellen** ervan is niet getest en uitgeschakeld tenzij `TWB_ENABLE_UNTESTED_WIN_ACL=1` is ingesteld. Lange paden, junctions, alternatieve gegevensstromen en EFS zijn niet getest of niet ondersteund.
* `install.ps1`, de handtekeningcontrole in pure PowerShell, de Windows-service, de firewallregel en het bestand voor Taakplanner dat `client schedule --target windows` maakt, zijn nooit onder Windows uitgevoerd.

## Bijwerken, terugdraaien, verwijderen

```sh
sudo ./install.sh --role server                         # run it again with the same options: upgrade
sudo mv /usr/local/bin/toutwaf-backup.prev /usr/local/bin/toutwaf-backup && sudo systemctl restart toutwaf-backup-server    # rollback
sudo ./install.sh --role server --uninstall            # keeps the data; add --purge to remove the configuration, the state and the user
```

Formaat 1 en API 1 zijn stabiel, dus servers en clients van verschillende 0.x-versies werken samen. Verwijderen laat de gegevens staan tenzij u `--purge` toevoegt; datastores buiten de statusmap worden nooit verwijderd.
