[English](../en/README.md) | [Français](../fr/README.md) | [Español](../es/README.md) | [Deutsch](../de/README.md) | [Italiano](../it/README.md) | [Português](../pt/README.md) | **Nederlands** | [Русский](../ru/README.md) | [中文](../zh/README.md) | [العربية](../ar/README.md)

# ToutWAF Backup

Een onafhankelijk back-upsysteem in één statisch programma: een **server** die ontdubbelde, gecomprimeerde, aan clientzijde versleutelde back-ups opslaat, een **client** die bestanden, mappen en databasedumps back-upt, een **webinterface** en een gedocumenteerde **koppeling met ToutWAF**. Het wordt op een eigen server geïnstalleerd en heeft niets van ToutWAF nodig om te werken.

* **Uw gegevens worden versleuteld voordat ze uw machine verlaten** (XChaCha20-Poly1305, sleutel afgeleid van uw wachtzin met Argon2id). De server heeft de sleutel nooit en kan geen bestandsnamen, inhoud of mapstructuur lezen.
* **Ontdubbeling en compressie**: op inhoud gebaseerde chunks, SHA-256-adressering, zstd. Een tweede back-up van ongewijzigde gegevens verstuurt niets; tussen clients die een sleutel delen worden dezelfde gegevens maar één keer opgeslagen.
* **Bestand tegen ransomware**: schrijftokens kunnen niet lezen of verwijderen; datastores en tokens kunnen *alleen toevoegen* zijn (uitschakelen vereist de servermachine zelf); een onveranderlijkheidsperiode; controle- en scrubtaken; externe kopieën; meldingen wanneer een back-up te laat is of een controle mislukt.
* **Complete client**: opname- en uitsluitregels, snelle incrementele back-ups, rechten, eigenaars, uitgebreide attributen en ACL's, `mysqldump | toutwaf-backup client backup --stdin`, pre- en postscripts, gedeeltelijk en geverifieerd herstel, `ls`, `find` en `cat` van elke snapshot zonder te herstellen, bandbreedtelimieten, het genereren van een systemd-timer of Windows-taak.
* **Quota en limieten**: bytequota per token en per naamruimte (zachte waarschuwing, harde weigering), aantallen snapshots en chunks, bandbreedtelimieten; zichtbaar in de interface, de API en op de opdrachtregel.
* **S3-back-ups als volwaardige functie** (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO, elke S3-compatibele dienst): een datastore **in een bucket** bewaren, een **externe kopie naar S3** van elke datastore plannen (bandbreedtelimiet, verificatie door terugleggen) en op een nieuwe server **hervatten vanuit S3** wanneer de oude verloren is. In de interface ingevoerde sleutels blijven op de server en worden nooit meer getoond; verbindingstest; optioneel Object Lock. Zie `S3.md`.
* **Een snapshot alleen-lezen koppelen** onder Linux (`client mount`, FUSE) en met gewone hulpmiddelen doorbladeren; gebruik onder Windows `ls`, `find`, `cat` en `restore`.
* **HTTPS- en HTTP/2-API** met tokens met beperkt bereik (admin, writer, reader, audit), vastgepind zelfondertekend certificaat, ratebeperking, hashgeketend auditlog, Prometheus-metrieken en health-endpoint.
* **Webinterface in tien talen** (Engels, Frans, Spaans, Duits, Italiaans, Portugees, Nederlands, Russisch, Chinees, Arabisch met rechts-naar-links-opmaak), licht en donker, bruikbaar met toetsenbord en schermlezer: datastores en gebruik, clients, snapshotbrowser met bestandsdownload, taken, controle, opschonen en ruimte-vrijgave, tokens, gebruikers, instellingen, audit. De opdrachtregel, de installatieprogramma's en de meldingen spreken dezelfde tien talen.

**Installatiebeleid.** ToutWAF Backup is optioneel. De **server draait op een andere machine dan ToutWAF** (de installatieprogramma's en `server run` weigeren anders): een back-up op de machine die hij beschermt overleeft het verlies van die machine niet. `--with-backup-client` aan de ToutWAF-kant installeert alleen de client. Releases zijn ondertekend met dezelfde Ed25519-sleutel als ToutWAF en gepubliceerd op de branch `toutwaf-backup` van de openbare ToutWAF-repository.

**Status: versie 0.1.2.** Alles is op Linux getest; niets is uitgevoerd op een echte Windows-machine, en S3 is getest tegen een in-proces nepservice, niet tegen een echte provider (zie `TESTING.md` in de Engelse documentatie). Geen beveiligingsaudit door derden. De licentie is nog niet gekozen.

## Snel aan de slag

```sh
# on the backup server
sudo ./install.sh --role server --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start
toutwaf-backup server token create --name web1 --role writer --datastore main --append-only

# on the machine to protect
sudo ./install.sh --role client
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --create-key
toutwaf-backup client backup --path /etc --path /var/www --id web1
toutwaf-backup client snapshots
toutwaf-backup client restore host/web1/latest --target /tmp/restore --verify
```

`toutwaf-backup --help` en `toutwaf-backup <opdracht> --help` documenteren elke optie, in de taal van uw systeem (of `--lang fr`, `--lang es` ...).

## Documentatie

| Pagina | Inhoud |
|---|---|
| [INSTALL.md](INSTALL.md) | installatie onder Linux en Windows, eerste stappen, bijwerken |
| [S3.md](S3.md) | S3-objectopslag: datastore in een bucket, externe kopie, hervatten, sleutels, Object Lock |
| [RESTORE.md](RESTORE.md) | herstel en noodherstelprocedure, de oefening |
| [SECURITY.md](SECURITY.md) | wat de server wel en niet kan zien, bedreigingsmodel, sleutels |
| [TOUTWAF-LINK.md](TOUTWAF-LINK.md) | koppeling met een ToutWAF-console, lokale of S3-datastore per machine |
| [Engelse documentatie](../../) | de volledige referentie: repositoryformaat, API, prestaties, tests |

## Talen

Deze pagina's bestaan in tien talen. De vertalingen zijn door een machine geschreven en **niet door moedertaalsprekers nagelezen**: als een zin vreemd klinkt of een detail afwijkt, geldt de Engelse documentatie in `docs/`. Correcties zijn welkom.
