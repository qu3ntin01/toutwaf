[English](../en/TOUTWAF-LINK.md) | [Français](../fr/TOUTWAF-LINK.md) | [Español](../es/TOUTWAF-LINK.md) | [Deutsch](../de/TOUTWAF-LINK.md) | [Italiano](../it/TOUTWAF-LINK.md) | [Português](../pt/TOUTWAF-LINK.md) | **Nederlands** | [Русский](../ru/TOUTWAF-LINK.md) | [中文](../zh/TOUTWAF-LINK.md) | [العربية](../ar/TOUTWAF-LINK.md)

# De koppeling met ToutWAF

ToutWAF Backup werkt zelfstandig. Met de koppeling kan een ToutWAF-console een back-upserver gebruiken: ze maakt de datastore en de beperkte tokens voor elke ToutWAF-machine aan, plant back-ups, controleert en herstelt ze, en ontvangt foutmeldingen. Het contract heeft een versie (`toutwaf-backup-link/1`) en is volledig gedocumenteerd in de Engelse `docs/TOUTWAF-LINK.md`; deze pagina is het gebruikersperspectief. **De sleutel blijft op de ToutWAF-machine**: de back-upserver en het koppelingstoken kunnen niets ontsleutelen.

## Koppelen

Maak in de ToutWAF-console een **koppeltoken** voor eenmalig gebruik aan ("back-upserver toevoegen") en voer op de back-upserver uit:

```sh
toutwaf-backup link --toutwaf https://waf.example.net --token <pairing token> --url https://backup.example.net:8007
toutwaf-backup link --status
toutwaf-backup link --remove
```

De opdracht maakt een koppelingstoken met beheerdersbereik, stuurt het met het adres van de server en de vingerafdruk van zijn certificaat naar ToutWAF en legt de koppeling vast; weigert ToutWAF, dan wordt het token weer ingetrokken en blijft er niets achter. De koppeling wordt geweigerd als de back-upserver en ToutWAF op dezelfde machine draaien. ToutWAF moet de vingerafdruk de eerste keer langs een ander kanaal controleren.

## Wat de ToutWAF-console dan kan doen

* Voor elke ToutWAF-machine een datastore en een **writer**-token (alleen toevoegen, beperkt tot één datastore en één naamruimte) aanmaken, plus een optioneel **reader**-token voor herstel.
* Quota en bandbreedtelimieten instellen op de tokens die ze inricht, en het gebruik uitlezen.
* De serverstatus lezen (gezondheid, gebruik, meldingen, laatste back-up van elke groep), snapshots tonen en bekijken.
* De controle van een snapshot of datastore starten (zonder sleutel) en volgen als taak.
* Ondertekende gebeurtenissen ontvangen: mislukte taak, mislukte controle, te late back-up, quotumwaarschuwing. Herstel draait op de ToutWAF-machine, die de sleutel heeft.

## Lokale of S3-datastore, per machine te kiezen

De console kiest met de velden `backend`, `s3` en `s3_auth` van `POST /api/v1/link/provision` waar de back-ups van elke machine staan, en kan met `offsite_s3` ook een externe kopie naar een bucket plannen. Alleen `name` is vereist; `backend` is standaard een lokale datastore. De sleutels in `s3_auth` zijn alleen schrijfbaar: op de server opgeslagen, nooit teruggegeven of gelogd.

```json
POST /api/v1/link/provision
{"name":"toutwaf-prod","datastore":"toutwaf","namespace":"toutwaf-prod","append_only":true,"require_encryption":true,
 "backend":"s3",
 "s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-backups","prefix":"toutwaf-prod","addressing":"auto",
       "object_lock_mode":"","object_lock_days":0,"storage_class":""},
 "s3_auth":{"access_key_id":"...","secret_access_key":"...","session_token":"","ca_pem":""},
 "offsite_s3":{"s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-offsite","prefix":"toutwaf-prod"},"s3_auth":{"access_key_id":"...","secret_access_key":"..."},
               "schedule":"every 6h","bandwidth_bps":0,"verify_after":true}}
```

* `backend`: `files` (lokaal, standaard) of `s3`.
* `s3`: provider, regio, bucket, prefix, adressering, Object Lock-modus en -dagen, opslagklasse; `s3_auth`: toegangssleutel, geheime sleutel, optioneel sessietoken en privé-CA.
* `offsite_s3`: dezelfde `s3` en `s3_auth` voor de doelbucket, plus `schedule`, `bandwidth_bps` en `verify_after` (standaard waar); het maakt een taak `offsite-<datastore>` aan.
* Het antwoord bevat `backend`, `s3` (wat wordt getoond, nooit een geheim) en `offsite_job`. Een ongeldige bucket of verkeerde sleutels geven `400` en er wordt niets aangemaakt; een ander backend vragen dan dat van een bestaande datastore met dezelfde naam geeft `409`. Met `POST /api/v1/storage/test` kan de console eerst een bucket testen, en `POST /api/v1/datastores/import-s3` bouwt na totaal verlies een datastore opnieuw op uit een bucket.

## Eerlijke stand van zaken

Koppeling, inrichting, status, ondertekende gebeurtenissen en S3-velden zijn end-to-end getest tegen een nagemaakte ToutWAF-console. **Niet getest: een echte ToutWAF-console**, die haar kant nog niet implementeert; en S3 alleen tegen een in-proces nepservice, niet tegen een echte provider.
