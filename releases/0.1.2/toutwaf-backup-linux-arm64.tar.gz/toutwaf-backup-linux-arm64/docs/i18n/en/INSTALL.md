**English** | [Français](../fr/INSTALL.md) | [Español](../es/INSTALL.md) | [Deutsch](../de/INSTALL.md) | [Italiano](../it/INSTALL.md) | [Português](../pt/INSTALL.md) | [Nederlands](../nl/INSTALL.md) | [Русский](../ru/INSTALL.md) | [中文](../zh/INSTALL.md) | [العربية](../ar/INSTALL.md)

# Installation

Supported: Linux (amd64 and arm64, with systemd) and Windows (amd64, **not tested on a real Windows machine**). The Linux installer needs `bash`, `curl` or `wget`, `tar`, `sha256sum`, `base64` and **OpenSSL 3** to verify the signature. The binary itself is one static file.

## Where the server goes (read this first)

Installing ToutWAF Backup is **optional**. The **server must run on a different machine than ToutWAF**: a backup stored on the machine it protects does not survive the loss of that machine (disk failure, ransomware, fire, theft). `install.sh --role server` and `install.ps1 -Role server` look for ToutWAF on the host and **refuse**, with exit status 3, if they find it; `toutwaf-backup server run` makes the same check at start-up. The client role is never refused.

## Install on Linux

```sh
# server (the machine that stores the backups)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role server \
    --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start

# client (every machine to protect)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role client
```

The installer downloads `channel.json`, then `SHA256SUMS` and its signature; it **verifies the Ed25519 signature** with the public key baked into the script, then the **SHA-256 of the archive** against the signed list, and refuses a withdrawn version. It installs `toutwaf-backup` atomically (the previous binary is kept as `toutwaf-backup.prev`). For the server role it also creates the system user, the state directory, the systemd unit and, on the first install, the configuration: it prints the first admin token (once) and the certificate fingerprint. Nothing starts unless you pass `--start`. It is idempotent: run it again to upgrade.

**Language of the installers.** `install.sh` and `install.ps1` speak the ten languages: they follow `--lang fr` (or `--fr`, `--es`, `--de` ...; `-Lang fr` on Windows), then `TWB_LANG`, then the system language (`LC_ALL`, `LANG`; the Windows display language), then English. Accents and non-Latin scripts need a UTF-8 terminal; otherwise the installer speaks English. Option names, commands and file names are never translated.

## Server: first steps

```sh
systemctl enable --now toutwaf-backup-server       # if you did not pass --start
toutwaf-backup server token create --name web1 --role writer --datastore main --namespace hosts/web1 --append-only
toutwaf-backup server datastore set main --require-encryption=true --quota 2T --immutable-days 7
```

* Open the port (8007 by default) to your clients only. The web interface is `https://HOST:8007/` (sign in with the admin token). The certificate is self-signed, so browsers warn: compare the fingerprint shown in **Settings** with `toutwaf-backup server fingerprint`.
* Create one token per client and never share the admin token. A `writer` token can back up but cannot read or delete.
* *Append-only* on a datastore means nobody can delete through the API; switching it off needs `toutwaf-backup server datastore set main --append-only=false` on the server machine itself.
* Schedule the server's own chores in the web interface (**Jobs**): a weekly verification, a daily prune (not on an append-only datastore), a weekly garbage collection, and an offsite copy to a second server, a disk or an S3 bucket. Notifications (e-mail, signed webhooks) are in **Settings**.
* Back up the server's own state (`/var/lib/toutwaf-backup`: configuration, tokens, TLS key, audit log) with a client to another server. Losing the TLS key means every client must pin the new fingerprint.

## Client: first steps

```sh
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --namespace hosts/web1 --create-key
toutwaf-backup client backup --path /etc --path /var/www --id $(hostname) --one-file-system --exclude '*.tmp'
toutwaf-backup client snapshots
toutwaf-backup client schedule --daily 02:30 --id $(hostname) --path /etc --path /var/www --install
systemctl daemon-reload && systemctl enable --now toutwaf-backup-$(hostname).timer
```

`client init --create-key` shows the server fingerprint for you to confirm, writes the profile and creates the key file, then prints the **paper key**. **Store the key file, its passphrase and the paper key away from the machine**: without them nobody can restore (see `RESTORE.md`). For unattended runs put the passphrase in a file readable only by root and reference it in the profile. Exit status: 0 success, 1 failure (nothing committed), 2 committed with warnings. Databases need no temporary file:

```sh
mysqldump --single-transaction shop | toutwaf-backup client backup --type db --id shop --stdin --stdin-name shop.sql
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop
```

## S3 object storage

A datastore can keep its chunks in an S3-compatible bucket (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO), and any datastore can be copied to a bucket on a schedule. In the web interface: Datastores, *Create a datastore*, **S3 object storage**, then *Test the connection*. The complete guide, the command line and the recovery procedure are in [S3.md](S3.md).

## Mount a snapshot (Linux)

```sh
toutwaf-backup client mount host/web1/latest /mnt/snap        # read-only; Ctrl-C or: fusermount3 -u /mnt/snap
```

The snapshot appears as a read-only directory tree: nothing is restored; a file's chunks are downloaded, decrypted and authenticated only when a program reads them. A chunk that cannot be authenticated gives an I/O error, never wrong data. As a normal user the mount needs the `fuse3` package.

## Windows

> **NOT TESTED on a real Windows machine in this release.** The Windows binary is cross-compiled and the backup and restore engine is the same code that is tested on Linux, but everything specific to Windows was written against the documentation and has never run. Try it on a non-critical machine first.

```powershell
# in an elevated PowerShell
irm https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.ps1 -OutFile install.ps1    # read it, then:
.\install.ps1 -Role server -ExternalUrl https://backup.example.net:8007 -Datastore main=D:\Backups\main -Start
.\install.ps1 -Role client
```

The same options exist as parameters (`-Channel`, `-Version`, `-BaseUrl`, `-InstallDir`, `-StateDir`, `-Listen`, `-NoInit`, `-Start`, `-NoFirewall`, `-Uninstall`, `-Purge`, `-Force`, `-Yes`, `-Lang`). The script verifies the Ed25519 signature in pure PowerShell, installs `toutwaf-backup.exe`, adds it to the system PATH and, for the server, restricts the state directory, installs the Windows service and a firewall rule (Domain and Private profiles only). What differs from Linux:

* `client mount` is Linux only; on Windows use `client ls`, `client find`, `client cat` and `client restore`.
* Backing up from a Volume Shadow Copy (`--vss`) is **untested and disabled** unless the environment variable `TWB_ENABLE_UNTESTED_VSS=1` is set.
* NTFS security descriptors are recorded in every backup, but **restoring** them is untested and disabled unless `TWB_ENABLE_UNTESTED_WIN_ACL=1` is set. Long paths, junctions, alternate data streams and EFS are untested or not handled.
* `install.ps1`, its pure-PowerShell signature check, the Windows service, the firewall rule and the Task Scheduler file made by `client schedule --target windows` have never been run on Windows.

## Upgrade, rollback, uninstall

```sh
sudo ./install.sh --role server                         # run it again with the same options: upgrade
sudo mv /usr/local/bin/toutwaf-backup.prev /usr/local/bin/toutwaf-backup && sudo systemctl restart toutwaf-backup-server    # rollback
sudo ./install.sh --role server --uninstall            # keeps the data; add --purge to remove the configuration, the state and the user
```

Format 1 and API 1 are stable, so servers and clients of different 0.x versions interoperate. Uninstalling keeps the data unless you add `--purge`; datastores outside the state directory are never deleted.
