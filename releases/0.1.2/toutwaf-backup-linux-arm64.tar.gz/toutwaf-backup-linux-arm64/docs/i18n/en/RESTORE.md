**English** | [Français](../fr/RESTORE.md) | [Español](../es/RESTORE.md) | [Deutsch](../de/RESTORE.md) | [Italiano](../it/RESTORE.md) | [Português](../pt/RESTORE.md) | [Nederlands](../nl/RESTORE.md) | [Русский](../ru/RESTORE.md) | [中文](../zh/RESTORE.md) | [العربية](../ar/RESTORE.md)

# Restore and disaster-recovery runbook

A backup you have never restored is a hope. Read this once **before** you need it, and do the drill at the end at least every quarter.

## What you must have, and where to keep it

| Item | Why, and where to keep it |
|---|---|
| The **key file** and its **passphrase** | decrypt everything; keep them in a password manager or vault, not only on the machine being backed up |
| The **paper key** printed by `client key create` | rebuilds the key file if the file or the passphrase is lost; print it and keep it in a safe |
| The **server fingerprint** and a *reader* (or admin) token | to reach the server; a reader token can be created again on the server |
| This page and the `toutwaf-backup` binary for your system | the tool; keep a copy on a USB stick, it is one static file |

If you have none of the key file, the passphrase and the paper key, **the data cannot be recovered by anyone.** That is the price of a server that never holds a key.

## Restore a file or a directory (everyday)

```sh
toutwaf-backup client snapshots --type host --id web1                         # find the snapshot
toutwaf-backup client ls host/web1/latest etc/nginx                            # look inside, no restore needed
toutwaf-backup client find host/web1/latest '*.conf'
toutwaf-backup client restore host/web1/20261023T023000Z --path etc/nginx --target /tmp/restore --verify
toutwaf-backup client cat host/web1/latest etc/hostname                        # one file to standard output
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop                 # a database dump straight into its importer
```

Paths are the ones shown by `ls` (no leading slash); a source path `/etc/nginx` is restored at `<target>/etc/nginx`. Existing files are **never overwritten** unless you pass `--overwrite`. `client browse` opens a local web page (127.0.0.1) to browse and download.

## Restore a whole machine

The tool backs up **files and system information, not disk images**: it does not recreate partitions, boot loaders or the operating system. Rebuild the base system first, then restore the data.

1. Install the operating system (the same distribution if you can) and set the host name and the network.
2. Install the client (`install.sh --role client`, or copy the binary).
3. Recreate the connection and the key: with only the paper key use `client key import-paper` (it checks every line and asks for a new passphrase), then `client init`.
4. Look at what the host was (`.twb-meta/system.json`: host name, kernel, mounts, installed packages).
5. Restore into a staging directory first, or straight onto the root; run as root to restore owners, extended attributes, ACLs, device nodes and FIFOs.
6. Reinstall the boot loader and the packages if the root is new, reboot, check the services, then run a fresh backup: it deduplicates against the old ones.

```sh
toutwaf-backup client key import-paper --keyfile /root/key.json < paper.txt        # only if the key file or the passphrase is lost
toutwaf-backup client init --server https://backup.example.net:8007 --fingerprint <hex> --token <reader token> --datastore main --namespace hosts/web1 --keyfile /root/key.json
toutwaf-backup client cat host/web1/latest .twb-meta/system.json                   # what the host was (when saved with --system-info)
toutwaf-backup client restore host/web1/latest --target /mnt/newroot --verify      # a new root mounted at /mnt/newroot
toutwaf-backup client restore host/web1/latest --target / --overwrite --verify     # in place, replaces files
```

## The key file or the passphrase is lost

* Passphrase lost, **paper key kept**: `client key import-paper --keyfile new.json < paper.txt`, set a new passphrase, update the profile.
* Key file lost, passphrase kept: use the paper key as above. Without it nothing can be done. An **escrow copy** (`client key escrow`) opens with its own passphrase.
* Afterwards rotate the passphrase with `client key change-passphrase`. **If all three are lost, the backups are unreadable, by design.**

## The backup server is lost

1. Get the data back: the disk, a restored copy, or the **offsite copy** that a sync job pushed to a second server or disk. The datastore directory is self-describing.
2. On a new machine: `install.sh --role server --no-init`, then `toutwaf-backup server init --state /var/lib/toutwaf-backup --listen :8007 --external-url https://... --datastore main=/path/to/recovered/datastore` (an existing directory is adopted, nothing is rewritten). Note the new admin token and the **new certificate fingerprint**.
3. Create tokens for your clients (`server token create`) and run `client init` again with the new fingerprint.
4. Check with `toutwaf-backup server verify --datastore main --scrub`, restore one file with a client, and create the offsite job again.

## The server and its disk are lost, and the copy is in an S3 bucket

If an *Offsite copy to S3* job ran (or the datastore itself lives in a bucket), the bucket holds everything but the key: the chunks, and in `meta/` the settings and the list of snapshots. You need the bucket, the prefix of the copy (`offsite-<job id>` unless you chose another), S3 keys that can read it, and your key file or **paper key**. On the new server, in the web interface (Datastores, *Create a datastore*, **Resume from S3**) or on the command line:

```sh
printf '{"access_key_id":"...","secret_access_key":"..."}' | toutwaf-backup datastore import-s3 main \
  --s3-credentials-stdin --s3-bucket my-backups --s3-provider wasabi --s3-region eu-central-1 --s3-prefix offsite-main
```

A wrong or empty prefix is refused ("the bucket holds no metadata mirror") and nothing is created. Then create tokens and run `client init` again, restore with `client restore`, and create the offsite job again (it adopts the copy already in the bucket if you give the same bucket and prefix). [S3.md](S3.md) describes the three S3 features.

## The datastore is damaged (bit rot, partial disk failure)

```sh
toutwaf-backup server verify --datastore main --scrub     # reads every snapshot and chunk file; damaged chunks are moved aside, never deleted
toutwaf-backup client verify host/web1/latest --read-data  # needs the key: proves every chunk decrypts and matches its id
```

A **missing or damaged** chunk makes the snapshots that use it fail verification. The next backup of the same data uploads the chunk again and the datastore heals itself; older snapshots that needed a chunk the live data no longer contains stay damaged: restore them from the replica (a `pull` sync copies only what is missing) or accept the loss for those files. Restore tells you exactly which files it could not restore (exit status 1); the rest is restored.

## The drill (do it, then write the date down)

1. On a spare machine (or a temporary directory) with **only** the documented secrets: key file or paper key, passphrase, token, fingerprint.
2. `client restore <important group>/latest --target /tmp/drill --verify`, open a few files; for a database, import the dump into a scratch instance.
3. `client verify <snapshot> --read-data` proves that every chunk decrypts and matches its id.
4. Time it (a restore at 70 MiB/s takes about 4 hours per terabyte), note anything that surprised you, and fix this runbook.
