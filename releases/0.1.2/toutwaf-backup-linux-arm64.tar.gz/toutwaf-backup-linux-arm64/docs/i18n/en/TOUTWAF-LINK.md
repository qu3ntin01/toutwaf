**English** | [Français](../fr/TOUTWAF-LINK.md) | [Español](../es/TOUTWAF-LINK.md) | [Deutsch](../de/TOUTWAF-LINK.md) | [Italiano](../it/TOUTWAF-LINK.md) | [Português](../pt/TOUTWAF-LINK.md) | [Nederlands](../nl/TOUTWAF-LINK.md) | [Русский](../ru/TOUTWAF-LINK.md) | [中文](../zh/TOUTWAF-LINK.md) | [العربية](../ar/TOUTWAF-LINK.md)

# The ToutWAF link

ToutWAF Backup works on its own. The link lets a ToutWAF console use a backup server: it creates the datastore and the restricted tokens for each ToutWAF machine, schedules backups, checks and restores them, and receives failure alerts. The contract is versioned (`toutwaf-backup-link/1`) and documented in full in the English `docs/TOUTWAF-LINK.md`; this page is the user's view. **The key stays on the ToutWAF machine**: the backup server and the link token cannot decrypt anything.

## Pairing

In the ToutWAF console create a one-time **pairing token** ("add a backup server"), then run on the backup server:

```sh
toutwaf-backup link --toutwaf https://waf.example.net --token <pairing token> --url https://backup.example.net:8007
toutwaf-backup link --status
toutwaf-backup link --remove
```

The command creates an admin-scoped link token, sends it to ToutWAF with the server's address and certificate fingerprint, and records the pairing; if ToutWAF refuses, the token is revoked again and nothing is left behind. The pairing is refused when the backup server and ToutWAF run on the same machine. ToutWAF must verify the fingerprint out of band the first time.

## What the ToutWAF console can then do

* Create, for each ToutWAF machine, a datastore and a **writer** token (append-only, confined to one datastore and one namespace) and an optional **reader** token for restores.
* Set quotas and bandwidth caps on the tokens it provisions, and read usage.
* Read the server status (health, usage, alerts, last backup of each group), list and inspect snapshots.
* Start a verification of a snapshot or a datastore (no key needed) and follow it as a task.
* Receive signed events: failed job, failed verification, stale backup, quota warning. Restores run on the ToutWAF machine, which holds the key.

## Local or S3 datastore, chosen per machine

The console chooses where each machine's backups live with the fields `backend`, `s3` and `s3_auth` of `POST /api/v1/link/provision`, and can also schedule an offsite copy to a bucket with `offsite_s3`. Only `name` is required; `backend` defaults to a local datastore. The keys in `s3_auth` are write-only: stored on the server, never returned or logged.

```json
POST /api/v1/link/provision
{"name":"toutwaf-prod","datastore":"toutwaf","namespace":"toutwaf-prod","append_only":true,"require_encryption":true,
 "backend":"s3",
 "s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-backups","prefix":"toutwaf-prod","addressing":"auto",
       "object_lock_mode":"","object_lock_days":0,"storage_class":""},
 "s3_auth":{"access_key_id":"...","secret_access_key":"...","session_token":"","ca_pem":""},
 "offsite_s3":{"s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-offsite","prefix":"toutwaf-prod"},"s3_auth":{"access_key_id":"...","secret_access_key":"..."},
               "schedule":"every 6h","bandwidth_bps":0,"verify_after":true}}
```

* `backend`: `files` (local, the default) or `s3`.
* `s3`: provider, region, bucket, prefix, addressing, Object Lock mode and days, storage class; `s3_auth`: access key, secret key, optional session token and private CA.
* `offsite_s3`: the same `s3` and `s3_auth` of the destination bucket, plus `schedule`, `bandwidth_bps` and `verify_after` (true by default); it creates a job `offsite-<datastore>`.
* The answer carries `backend`, `s3` (what is shown, never a secret) and `offsite_job`. A bad bucket or wrong keys is a `400` and nothing is created; asking for another backend than an existing datastore of the same name is a `409`. `POST /api/v1/storage/test` lets the console test a bucket first, and `POST /api/v1/datastores/import-s3` rebuilds a datastore from a bucket after a total loss.

## Honest status

The pairing, the provisioning, the status, the signed events and the S3 fields are tested end to end against a fake ToutWAF console. **Not tested: a real ToutWAF console**, which does not implement its side yet; and S3 only against an in-process fake, not a real provider.
