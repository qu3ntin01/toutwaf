**English** | [Français](../fr/SECURITY.md) | [Español](../es/SECURITY.md) | [Deutsch](../de/SECURITY.md) | [Italiano](../it/SECURITY.md) | [Português](../pt/SECURITY.md) | [Nederlands](../nl/SECURITY.md) | [Русский](../ru/SECURITY.md) | [中文](../zh/SECURITY.md) | [العربية](../ar/SECURITY.md)

# Security model (summary)

This is a summary. The complete threat model, the cryptography and the repository format are in the English documentation (`docs/SECURITY.md`, `docs/ARCHITECTURE.md`). **No third party has audited this software.**

## What the server can and cannot see

| The server can see | The server cannot see |
|---|---|
| that a client with a valid token exists, its address, when it connects | the key, the passphrase, the contents of any file |
| the backup group name (for example `host/web1`), the namespace, snapshot times, total sizes and file counts, the size and number of stored chunks | file names, the directory structure, sizes of individual files, owners, permissions, which chunk belongs to which file, whether two files share content |
| that two snapshots share chunks (same key) | anything that would let it test a guess of your plaintext: chunk ids are keyed (HMAC), the chunk boundaries are keyed too |

Size and timing leak by design: an observer of the server or the network learns how much changed and when. With `--no-encrypt` everything is readable by the server; a datastore can be set to `require_encryption` so that plaintext is refused.

## Threat model

| Adversary | What they get, and why |
|---|---|
| Network observer or man in the middle | only sizes and timing: TLS, and the client pins the server certificate fingerprint; another certificate is refused before a byte is sent |
| Stolen backup disk, or read access to the server | ciphertext, group names, sizes and timing: the key never reaches the server |
| Server compromise with write access | can delete or withhold backups (availability); cannot forge, alter or splice snapshots undetected: every chunk is authenticated with its id and every manifest is sealed with the key |
| Compromised client | can upload junk, but cannot delete or overwrite existing backups if its token is a writer token (or the datastore is append-only); a client that holds the key can read its own backups |
| Compromised admin token | can change settings and tokens, but cannot delete from an append-only datastore, switch append-only off or shorten the immutability period: those settings change only on the server machine itself; every action is in the hash-chained audit log |
| Ransomware, or root on the server machine | ransomware on a client encrypts the live data, not the backups; root on the server can delete everything (availability): keep an offsite copy (a second server, a disk or an S3 bucket with Object Lock) for ransomware-grade guarantees |

**Not defended against:** a server that hides your newest snapshots (compare `client snapshots` with your own records, or alert on stale backups); loss of the key; a malicious client talking to a datastore that does not require encryption; a writer filling the disk (set a quota); physical access to the machine that holds both the key file and the passphrase.

## Cryptography

Passphrase to key: **Argon2id**. Authenticated encryption: **XChaCha20-Poly1305** (random 192-bit nonce). Subkeys: **HKDF-SHA-256**. Chunk ids: HMAC-SHA-256 under a subkey (SHA-256 when not encrypted). TLS 1.2 or newer with a self-signed ECDSA P-256 certificate; release signatures are Ed25519. Nothing is home-made; the format is described so that it can be audited.

## Key management

* `client key create` makes the key file and prints the **paper key**. The key file is safe to copy (it reveals nothing without the passphrase); the paper key is the plaintext master key: print it, put it in a safe, never on the same machine as the data.
* `client key change-passphrase` re-wraps the same master key (old copies of the key file still open with the old passphrase: destroy them). `client key escrow` writes the key wrapped under a second, separate passphrase for a trustee.
* Lost key file and passphrase but the paper key kept: `client key import-paper` rebuilds a key file. **All three lost: the backups are unreadable, by design.**
* To replace the master key (after a suspected compromise), create a new key and take new backups: they do not deduplicate against the old ones, which stay readable with the old key until pruned. Test recovery, not just backup: the drill is in [RESTORE.md](RESTORE.md).

## API tokens and roles

| Role | Can / cannot |
|---|---|
| **admin** | everything, including tokens, datastores, jobs and settings; cannot switch append-only off or shorten the immutability period (server machine only) |
| **writer** | checks and uploads chunks, commits snapshots, lists; cannot read chunks, delete or prune (unless allowed, and then only its own snapshots, never on append-only) |
| **reader** | lists, reads chunks and indexes, browses and downloads unencrypted snapshots; cannot write |
| **audit** | reads snapshot metadata, the audit log, metrics, alerts and task state; cannot read chunk data or change anything |

## Operations

* **The server never runs on the machine it protects, nor next to ToutWAF.** The installers and `server run` refuse it, and the pairing contract carries a hash of the machine id so that ToutWAF and the server both refuse a same-machine pairing. A laboratory override exists; it must not be used in production.
* Quotas (hard and soft byte limits, snapshot and chunk counts, bandwidth caps) per token and per namespace make a fairness tool, not a security boundary against a token that holds its own client key.
* S3 credentials live in the server's environment, in a file only the service can read, or (typed in the interface or sent by the ToutWAF console) in `<state>/secrets/s3/` with mode 0600. They are write-only: never in a configuration file, a mirror in the bucket, an API response, a page, the audit log, a log line or a command-line argument. The state directory is therefore a secret. With Object Lock in Compliance mode and an append-only datastore, even a stolen S3 key cannot delete chunks before their retention ends. See [S3.md](S3.md).
* The service runs as an unprivileged user with a hardened systemd unit; the port is opened to your clients only. Per-address rate limiting and authentication lockout are on by default; the audit log is hash-chained (`server audit-verify` finds any edit). The web interface sets a strict Content-Security-Policy with no inline script and no external origin.

## Reporting a vulnerability

Report a vulnerability privately to the owner of the ToutWAF project (see the repository contact); do not open a public issue.
