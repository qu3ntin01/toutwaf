[English](../en/README.md) | [Français](../fr/README.md) | [Español](../es/README.md) | [Deutsch](../de/README.md) | **Italiano** | [Português](../pt/README.md) | [Nederlands](../nl/README.md) | [Русский](../ru/README.md) | [中文](../zh/README.md) | [العربية](../ar/README.md)

# ToutWAF Backup

Un sistema di backup indipendente in un unico binario statico: un **server** che archivia backup deduplicati, compressi e cifrati lato client, un **client** che salva file, directory e dump di database, un'**interfaccia web** e un **collegamento documentato con ToutWAF**. Si installa sul proprio server e non ha bisogno di nulla da ToutWAF per funzionare.

* **I tuoi dati sono cifrati prima di lasciare la tua macchina** (XChaCha20-Poly1305, chiave derivata dalla tua passphrase con Argon2id). Il server non ha mai la chiave e non può leggere né i nomi dei file, né i contenuti, né la struttura.
* **Deduplicazione e compressione**: chunk delimitati dal contenuto, indirizzamento SHA-256, zstd. Un secondo backup di dati invariati non invia nulla; tra client che condividono una chiave lo stesso dato è archiviato una sola volta.
* **Resistente al ransomware**: i token di scrittura non possono né leggere né cancellare; datastore e token possono essere in *sola aggiunta* (per disattivarlo serve la macchina del server stessa); un periodo di immutabilità; job di verifica e di scrub; copie fuori sede; notifiche quando un backup è in ritardo o un controllo fallisce.
* **Client completo**: regole di inclusione ed esclusione, incrementale veloce, permessi, proprietari, attributi estesi e ACL, `mysqldump | toutwaf-backup client backup --stdin`, script prima e dopo, ripristino parziale e verificato, `ls`, `find` e `cat` di qualsiasi snapshot senza ripristinare, limiti di banda, generazione di timer systemd o attività Windows.
* **Quote e limiti**: quote di byte per token e per spazio dei nomi (avviso morbido, rifiuto rigido), numero di snapshot e di chunk, limiti di banda; visibili nell'interfaccia, nell'API e da riga di comando.
* **Backup su S3 di prima classe** (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO, qualsiasi servizio compatibile S3): tenere un datastore **in un bucket**, pianificare una **copia fuori sede su S3** di qualsiasi datastore (limite di banda, verifica per rilettura) e **riprendere da S3** su un nuovo server quando il vecchio è perso. Le chiavi digitate nell'interfaccia restano sul server e non vengono più mostrate; test di connessione; Object Lock opzionale. Vedi `S3.md`.
* **Montare uno snapshot** in sola lettura su Linux (`client mount`, FUSE) e sfogliarlo con gli strumenti di sempre; su Windows usa `ls`, `find`, `cat` e `restore`.
* **API HTTPS e HTTP/2** con token a portata limitata (admin, writer, reader, audit), certificato autofirmato fissato, limitazione delle richieste, registro di audit concatenato con hash, metriche Prometheus, endpoint di salute.
* **Interfaccia web in dieci lingue** (inglese, francese, spagnolo, tedesco, italiano, portoghese, olandese, russo, cinese, arabo con layout da destra a sinistra), chiara e scura, utilizzabile con la tastiera e con lo screen reader: datastore e utilizzo, client, navigatore di snapshot con download dei file, job, verifica, potatura e recupero dello spazio, token, utenti, impostazioni, audit. La riga di comando, gli installer e le notifiche parlano le stesse dieci lingue.

**Politica di installazione.** ToutWAF Backup è opzionale. Il **server gira su una macchina diversa da quella di ToutWAF** (gli installer e `server run` altrimenti rifiutano): un backup archiviato sulla macchina che protegge non sopravvive alla perdita di quella macchina. `--with-backup-client` sul lato ToutWAF installa solo il client. Le release sono firmate con la stessa chiave Ed25519 di ToutWAF e pubblicate sul ramo `toutwaf-backup` del repository pubblico di ToutWAF.

**Stato: versione 0.1.2.** Tutto è stato testato su Linux; nulla è stato eseguito su una vera macchina Windows, e S3 è stato testato contro un finto S3 in memoria, non contro un vero provider (vedi `TESTING.md` nella documentazione inglese). Nessun audit di sicurezza di terze parti. La licenza non è ancora scelta.

## Avvio rapido

```sh
# on the backup server
sudo ./install.sh --role server --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start
toutwaf-backup server token create --name web1 --role writer --datastore main --append-only

# on the machine to protect
sudo ./install.sh --role client
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --create-key
toutwaf-backup client backup --path /etc --path /var/www --id web1
toutwaf-backup client snapshots
toutwaf-backup client restore host/web1/latest --target /tmp/restore --verify
```

`toutwaf-backup --help` e `toutwaf-backup <comando> --help` documentano ogni opzione, nella lingua del tuo sistema (oppure `--lang fr`, `--lang es` ...).

## Documentazione

| Pagina | Contenuto |
|---|---|
| [INSTALL.md](INSTALL.md) | installazione su Linux e Windows, primi passi, aggiornamento |
| [S3.md](S3.md) | archiviazione a oggetti S3: datastore in un bucket, copia fuori sede, ripresa, chiavi, Object Lock |
| [RESTORE.md](RESTORE.md) | ripristino e procedura di disaster recovery, l'esercitazione |
| [SECURITY.md](SECURITY.md) | cosa il server può e non può vedere, modello di minaccia, chiavi |
| [TOUTWAF-LINK.md](TOUTWAF-LINK.md) | abbinamento con una console ToutWAF, datastore locale o S3 per macchina |
| [Documentazione in inglese](../../) | il riferimento completo: formato del repository, API, prestazioni, test |

## Lingue

Queste pagine esistono in dieci lingue. Le traduzioni sono state scritte da una macchina e **non sono state riviste da madrelingua**: se una frase suona strana o un dettaglio differisce, fa fede la documentazione inglese in `docs/`. Le correzioni sono benvenute.
