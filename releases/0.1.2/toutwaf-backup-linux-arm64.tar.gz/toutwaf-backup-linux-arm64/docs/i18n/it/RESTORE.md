[English](../en/RESTORE.md) | [Français](../fr/RESTORE.md) | [Español](../es/RESTORE.md) | [Deutsch](../de/RESTORE.md) | **Italiano** | [Português](../pt/RESTORE.md) | [Nederlands](../nl/RESTORE.md) | [Русский](../ru/RESTORE.md) | [中文](../zh/RESTORE.md) | [العربية](../ar/RESTORE.md)

# Ripristino e procedura di disaster recovery

Un backup che non hai mai ripristinato è solo una speranza. Leggi questo una volta **prima** di averne bisogno e fai l'esercitazione finale almeno ogni trimestre.

## Cosa devi avere e dove conservarlo

| Elemento | Perché e dove conservarlo |
|---|---|
| Il **file della chiave** e la sua **passphrase** | decifrano tutto; conservali in un gestore di password o in una cassaforte, non solo sulla macchina di cui si fa il backup |
| La **chiave su carta** stampata da `client key create` | ricostruisce il file della chiave se il file o la passphrase vanno persi; stampalo e conservalo in una cassaforte |
| L'**impronta del server** e un token *reader* (o admin) | per raggiungere il server; un token reader può essere ricreato sul server |
| Questa pagina e il binario `toutwaf-backup` per il tuo sistema | lo strumento; conserva una copia su una chiavetta USB, è un unico file statico |

Se non hai né il file della chiave, né la passphrase, né la chiave su carta, **nessuno può recuperare i dati.** È il prezzo di un server che non possiede mai una chiave.

## Ripristinare un file o una directory (uso quotidiano)

```sh
toutwaf-backup client snapshots --type host --id web1                         # find the snapshot
toutwaf-backup client ls host/web1/latest etc/nginx                            # look inside, no restore needed
toutwaf-backup client find host/web1/latest '*.conf'
toutwaf-backup client restore host/web1/20261023T023000Z --path etc/nginx --target /tmp/restore --verify
toutwaf-backup client cat host/web1/latest etc/hostname                        # one file to standard output
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop                 # a database dump straight into its importer
```

I percorsi sono quelli mostrati da `ls` (senza barra iniziale); un percorso sorgente `/etc/nginx` viene ripristinato in `<destinazione>/etc/nginx`. I file esistenti **non vengono mai sovrascritti** senza `--overwrite`. `client browse` apre una pagina web locale (127.0.0.1) per sfogliare e scaricare.

## Ripristinare un'intera macchina

Lo strumento salva **file e informazioni di sistema, non immagini del disco**: non ricrea partizioni, boot loader né il sistema operativo. Ricostruisci prima il sistema di base, poi ripristina i dati.

1. Installa il sistema operativo (la stessa distribuzione, se puoi) e imposta il nome host e la rete.
2. Installa il client (`install.sh --role client`, oppure copia il binario).
3. Ricrea la connessione e la chiave: con la sola chiave su carta usa `client key import-paper` (controlla ogni riga e chiede una nuova passphrase), poi `client init`.
4. Guarda com'era l'host (`.twb-meta/system.json`: nome host, kernel, mount, pacchetti installati).
5. Ripristina prima in una directory di prova, oppure direttamente sulla radice; esegui come root per ripristinare proprietari, attributi estesi, ACL, nodi di dispositivo e FIFO.
6. Reinstalla il boot loader e i pacchetti se la radice è nuova, riavvia, controlla i servizi, poi esegui un nuovo backup: viene deduplicato rispetto ai vecchi.

```sh
toutwaf-backup client key import-paper --keyfile /root/key.json < paper.txt        # only if the key file or the passphrase is lost
toutwaf-backup client init --server https://backup.example.net:8007 --fingerprint <hex> --token <reader token> --datastore main --namespace hosts/web1 --keyfile /root/key.json
toutwaf-backup client cat host/web1/latest .twb-meta/system.json                   # what the host was (when saved with --system-info)
toutwaf-backup client restore host/web1/latest --target /mnt/newroot --verify      # a new root mounted at /mnt/newroot
toutwaf-backup client restore host/web1/latest --target / --overwrite --verify     # in place, replaces files
```

## Il file della chiave o la passphrase sono persi

* Passphrase persa, **chiave su carta conservata**: `client key import-paper --keyfile new.json < paper.txt`, imposta una nuova passphrase, aggiorna il profilo.
* File della chiave perso, passphrase conservata: usa la chiave su carta come sopra. Senza di essa non si può fare nulla. Una **copia di deposito** (`client key escrow`) si apre con la sua passphrase.
* Poi cambia la passphrase con `client key change-passphrase`. **Se tutti e tre sono persi, i backup sono illeggibili, per progetto.**

## Il server di backup è perso

1. Recupera i dati: il disco, una copia ripristinata, oppure la **copia fuori sede** che un job di sincronizzazione ha inviato a un secondo server o disco. La directory del datastore è autodescrittiva.
2. Su una nuova macchina: `install.sh --role server --no-init`, poi `toutwaf-backup server init --state /var/lib/toutwaf-backup --listen :8007 --external-url https://... --datastore main=/percorso/del/datastore/recuperato` (una directory esistente viene adottata, nulla viene riscritto). Annota il nuovo token di amministrazione e la **nuova impronta del certificato**.
3. Crea i token per i tuoi client (`server token create`) ed esegui di nuovo `client init` con la nuova impronta.
4. Verifica con `toutwaf-backup server verify --datastore main --scrub`, ripristina un file con un client e ricrea il job di copia fuori sede.

## Il server e il suo disco sono persi e la copia è in un bucket S3

Se è stato eseguito un job *Copia fuori sede su S3* (o se il datastore stesso vive in un bucket), il bucket contiene tutto tranne la chiave: i chunk e, in `meta/`, le impostazioni e l'elenco degli snapshot. Ti servono il bucket, il prefisso della copia (`offsite-<id del job>` salvo diversa scelta), chiavi S3 che possano leggerlo e il tuo file della chiave o la tua **chiave su carta**. Sul nuovo server, nell'interfaccia web (Datastore, *Crea un datastore*, **Riprendi da S3**) o da riga di comando:

```sh
printf '{"access_key_id":"...","secret_access_key":"..."}' | toutwaf-backup datastore import-s3 main \
  --s3-credentials-stdin --s3-bucket my-backups --s3-provider wasabi --s3-region eu-central-1 --s3-prefix offsite-main
```

Un prefisso errato o vuoto viene rifiutato («il bucket non contiene alcun mirror dei metadati») e non viene creato nulla. Poi crea i token, esegui di nuovo `client init`, ripristina con `client restore` e ricrea il job di copia fuori sede (adotta la copia già presente nel bucket se indichi lo stesso bucket e prefisso). [S3.md](S3.md) descrive le tre funzioni S3.

## Il datastore è danneggiato (corruzione silenziosa, guasto parziale del disco)

```sh
toutwaf-backup server verify --datastore main --scrub     # reads every snapshot and chunk file; damaged chunks are moved aside, never deleted
toutwaf-backup client verify host/web1/latest --read-data  # needs the key: proves every chunk decrypts and matches its id
```

Un chunk **mancante o danneggiato** fa fallire la verifica degli snapshot che lo usano. Il backup successivo degli stessi dati ricarica il chunk e il datastore si ripara da solo; gli snapshot più vecchi che richiedevano un chunk che i dati attuali non contengono più restano danneggiati: ripristinali dalla replica (una sincronizzazione `pull` copia solo ciò che manca) o accetta la perdita per quei file. Il ripristino indica esattamente quali file non ha potuto ripristinare (stato di uscita 1); il resto viene ripristinato.

## L'esercitazione (falla, poi annota la data)

1. Su una macchina di riserva (o in una directory temporanea) con **solo** i segreti documentati: file della chiave o chiave su carta, passphrase, token, impronta.
2. `client restore <gruppo importante>/latest --target /tmp/drill --verify`, apri alcuni file; per un database, importa il dump in un'istanza di prova.
3. `client verify <snapshot> --read-data` dimostra che ogni chunk si decifra e corrisponde al suo id.
4. Cronometra (un ripristino a 70 MiB/s richiede circa 4 ore per terabyte), annota tutto ciò che ti ha sorpreso e correggi questa procedura.
