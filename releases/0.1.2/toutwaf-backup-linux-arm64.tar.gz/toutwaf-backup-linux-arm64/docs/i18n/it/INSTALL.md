[English](../en/INSTALL.md) | [Français](../fr/INSTALL.md) | [Español](../es/INSTALL.md) | [Deutsch](../de/INSTALL.md) | **Italiano** | [Português](../pt/INSTALL.md) | [Nederlands](../nl/INSTALL.md) | [Русский](../ru/INSTALL.md) | [中文](../zh/INSTALL.md) | [العربية](../ar/INSTALL.md)

# Installazione

Supportati: Linux (amd64 e arm64, con systemd) e Windows (amd64, **non testato su una vera macchina Windows**). L'installer Linux richiede `bash`, `curl` o `wget`, `tar`, `sha256sum`, `base64` e **OpenSSL 3** per verificare la firma. Il binario stesso è un unico file statico.

## Dove va il server (da leggere per prima)

Installare ToutWAF Backup è **facoltativo**. Il **server deve girare su una macchina diversa da quella di ToutWAF**: un backup archiviato sulla macchina che protegge non sopravvive alla perdita di quella macchina (guasto del disco, ransomware, incendio, furto). `install.sh --role server` e `install.ps1 -Role server` cercano ToutWAF sull'host e **rifiutano**, con stato di uscita 3, se lo trovano; `toutwaf-backup server run` fa lo stesso controllo all'avvio. Il ruolo client non viene mai rifiutato.

## Installazione su Linux

```sh
# server (the machine that stores the backups)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role server \
    --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start

# client (every machine to protect)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role client
```

L'installer scarica `channel.json`, poi `SHA256SUMS` e la sua firma; **verifica la firma Ed25519** con la chiave pubblica incorporata nello script, poi lo **SHA-256 dell'archivio** rispetto all'elenco firmato, e rifiuta una versione ritirata. Installa `toutwaf-backup` in modo atomico (il binario precedente è conservato come `toutwaf-backup.prev`). Per il ruolo server crea anche l'utente di sistema, la directory di stato, l'unit systemd e, alla prima installazione, la configurazione: mostra il primo token di amministrazione (una sola volta) e l'impronta del certificato. Nulla parte senza `--start`. È idempotente: eseguilo di nuovo per aggiornare.

**Lingua degli installer.** `install.sh` e `install.ps1` parlano le dieci lingue: seguono `--lang fr` (o `--fr`, `--es`, `--de` ...; `-Lang fr` su Windows), poi `TWB_LANG`, poi la lingua del sistema (`LC_ALL`, `LANG`; la lingua di visualizzazione di Windows), poi l'inglese. Accenti e scritture non latine richiedono un terminale UTF-8; altrimenti l'installer parla inglese. Nomi delle opzioni, comandi e nomi dei file non vengono mai tradotti.

## Server: primi passi

```sh
systemctl enable --now toutwaf-backup-server       # if you did not pass --start
toutwaf-backup server token create --name web1 --role writer --datastore main --namespace hosts/web1 --append-only
toutwaf-backup server datastore set main --require-encryption=true --quota 2T --immutable-days 7
```

* Apri la porta (8007 per impostazione predefinita) solo ai tuoi client. L'interfaccia web è `https://HOST:8007/` (accesso con il token di amministrazione). Il certificato è autofirmato, quindi i browser avvisano: confronta l'impronta mostrata in **Impostazioni** con `toutwaf-backup server fingerprint`.
* Crea un token per client e non condividere mai il token di amministrazione. Un token `writer` può eseguire backup ma non può né leggere né cancellare.
* La modalità *sola aggiunta* su un datastore significa che nessuno può cancellare tramite l'API; per disattivarla serve `toutwaf-backup server datastore set main --append-only=false` sulla macchina del server stessa.
* Pianifica le attività proprie del server nell'interfaccia web (**Job**): una verifica settimanale, una potatura giornaliera (non su un datastore in sola aggiunta), un recupero dello spazio settimanale e una copia fuori sede su un secondo server, un disco o un bucket S3. Le notifiche (e-mail, webhook firmati) sono in **Impostazioni**.
* Fai il backup dello stato proprio del server (`/var/lib/toutwaf-backup`: configurazione, token, chiave TLS, registro di audit) con un client verso un altro server. Perdere la chiave TLS obbliga ogni client a fissare la nuova impronta.

## Client: primi passi

```sh
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --namespace hosts/web1 --create-key
toutwaf-backup client backup --path /etc --path /var/www --id $(hostname) --one-file-system --exclude '*.tmp'
toutwaf-backup client snapshots
toutwaf-backup client schedule --daily 02:30 --id $(hostname) --path /etc --path /var/www --install
systemctl daemon-reload && systemctl enable --now toutwaf-backup-$(hostname).timer
```

`client init --create-key` mostra l'impronta del server perché tu la confermi, scrive il profilo e crea il file della chiave, poi stampa la **chiave su carta**. **Conserva il file della chiave, la sua passphrase e la chiave su carta lontano dalla macchina**: senza di essi nessuno può ripristinare (vedi `RESTORE.md`). Per le esecuzioni non presidiate metti la passphrase in un file leggibile solo da root e referenzialo nel profilo. Stato di uscita: 0 successo, 1 errore (nulla confermato), 2 confermato con avvisi. I database non richiedono file temporanei:

```sh
mysqldump --single-transaction shop | toutwaf-backup client backup --type db --id shop --stdin --stdin-name shop.sql
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop
```

## Archiviazione a oggetti S3

Un datastore può tenere i propri chunk in un bucket compatibile S3 (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO), e qualsiasi datastore può essere copiato in un bucket con una pianificazione. Nell'interfaccia web: Datastore, *Crea un datastore*, **Archiviazione a oggetti S3**, poi *Testa la connessione*. La guida completa, la riga di comando e la procedura di ripristino sono in [S3.md](S3.md).

## Montare uno snapshot (Linux)

```sh
toutwaf-backup client mount host/web1/latest /mnt/snap        # read-only; Ctrl-C or: fusermount3 -u /mnt/snap
```

Lo snapshot appare come un albero di directory in sola lettura: nulla viene ripristinato; i chunk di un file vengono scaricati, decifrati e autenticati solo quando un programma li legge. Un chunk non autenticabile dà un errore di I/O, mai dati sbagliati. Come utente normale il mount richiede il pacchetto `fuse3`.

## Windows

> **NON testato su una vera macchina Windows in questa release.** Il binario Windows è compilato in cross-compilazione e il motore di backup e ripristino è lo stesso codice testato su Linux, ma tutto ciò che è specifico di Windows è stato scritto in base alla documentazione e non è mai stato eseguito. Provalo prima su una macchina non critica.

```powershell
# in an elevated PowerShell
irm https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.ps1 -OutFile install.ps1    # read it, then:
.\install.ps1 -Role server -ExternalUrl https://backup.example.net:8007 -Datastore main=D:\Backups\main -Start
.\install.ps1 -Role client
```

Le stesse opzioni esistono come parametri (`-Channel`, `-Version`, `-BaseUrl`, `-InstallDir`, `-StateDir`, `-Listen`, `-NoInit`, `-Start`, `-NoFirewall`, `-Uninstall`, `-Purge`, `-Force`, `-Yes`, `-Lang`). Lo script verifica la firma Ed25519 in PowerShell puro, installa `toutwaf-backup.exe`, lo aggiunge al PATH di sistema e, per il server, limita la directory di stato, installa il servizio Windows e una regola del firewall (solo profili Dominio e Privato). Ciò che differisce da Linux:

* `client mount` esiste solo su Linux; su Windows usa `client ls`, `client find`, `client cat` e `client restore`.
* Il backup da una copia shadow del volume (`--vss`) è **non testato e disattivato** salvo che sia impostata la variabile d'ambiente `TWB_ENABLE_UNTESTED_VSS=1`.
* I descrittori di sicurezza NTFS sono registrati in ogni backup, ma il loro **ripristino** non è testato e resta disattivato salvo che sia impostato `TWB_ENABLE_UNTESTED_WIN_ACL=1`. Percorsi lunghi, giunzioni, flussi di dati alternativi ed EFS non sono testati o non sono gestiti.
* `install.ps1`, il suo controllo della firma in PowerShell puro, il servizio Windows, la regola del firewall e il file per l'Utilità di pianificazione generato da `client schedule --target windows` non sono mai stati eseguiti su Windows.

## Aggiornamento, ripristino della versione, disinstallazione

```sh
sudo ./install.sh --role server                         # run it again with the same options: upgrade
sudo mv /usr/local/bin/toutwaf-backup.prev /usr/local/bin/toutwaf-backup && sudo systemctl restart toutwaf-backup-server    # rollback
sudo ./install.sh --role server --uninstall            # keeps the data; add --purge to remove the configuration, the state and the user
```

Il formato 1 e l'API 1 sono stabili, quindi server e client di versioni 0.x diverse interoperano. La disinstallazione conserva i dati salvo `--purge`; i datastore fuori dalla directory di stato non vengono mai eliminati.
