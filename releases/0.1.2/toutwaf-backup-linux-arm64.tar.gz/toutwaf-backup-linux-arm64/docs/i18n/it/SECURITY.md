[English](../en/SECURITY.md) | [Français](../fr/SECURITY.md) | [Español](../es/SECURITY.md) | [Deutsch](../de/SECURITY.md) | **Italiano** | [Português](../pt/SECURITY.md) | [Nederlands](../nl/SECURITY.md) | [Русский](../ru/SECURITY.md) | [中文](../zh/SECURITY.md) | [العربية](../ar/SECURITY.md)

# Modello di sicurezza (riepilogo)

Questo è un riepilogo. Il modello di minaccia completo, la crittografia e il formato del repository sono nella documentazione inglese (`docs/SECURITY.md`, `docs/ARCHITECTURE.md`). **Nessuna terza parte ha verificato questo software.**

## Cosa il server può e non può vedere

| Il server può vedere | Il server non può vedere |
|---|---|
| che esiste un client con un token valido, il suo indirizzo, quando si connette | la chiave, la passphrase, il contenuto di qualsiasi file |
| il nome del gruppo di backup (ad esempio `host/web1`), lo spazio dei nomi, gli orari degli snapshot, le dimensioni totali e il numero di file, la dimensione e il numero dei chunk archiviati | i nomi dei file, la struttura delle directory, la dimensione dei singoli file, i proprietari, i permessi, quale chunk appartiene a quale file, se due file condividono contenuto |
| che due snapshot condividono chunk (stessa chiave) | nulla che gli permetta di verificare un'ipotesi sui tuoi dati in chiaro: gli id dei chunk sono con chiave (HMAC), anche i confini dei chunk |

Dimensioni e tempi trapelano per progetto: un osservatore del server o della rete apprende quanto è cambiato e quando. Con `--no-encrypt` il server può leggere tutto; un datastore può essere impostato su `require_encryption` per rifiutare i dati in chiaro.

## Modello di minaccia

| Avversario | Cosa ottiene e perché |
|---|---|
| Osservatore di rete o man in the middle | solo dimensioni e tempi: TLS, e il client fissa l'impronta del certificato del server; un altro certificato viene rifiutato prima di inviare un solo byte |
| Disco di backup rubato, o accesso in lettura al server | testo cifrato, nomi dei gruppi, dimensioni e tempi: la chiave non raggiunge mai il server |
| Compromissione del server con accesso in scrittura | può cancellare o trattenere backup (disponibilità); non può falsificare, alterare o unire snapshot senza essere scoperto: ogni chunk è autenticato con il suo id e ogni manifest è sigillato con la chiave |
| Client compromesso | può caricare spazzatura, ma non può cancellare né sovrascrivere i backup esistenti se il suo token è di scrittura (o il datastore è in sola aggiunta); un client che possiede la chiave può leggere i propri backup |
| Token di amministrazione compromesso | può cambiare impostazioni e token, ma non può cancellare da un datastore in sola aggiunta, disattivare la sola aggiunta né accorciare il periodo di immutabilità: queste impostazioni cambiano solo sulla macchina del server stessa; ogni azione è nel registro di audit concatenato con hash |
| Ransomware, o root sulla macchina del server | il ransomware su un client cifra i dati attivi, non i backup; root sul server può cancellare tutto (disponibilità): tieni una copia fuori sede (un secondo server, un disco o un bucket S3 con Object Lock) per garanzie a prova di ransomware |

**Non coperto:** un server che nasconde i tuoi snapshot più recenti (confronta `client snapshots` con i tuoi registri, o avvisa sui backup in ritardo); la perdita della chiave; un client malevolo che parla con un datastore che non richiede la cifratura; uno scrittore che riempie il disco (imposta una quota); l'accesso fisico alla macchina che contiene sia il file della chiave sia la passphrase.

## Crittografia

Da passphrase a chiave: **Argon2id**. Cifratura autenticata: **XChaCha20-Poly1305** (nonce casuale a 192 bit). Sottochiavi: **HKDF-SHA-256**. Id dei chunk: HMAC-SHA-256 con una sottochiave (SHA-256 senza cifratura). TLS 1.2 o successivo con un certificato ECDSA P-256 autofirmato; le firme delle release sono Ed25519. Nulla è fatto in casa; il formato è descritto perché possa essere verificato.

## Gestione delle chiavi

* `client key create` crea il file della chiave e stampa la **chiave su carta**. Il file della chiave si può copiare senza rischi (senza la passphrase non rivela nulla); la chiave su carta è la chiave principale in chiaro: stampala, mettila in una cassaforte, mai sulla stessa macchina dei dati.
* `client key change-passphrase` reimpacchetta la stessa chiave principale (le vecchie copie del file della chiave si aprono ancora con la vecchia passphrase: distruggile). `client key escrow` scrive la chiave protetta da una seconda passphrase distinta per una persona di fiducia.
* File della chiave e passphrase persi ma chiave su carta conservata: `client key import-paper` ricostruisce un file della chiave. **Persi tutti e tre: i backup sono illeggibili, per progetto.**
* Per sostituire la chiave principale (dopo un sospetto di compromissione), crea una nuova chiave ed esegui nuovi backup: non si deduplicano rispetto ai vecchi, che restano leggibili con la vecchia chiave finché non vengono potati. Testa il ripristino, non solo il backup: l'esercitazione è in [RESTORE.md](RESTORE.md).

## Token API e ruoli

| Ruolo | Può / non può |
|---|---|
| **admin** | tutto, compresi token, datastore, job e impostazioni; non può disattivare la sola aggiunta né accorciare il periodo di immutabilità (solo sulla macchina del server) |
| **writer** | controlla e carica chunk, conferma snapshot, elenca; non può leggere chunk, cancellare né potare (salvo autorizzazione, e allora solo i propri snapshot, mai in sola aggiunta) |
| **reader** | elenca, legge chunk e indici, sfoglia e scarica snapshot non cifrati; non può scrivere |
| **audit** | legge i metadati degli snapshot, il registro di audit, le metriche, gli avvisi e lo stato dei job; non può leggere i dati dei chunk né modificare nulla |

## Operatività

* **Il server non gira mai sulla macchina che protegge, né accanto a ToutWAF.** Gli installer e `server run` lo rifiutano, e il contratto di abbinamento porta un hash dell'id macchina perché ToutWAF e il server rifiutino entrambi un abbinamento sulla stessa macchina. Esiste una deroga di laboratorio; non va usata in produzione.
* Le quote (limiti di byte rigidi e morbidi, numero di snapshot e di chunk, limiti di banda) per token e per spazio dei nomi sono uno strumento di equità, non un confine di sicurezza rispetto a un token che possiede la propria chiave client.
* Le credenziali S3 stanno nell'ambiente del server, in un file leggibile solo dal servizio, oppure (digitate nell'interfaccia o inviate dalla console di ToutWAF) in `<stato>/secrets/s3/` con modo 0600. Sono in sola scrittura: mai in un file di configurazione, in un mirror nel bucket, in una risposta dell'API, in una pagina, nel registro di audit, in una riga di log o in un argomento della riga di comando. La directory di stato è quindi un segreto. Con Object Lock in modalità Compliance e un datastore in sola aggiunta, nemmeno una chiave S3 rubata può cancellare chunk prima della fine della loro conservazione. Vedi [S3.md](S3.md).
* Il servizio gira come utente senza privilegi con una unit systemd rafforzata; la porta è aperta solo ai tuoi client. La limitazione per indirizzo e il blocco dopo errori di autenticazione sono attivi per impostazione predefinita; il registro di audit è concatenato con hash (`server audit-verify` rileva qualsiasi modifica). L'interfaccia web imposta una Content-Security-Policy rigorosa, senza script inline né origini esterne.

## Segnalare una vulnerabilità

Segnala una vulnerabilità in privato al proprietario del progetto ToutWAF (vedi il contatto del repository); non aprire una issue pubblica.
