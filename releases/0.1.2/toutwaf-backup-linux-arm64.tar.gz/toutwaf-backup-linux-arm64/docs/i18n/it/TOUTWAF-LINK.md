[English](../en/TOUTWAF-LINK.md) | [Français](../fr/TOUTWAF-LINK.md) | [Español](../es/TOUTWAF-LINK.md) | [Deutsch](../de/TOUTWAF-LINK.md) | **Italiano** | [Português](../pt/TOUTWAF-LINK.md) | [Nederlands](../nl/TOUTWAF-LINK.md) | [Русский](../ru/TOUTWAF-LINK.md) | [中文](../zh/TOUTWAF-LINK.md) | [العربية](../ar/TOUTWAF-LINK.md)

# Il collegamento con ToutWAF

ToutWAF Backup funziona da solo. Il collegamento permette a una console ToutWAF di usare un server di backup: crea il datastore e i token limitati per ogni macchina ToutWAF, pianifica i backup, li verifica e li ripristina, e riceve gli avvisi di errore. Il contratto è versionato (`toutwaf-backup-link/1`) e documentato per intero nel `docs/TOUTWAF-LINK.md` inglese; questa pagina è la vista dell'utente. **La chiave resta sulla macchina ToutWAF**: il server di backup e il token del collegamento non possono decifrare nulla.

## Abbinamento

Nella console di ToutWAF crea un **token di abbinamento** monouso («aggiungi un server di backup»), poi esegui sul server di backup:

```sh
toutwaf-backup link --toutwaf https://waf.example.net --token <pairing token> --url https://backup.example.net:8007
toutwaf-backup link --status
toutwaf-backup link --remove
```

Il comando crea un token di collegamento con ambito amministratore, lo invia a ToutWAF con l'indirizzo del server e l'impronta del suo certificato, e registra l'abbinamento; se ToutWAF rifiuta, il token viene revocato di nuovo e non resta nulla. L'abbinamento viene rifiutato quando il server di backup e ToutWAF girano sulla stessa macchina. ToutWAF deve verificare l'impronta fuori banda la prima volta.

## Cosa può fare allora la console di ToutWAF

* Creare, per ogni macchina ToutWAF, un datastore e un token **writer** (sola aggiunta, limitato a un datastore e a uno spazio dei nomi) e un token **reader** facoltativo per i ripristini.
* Impostare quote e limiti di banda sui token che predispone, e leggere l'utilizzo.
* Leggere lo stato del server (salute, utilizzo, avvisi, ultimo backup di ogni gruppo), elencare e ispezionare gli snapshot.
* Avviare la verifica di uno snapshot o di un datastore (senza chiave) e seguirla come attività.
* Ricevere eventi firmati: job fallito, verifica fallita, backup in ritardo, avviso di quota. I ripristini girano sulla macchina ToutWAF, che possiede la chiave.

## Datastore locale o S3, a scelta per macchina

La console sceglie dove vivono i backup di ogni macchina con i campi `backend`, `s3` e `s3_auth` di `POST /api/v1/link/provision`, e può anche pianificare una copia fuori sede su un bucket con `offsite_s3`. Solo `name` è obbligatorio; `backend` è per impostazione predefinita un datastore locale. Le chiavi in `s3_auth` sono in sola scrittura: salvate sul server, mai restituite né registrate.

```json
POST /api/v1/link/provision
{"name":"toutwaf-prod","datastore":"toutwaf","namespace":"toutwaf-prod","append_only":true,"require_encryption":true,
 "backend":"s3",
 "s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-backups","prefix":"toutwaf-prod","addressing":"auto",
       "object_lock_mode":"","object_lock_days":0,"storage_class":""},
 "s3_auth":{"access_key_id":"...","secret_access_key":"...","session_token":"","ca_pem":""},
 "offsite_s3":{"s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-offsite","prefix":"toutwaf-prod"},"s3_auth":{"access_key_id":"...","secret_access_key":"..."},
               "schedule":"every 6h","bandwidth_bps":0,"verify_after":true}}
```

* `backend`: `files` (locale, predefinito) o `s3`.
* `s3`: provider, regione, bucket, prefisso, indirizzamento, modalità e giorni di Object Lock, classe di archiviazione; `s3_auth`: chiave di accesso, chiave segreta, token di sessione facoltativo e CA privata.
* `offsite_s3`: gli stessi `s3` e `s3_auth` per il bucket di destinazione, più `schedule`, `bandwidth_bps` e `verify_after` (vero per impostazione predefinita); crea un job `offsite-<datastore>`.
* La risposta contiene `backend`, `s3` (ciò che viene mostrato, mai un segreto) e `offsite_job`. Un bucket non valido o chiavi errate danno `400` e non viene creato nulla; chiedere un backend diverso da quello di un datastore esistente con lo stesso nome dà `409`. `POST /api/v1/storage/test` permette alla console di testare prima un bucket, e `POST /api/v1/datastores/import-s3` ricostruisce un datastore da un bucket dopo una perdita totale.

## Stato, con onestà

Abbinamento, predisposizione, stato, eventi firmati e campi S3 sono testati end-to-end contro una finta console ToutWAF. **Non testato: una vera console ToutWAF**, che non implementa ancora la sua parte; e S3 solo contro un finto in memoria, non un vero provider.
