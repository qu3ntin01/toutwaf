[English](../en/SECURITY.md) | [Français](../fr/SECURITY.md) | [Español](../es/SECURITY.md) | **Deutsch** | [Italiano](../it/SECURITY.md) | [Português](../pt/SECURITY.md) | [Nederlands](../nl/SECURITY.md) | [Русский](../ru/SECURITY.md) | [中文](../zh/SECURITY.md) | [العربية](../ar/SECURITY.md)

# Sicherheitsmodell (Zusammenfassung)

Dies ist eine Zusammenfassung. Das vollständige Bedrohungsmodell, die Kryptografie und das Repository-Format stehen in der englischen Dokumentation (`docs/SECURITY.md`, `docs/ARCHITECTURE.md`). **Kein Dritter hat diese Software auditiert.**

## Was der Server sehen kann und was nicht

| Der Server kann sehen | Der Server kann nicht sehen |
|---|---|
| dass ein Client mit gültigem Token existiert, seine Adresse, wann er sich verbindet | den Schlüssel, die Passphrase, den Inhalt irgendeiner Datei |
| den Namen der Backup-Gruppe (zum Beispiel `host/web1`), den Namensraum, die Zeitpunkte der Snapshots, Gesamtgrößen und Dateianzahlen, Größe und Anzahl der gespeicherten Chunks | Dateinamen, die Verzeichnisstruktur, Größen einzelner Dateien, Besitzer, Berechtigungen, welcher Chunk zu welcher Datei gehört, ob zwei Dateien Inhalt teilen |
| dass zwei Snapshots Chunks teilen (gleicher Schlüssel) | nichts, womit es eine Vermutung über Ihre Klartexte prüfen könnte: Chunk-IDs sind geschlüsselt (HMAC), die Chunk-Grenzen ebenfalls |

Größe und Zeitverhalten sind konstruktionsbedingt sichtbar: Ein Beobachter des Servers oder des Netzwerks erfährt, wie viel sich wann geändert hat. Mit `--no-encrypt` kann der Server alles lesen; ein Datastore lässt sich auf `require_encryption` setzen, damit Klartext abgelehnt wird.

## Bedrohungsmodell

| Angreifer | Was er erhält und warum |
|---|---|
| Netzwerkbeobachter oder Man-in-the-Middle | nur Größen und Zeitverhalten: TLS, und der Client pinnt den Fingerabdruck des Serverzertifikats; ein anderes Zertifikat wird abgelehnt, bevor ein Byte gesendet wird |
| Gestohlener Backup-Datenträger oder Lesezugriff auf den Server | Geheimtext, Gruppennamen, Größen und Zeitverhalten: Der Schlüssel erreicht den Server nie |
| Server-Kompromittierung mit Schreibzugriff | kann Sicherungen löschen oder zurückhalten (Verfügbarkeit); kann Snapshots nicht unbemerkt fälschen, ändern oder zusammenfügen: Jeder Chunk ist mit seiner ID authentifiziert, jedes Manifest mit dem Schlüssel versiegelt |
| Kompromittierter Client | kann Müll hochladen, aber vorhandene Sicherungen weder löschen noch überschreiben, wenn sein Token ein writer-Token ist (oder der Datastore „nur anhängen“ ist); ein Client mit dem Schlüssel kann seine eigenen Sicherungen lesen |
| Kompromittiertes Admin-Token | kann Einstellungen und Tokens ändern, aber weder aus einem Datastore „nur anhängen“ löschen noch „nur anhängen“ ausschalten noch die Unveränderlichkeitsfrist verkürzen: Diese Einstellungen ändern sich nur auf dem Server-Rechner selbst; jede Aktion steht im hashverketteten Audit-Protokoll |
| Ransomware oder root auf dem Server-Rechner | Ransomware auf einem Client verschlüsselt die Live-Daten, nicht die Sicherungen; root auf dem Server kann alles löschen (Verfügbarkeit): Halten Sie eine externe Kopie (zweiter Server, Datenträger oder S3-Bucket mit Object Lock) für Garantien auf Ransomware-Niveau |

**Nicht abgedeckt:** ein Server, der Ihre neuesten Snapshots verbirgt (vergleichen Sie `client snapshots` mit Ihren eigenen Aufzeichnungen oder alarmieren Sie bei überfälligen Sicherungen); Verlust des Schlüssels; ein bösartiger Client, der mit einem Datastore ohne Verschlüsselungspflicht spricht; ein Schreiber, der den Datenträger füllt (Kontingent setzen); physischer Zugriff auf den Rechner, der Schlüsseldatei und Passphrase zugleich enthält.

## Kryptografie

Passphrase zu Schlüssel: **Argon2id**. Authentifizierte Verschlüsselung: **XChaCha20-Poly1305** (zufällige 192-Bit-Nonce). Unterschlüssel: **HKDF-SHA-256**. Chunk-IDs: HMAC-SHA-256 unter einem Unterschlüssel (SHA-256 ohne Verschlüsselung). TLS 1.2 oder neuer mit selbstsigniertem ECDSA-P-256-Zertifikat; Release-Signaturen sind Ed25519. Nichts ist selbst erfunden; das Format ist beschrieben, damit es geprüft werden kann.

## Schlüsselverwaltung

* `client key create` erzeugt die Schlüsseldatei und gibt den **Papierschlüssel** aus. Die Schlüsseldatei kann gefahrlos kopiert werden (ohne Passphrase verrät sie nichts); der Papierschlüssel ist der Hauptschlüssel im Klartext: ausdrucken, im Tresor verwahren, nie auf demselben Rechner wie die Daten.
* `client key change-passphrase` verpackt denselben Hauptschlüssel neu (alte Kopien der Schlüsseldatei lassen sich noch mit der alten Passphrase öffnen: vernichten Sie sie). `client key escrow` schreibt den Schlüssel unter einer zweiten, getrennten Passphrase für eine Vertrauensperson.
* Schlüsseldatei und Passphrase verloren, Papierschlüssel vorhanden: `client key import-paper` baut eine Schlüsseldatei neu auf. **Alle drei verloren: Die Sicherungen sind unlesbar, so ist es gewollt.**
* Um den Hauptschlüssel zu ersetzen (nach vermuteter Kompromittierung), erzeugen Sie einen neuen Schlüssel und erstellen neue Sicherungen: Diese werden nicht gegen die alten dedupliziert, die mit dem alten Schlüssel lesbar bleiben, bis sie bereinigt werden. Testen Sie die Wiederherstellung, nicht nur die Sicherung: Die Übung steht in [RESTORE.md](RESTORE.md).

## API-Tokens und Rollen

| Rolle | Kann / kann nicht |
|---|---|
| **admin** | alles, einschließlich Tokens, Datastores, Aufträge und Einstellungen; kann „nur anhängen“ nicht ausschalten und die Unveränderlichkeitsfrist nicht verkürzen (nur auf dem Server-Rechner) |
| **writer** | prüft und lädt Chunks hoch, übernimmt Snapshots, listet auf; kann Chunks weder lesen noch löschen noch bereinigen (außer erlaubt, dann nur eigene Snapshots, nie bei „nur anhängen“) |
| **reader** | listet auf, liest Chunks und Indizes, durchsucht und lädt unverschlüsselte Snapshots herunter; kann nicht schreiben |
| **audit** | liest Snapshot-Metadaten, das Audit-Protokoll, Metriken, Alarme und den Aufgabenstatus; kann weder Chunk-Daten lesen noch etwas ändern |

## Betrieb

* **Der Server läuft nie auf dem Rechner, den er schützt, und nie neben ToutWAF.** Die Installer und `server run` lehnen das ab, und der Kopplungsvertrag enthält einen Hash der Rechner-ID, damit ToutWAF und der Server beide eine Kopplung auf demselben Rechner ablehnen. Es gibt eine Ausnahme für Labore; sie darf nicht in der Produktion verwendet werden.
* Kontingente (harte und weiche Byte-Limits, Anzahl von Snapshots und Chunks, Bandbreitenlimits) pro Token und pro Namensraum sind ein Fairness-Werkzeug, keine Sicherheitsgrenze gegenüber einem Token mit eigenem Client-Schlüssel.
* S3-Zugangsdaten liegen in der Umgebung des Servers, in einer nur für den Dienst lesbaren Datei oder (in der Oberfläche eingegeben bzw. von der ToutWAF-Konsole gesendet) in `<Status>/secrets/s3/` mit Modus 0600. Sie sind nur schreibbar: nie in einer Konfigurationsdatei, einem Spiegel im Bucket, einer API-Antwort, einer Seite, dem Audit-Protokoll, einer Protokollzeile oder einem Kommandozeilenargument. Das Statusverzeichnis ist daher ein Geheimnis. Mit Object Lock im Compliance-Modus und einem Datastore „nur anhängen“ kann selbst ein gestohlener S3-Schlüssel Chunks nicht vor Ablauf ihrer Aufbewahrung löschen. Siehe [S3.md](S3.md).
* Der Dienst läuft als unprivilegierter Benutzer mit einer gehärteten systemd-Unit; der Port wird nur für Ihre Clients geöffnet. Ratenbegrenzung pro Adresse und Sperre nach Anmeldefehlern sind standardmäßig aktiv; das Audit-Protokoll ist hashverkettet (`server audit-verify` findet jede Änderung). Die Weboberfläche setzt eine strenge Content-Security-Policy ohne Inline-Skript und ohne externe Herkunft.

## Eine Schwachstelle melden

Melden Sie eine Schwachstelle privat dem Eigentümer des ToutWAF-Projekts (siehe Kontakt im Repository); eröffnen Sie kein öffentliches Issue.
