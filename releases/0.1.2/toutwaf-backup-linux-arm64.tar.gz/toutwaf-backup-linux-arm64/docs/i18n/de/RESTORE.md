[English](../en/RESTORE.md) | [Français](../fr/RESTORE.md) | [Español](../es/RESTORE.md) | **Deutsch** | [Italiano](../it/RESTORE.md) | [Português](../pt/RESTORE.md) | [Nederlands](../nl/RESTORE.md) | [Русский](../ru/RESTORE.md) | [中文](../zh/RESTORE.md) | [العربية](../ar/RESTORE.md)

# Wiederherstellung und Notfallplan

Eine Sicherung, die Sie nie wiederhergestellt haben, ist nur eine Hoffnung. Lesen Sie dies einmal, **bevor** Sie es brauchen, und machen Sie die Übung am Ende mindestens jedes Quartal.

## Was Sie haben müssen und wo Sie es aufbewahren

| Element | Wozu und wo aufbewahren |
|---|---|
| Die **Schlüsseldatei** und ihre **Passphrase** | entschlüsseln alles; bewahren Sie sie in einem Passwortmanager oder Tresor auf, nicht nur auf dem gesicherten Rechner |
| Der von `client key create` ausgegebene **Papierschlüssel** | baut die Schlüsseldatei neu auf, wenn Datei oder Passphrase verloren sind; ausdrucken und im Tresor aufbewahren |
| Der **Fingerabdruck des Servers** und ein *reader*- (oder admin-)Token | um den Server zu erreichen; ein reader-Token lässt sich auf dem Server neu anlegen |
| Diese Seite und die `toutwaf-backup`-Programmdatei für Ihr System | das Werkzeug; bewahren Sie eine Kopie auf einem USB-Stick auf, es ist eine einzige statische Datei |

Haben Sie weder Schlüsseldatei noch Passphrase noch Papierschlüssel, **kann niemand die Daten wiederherstellen.** Das ist der Preis eines Servers, der nie einen Schlüssel besitzt.

## Eine Datei oder ein Verzeichnis wiederherstellen (alltäglich)

```sh
toutwaf-backup client snapshots --type host --id web1                         # find the snapshot
toutwaf-backup client ls host/web1/latest etc/nginx                            # look inside, no restore needed
toutwaf-backup client find host/web1/latest '*.conf'
toutwaf-backup client restore host/web1/20261023T023000Z --path etc/nginx --target /tmp/restore --verify
toutwaf-backup client cat host/web1/latest etc/hostname                        # one file to standard output
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop                 # a database dump straight into its importer
```

Pfade sind die von `ls` gezeigten (ohne führenden Schrägstrich); ein Quellpfad `/etc/nginx` wird nach `<Ziel>/etc/nginx` wiederhergestellt. Vorhandene Dateien werden **nie überschrieben**, außer mit `--overwrite`. `client browse` öffnet eine lokale Webseite (127.0.0.1) zum Durchsuchen und Herunterladen.

## Einen ganzen Rechner wiederherstellen

Das Werkzeug sichert **Dateien und Systeminformationen, keine Datenträger-Abbilder**: Es legt weder Partitionen noch Bootloader noch das Betriebssystem neu an. Bauen Sie zuerst das Basissystem neu auf, dann stellen Sie die Daten wieder her.

1. Installieren Sie das Betriebssystem (nach Möglichkeit dieselbe Distribution) und richten Sie Rechnernamen und Netzwerk ein.
2. Installieren Sie den Client (`install.sh --role client` oder die Programmdatei kopieren).
3. Stellen Sie Verbindung und Schlüssel wieder her: Mit nur dem Papierschlüssel verwenden Sie `client key import-paper` (prüft jede Zeile und fragt nach einer neuen Passphrase), danach `client init`.
4. Sehen Sie nach, was der Rechner war (`.twb-meta/system.json`: Rechnername, Kernel, Einhängepunkte, installierte Pakete).
5. Stellen Sie zuerst in ein Arbeitsverzeichnis oder direkt auf die Wurzel wieder her; als root ausführen, um Besitzer, erweiterte Attribute, ACLs, Gerätedateien und FIFOs wiederherzustellen.
6. Installieren Sie bei neuer Wurzel Bootloader und Pakete neu, starten Sie neu, prüfen Sie die Dienste und führen Sie dann eine neue Sicherung aus: Sie wird gegen die alten dedupliziert.

```sh
toutwaf-backup client key import-paper --keyfile /root/key.json < paper.txt        # only if the key file or the passphrase is lost
toutwaf-backup client init --server https://backup.example.net:8007 --fingerprint <hex> --token <reader token> --datastore main --namespace hosts/web1 --keyfile /root/key.json
toutwaf-backup client cat host/web1/latest .twb-meta/system.json                   # what the host was (when saved with --system-info)
toutwaf-backup client restore host/web1/latest --target /mnt/newroot --verify      # a new root mounted at /mnt/newroot
toutwaf-backup client restore host/web1/latest --target / --overwrite --verify     # in place, replaces files
```

## Schlüsseldatei oder Passphrase sind verloren

* Passphrase verloren, **Papierschlüssel vorhanden**: `client key import-paper --keyfile new.json < paper.txt`, eine neue Passphrase setzen, das Profil aktualisieren.
* Schlüsseldatei verloren, Passphrase vorhanden: Verwenden Sie den Papierschlüssel wie oben. Ohne ihn ist nichts zu machen. Eine **Treuhandkopie** (`client key escrow`) öffnet sich mit ihrer eigenen Passphrase.
* Ändern Sie danach die Passphrase mit `client key change-passphrase`. **Sind alle drei verloren, sind die Sicherungen unlesbar, so ist es gewollt.**

## Der Backup-Server ist verloren

1. Holen Sie die Daten zurück: den Datenträger, eine wiederhergestellte Kopie oder die **externe Kopie**, die ein Synchronisierungsauftrag auf einen zweiten Server oder Datenträger übertragen hat. Das Datastore-Verzeichnis beschreibt sich selbst.
2. Auf einem neuen Rechner: `install.sh --role server --no-init`, dann `toutwaf-backup server init --state /var/lib/toutwaf-backup --listen :8007 --external-url https://... --datastore main=/Pfad/zum/wiederhergestellten/datastore` (ein vorhandenes Verzeichnis wird übernommen, nichts wird neu geschrieben). Notieren Sie das neue Admin-Token und den **neuen Zertifikat-Fingerabdruck**.
3. Legen Sie Tokens für Ihre Clients an (`server token create`) und führen Sie `client init` mit dem neuen Fingerabdruck erneut aus.
4. Prüfen Sie mit `toutwaf-backup server verify --datastore main --scrub`, stellen Sie mit einem Client eine Datei wieder her und legen Sie den Auftrag für die externe Kopie neu an.

## Server und Datenträger sind verloren, und die Kopie liegt in einem S3-Bucket

Wenn ein Auftrag *Externe Kopie nach S3* lief (oder der Datastore selbst in einem Bucket liegt), enthält der Bucket alles außer dem Schlüssel: die Chunks und in `meta/` die Einstellungen und die Snapshot-Liste. Sie brauchen den Bucket, das Präfix der Kopie (`offsite-<Auftrags-ID>`, sofern Sie kein anderes gewählt haben), S3-Schlüssel mit Leserecht und Ihre Schlüsseldatei oder Ihren **Papierschlüssel**. Auf dem neuen Server, in der Weboberfläche (Datastores, *Datastore anlegen*, **Aus S3 fortsetzen**) oder auf der Kommandozeile:

```sh
printf '{"access_key_id":"...","secret_access_key":"..."}' | toutwaf-backup datastore import-s3 main \
  --s3-credentials-stdin --s3-bucket my-backups --s3-provider wasabi --s3-region eu-central-1 --s3-prefix offsite-main
```

Ein falsches oder leeres Präfix wird abgelehnt („der Bucket enthält keinen Metadaten-Spiegel“), und es wird nichts angelegt. Legen Sie danach Tokens an, führen Sie `client init` erneut aus, stellen Sie mit `client restore` wieder her und legen Sie den Auftrag für die externe Kopie neu an (er übernimmt die bereits im Bucket liegende Kopie, wenn Sie denselben Bucket und dasselbe Präfix angeben). [S3.md](S3.md) beschreibt die drei S3-Funktionen.

## Der Datastore ist beschädigt (Bitfäule, teilweiser Datenträgerausfall)

```sh
toutwaf-backup server verify --datastore main --scrub     # reads every snapshot and chunk file; damaged chunks are moved aside, never deleted
toutwaf-backup client verify host/web1/latest --read-data  # needs the key: proves every chunk decrypts and matches its id
```

Ein **fehlender oder beschädigter** Chunk lässt die Prüfung der Snapshots scheitern, die ihn verwenden. Die nächste Sicherung derselben Daten lädt den Chunk erneut hoch, und der Datastore heilt sich selbst; ältere Snapshots, die einen Chunk brauchten, den die aktuellen Daten nicht mehr enthalten, bleiben beschädigt: Stellen Sie sie aus der Replik wieder her (eine `pull`-Synchronisierung kopiert nur Fehlendes) oder nehmen Sie den Verlust dieser Dateien hin. Die Wiederherstellung nennt genau, welche Dateien sie nicht wiederherstellen konnte (Exit-Status 1); der Rest wird wiederhergestellt.

## Die Übung (durchführen, dann das Datum notieren)

1. Auf einem Ersatzrechner (oder in einem temporären Verzeichnis) mit **nur** den dokumentierten Geheimnissen: Schlüsseldatei oder Papierschlüssel, Passphrase, Token, Fingerabdruck.
2. `client restore <wichtige Gruppe>/latest --target /tmp/drill --verify`, einige Dateien öffnen; bei einer Datenbank den Dump in eine Testinstanz importieren.
3. `client verify <Snapshot> --read-data` belegt, dass jeder Chunk entschlüsselt werden kann und zu seiner ID passt.
4. Messen Sie die Zeit (eine Wiederherstellung mit 70 MiB/s dauert etwa 4 Stunden pro Terabyte), notieren Sie alles Überraschende und korrigieren Sie diesen Plan.
