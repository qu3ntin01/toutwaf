[English](../en/TOUTWAF-LINK.md) | [Français](../fr/TOUTWAF-LINK.md) | [Español](../es/TOUTWAF-LINK.md) | **Deutsch** | [Italiano](../it/TOUTWAF-LINK.md) | [Português](../pt/TOUTWAF-LINK.md) | [Nederlands](../nl/TOUTWAF-LINK.md) | [Русский](../ru/TOUTWAF-LINK.md) | [中文](../zh/TOUTWAF-LINK.md) | [العربية](../ar/TOUTWAF-LINK.md)

# Die Anbindung an ToutWAF

ToutWAF Backup funktioniert eigenständig. Die Anbindung lässt eine ToutWAF-Konsole einen Backup-Server nutzen: Sie legt den Datastore und die eingeschränkten Tokens für jeden ToutWAF-Rechner an, plant Sicherungen, prüft und stellt sie wieder her und empfängt Fehleralarme. Der Vertrag ist versioniert (`toutwaf-backup-link/1`) und ausführlich in der englischen `docs/TOUTWAF-LINK.md` dokumentiert; diese Seite zeigt die Sicht des Benutzers. **Der Schlüssel bleibt auf dem ToutWAF-Rechner**: Der Backup-Server und das Verbindungs-Token können nichts entschlüsseln.

## Kopplung

Erstellen Sie in der ToutWAF-Konsole ein einmaliges **Kopplungs-Token** („Backup-Server hinzufügen“) und führen Sie auf dem Backup-Server aus:

```sh
toutwaf-backup link --toutwaf https://waf.example.net --token <pairing token> --url https://backup.example.net:8007
toutwaf-backup link --status
toutwaf-backup link --remove
```

Der Befehl erzeugt ein Verbindungs-Token mit Administrator-Rechten, sendet es mit Adresse und Zertifikat-Fingerabdruck des Servers an ToutWAF und hält die Kopplung fest; lehnt ToutWAF ab, wird das Token wieder widerrufen und nichts bleibt zurück. Die Kopplung wird abgelehnt, wenn Backup-Server und ToutWAF auf demselben Rechner laufen. ToutWAF muss den Fingerabdruck beim ersten Mal auf einem anderen Weg prüfen.

## Was die ToutWAF-Konsole dann tun kann

* Für jeden ToutWAF-Rechner einen Datastore und ein **writer**-Token (nur anhängen, auf einen Datastore und einen Namensraum beschränkt) sowie ein optionales **reader**-Token für Wiederherstellungen anlegen.
* Kontingente und Bandbreitenlimits für die von ihr eingerichteten Tokens setzen und die Nutzung lesen.
* Den Serverstatus lesen (Zustand, Nutzung, Alarme, letzte Sicherung jeder Gruppe), Snapshots auflisten und untersuchen.
* Die Prüfung eines Snapshots oder Datastores starten (ohne Schlüssel) und als Aufgabe verfolgen.
* Signierte Ereignisse empfangen: fehlgeschlagener Auftrag, fehlgeschlagene Prüfung, überfällige Sicherung, Kontingentwarnung. Wiederherstellungen laufen auf dem ToutWAF-Rechner, der den Schlüssel besitzt.

## Lokaler oder S3-Datastore, pro Rechner wählbar

Die Konsole wählt mit den Feldern `backend`, `s3` und `s3_auth` von `POST /api/v1/link/provision`, wo die Sicherungen jedes Rechners liegen, und kann mit `offsite_s3` auch eine externe Kopie in einen Bucket planen. Nur `name` ist erforderlich; `backend` ist standardmäßig ein lokaler Datastore. Die Schlüssel in `s3_auth` sind nur schreibbar: auf dem Server gespeichert, nie zurückgegeben oder protokolliert.

```json
POST /api/v1/link/provision
{"name":"toutwaf-prod","datastore":"toutwaf","namespace":"toutwaf-prod","append_only":true,"require_encryption":true,
 "backend":"s3",
 "s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-backups","prefix":"toutwaf-prod","addressing":"auto",
       "object_lock_mode":"","object_lock_days":0,"storage_class":""},
 "s3_auth":{"access_key_id":"...","secret_access_key":"...","session_token":"","ca_pem":""},
 "offsite_s3":{"s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-offsite","prefix":"toutwaf-prod"},"s3_auth":{"access_key_id":"...","secret_access_key":"..."},
               "schedule":"every 6h","bandwidth_bps":0,"verify_after":true}}
```

* `backend`: `files` (lokal, Standard) oder `s3`.
* `s3`: Anbieter, Region, Bucket, Präfix, Adressierung, Object-Lock-Modus und -Tage, Speicherklasse; `s3_auth`: Zugangsschlüssel, geheimer Schlüssel, optionales Sitzungstoken und private CA.
* `offsite_s3`: dieselben `s3` und `s3_auth` für den Ziel-Bucket, dazu `schedule`, `bandwidth_bps` und `verify_after` (standardmäßig wahr); es legt einen Auftrag `offsite-<datastore>` an.
* Die Antwort enthält `backend`, `s3` (was angezeigt wird, nie ein Geheimnis) und `offsite_job`. Ein ungültiger Bucket oder falsche Schlüssel ergeben `400`, und nichts wird angelegt; ein anderes Backend als das eines vorhandenen Datastores gleichen Namens ergibt `409`. Mit `POST /api/v1/storage/test` kann die Konsole einen Bucket vorab testen, und `POST /api/v1/datastores/import-s3` baut nach einem Totalverlust einen Datastore aus einem Bucket neu auf.

## Ehrlicher Stand

Kopplung, Einrichtung, Status, signierte Ereignisse und S3-Felder sind Ende-zu-Ende gegen eine nachgebaute ToutWAF-Konsole getestet. **Nicht getestet: eine echte ToutWAF-Konsole**, die ihre Seite noch nicht umsetzt; und S3 nur gegen eine In-Process-Attrappe, nicht gegen einen echten Anbieter.
