[English](../en/TOUTWAF-LINK.md) | [Français](../fr/TOUTWAF-LINK.md) | [Español](../es/TOUTWAF-LINK.md) | [Deutsch](../de/TOUTWAF-LINK.md) | [Italiano](../it/TOUTWAF-LINK.md) | **Português** | [Nederlands](../nl/TOUTWAF-LINK.md) | [Русский](../ru/TOUTWAF-LINK.md) | [中文](../zh/TOUTWAF-LINK.md) | [العربية](../ar/TOUTWAF-LINK.md)

# A ligação ao ToutWAF

O ToutWAF Backup funciona sozinho. A ligação permite que uma consola do ToutWAF use um servidor de cópias: cria o datastore e os tokens restritos de cada máquina ToutWAF, agenda cópias, verifica-as e restaura-as, e recebe os alertas de falha. O contrato tem versão (`toutwaf-backup-link/1`) e está documentado por inteiro no `docs/TOUTWAF-LINK.md` em inglês; esta página é a vista do utilizador. **A chave fica na máquina ToutWAF**: o servidor de cópias e o token da ligação não conseguem decifrar nada.

## Emparelhamento

Na consola do ToutWAF crie um **token de emparelhamento** de uso único («adicionar um servidor de cópias») e execute no servidor de cópias:

```sh
toutwaf-backup link --toutwaf https://waf.example.net --token <pairing token> --url https://backup.example.net:8007
toutwaf-backup link --status
toutwaf-backup link --remove
```

O comando cria um token de ligação com âmbito de administrador, envia-o ao ToutWAF com o endereço do servidor e a impressão digital do seu certificado, e regista o emparelhamento; se o ToutWAF recusar, o token é revogado de novo e nada fica. O emparelhamento é recusado quando o servidor de cópias e o ToutWAF correm na mesma máquina. O ToutWAF deve verificar a impressão digital por outro canal da primeira vez.

## O que a consola do ToutWAF pode então fazer

* Criar, para cada máquina ToutWAF, um datastore e um token **escritor** (só acrescentar, confinado a um datastore e a um espaço de nomes) e um token **leitor** opcional para os restauros.
* Definir quotas e limites de largura de banda nos tokens que aprovisiona, e ler a utilização.
* Ler o estado do servidor (saúde, utilização, alertas, última cópia de cada grupo), listar e inspecionar instantâneos.
* Iniciar a verificação de um instantâneo ou de um datastore (sem chave) e acompanhá-la como tarefa.
* Receber eventos assinados: tarefa falhada, verificação falhada, cópia em atraso, aviso de quota. Os restauros correm na máquina ToutWAF, que tem a chave.

## Datastore local ou S3, à escolha por máquina

A consola escolhe onde vivem as cópias de cada máquina com os campos `backend`, `s3` e `s3_auth` de `POST /api/v1/link/provision`, e também pode agendar uma cópia externa para um bucket com `offsite_s3`. Só `name` é obrigatório; `backend` é por predefinição um datastore local. As chaves em `s3_auth` são de só escrita: guardadas no servidor, nunca devolvidas nem registadas.

```json
POST /api/v1/link/provision
{"name":"toutwaf-prod","datastore":"toutwaf","namespace":"toutwaf-prod","append_only":true,"require_encryption":true,
 "backend":"s3",
 "s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-backups","prefix":"toutwaf-prod","addressing":"auto",
       "object_lock_mode":"","object_lock_days":0,"storage_class":""},
 "s3_auth":{"access_key_id":"...","secret_access_key":"...","session_token":"","ca_pem":""},
 "offsite_s3":{"s3":{"provider":"wasabi","region":"eu-central-1","bucket":"my-offsite","prefix":"toutwaf-prod"},"s3_auth":{"access_key_id":"...","secret_access_key":"..."},
               "schedule":"every 6h","bandwidth_bps":0,"verify_after":true}}
```

* `backend`: `files` (local, a predefinição) ou `s3`.
* `s3`: fornecedor, região, bucket, prefixo, endereçamento, modo e dias de Object Lock, classe de armazenamento; `s3_auth`: chave de acesso, chave secreta, token de sessão opcional e AC privada.
* `offsite_s3`: os mesmos `s3` e `s3_auth` para o bucket de destino, mais `schedule`, `bandwidth_bps` e `verify_after` (verdadeiro por predefinição); cria uma tarefa `offsite-<datastore>`.
* A resposta inclui `backend`, `s3` (o que é mostrado, nunca um segredo) e `offsite_job`. Um bucket inválido ou chaves erradas dão `400` e nada é criado; pedir um backend diferente do de um datastore existente com o mesmo nome dá `409`. `POST /api/v1/storage/test` permite à consola testar primeiro um bucket, e `POST /api/v1/datastores/import-s3` reconstrói um datastore a partir de um bucket após uma perda total.

## Estado, com franqueza

O emparelhamento, o aprovisionamento, o estado, os eventos assinados e os campos S3 são testados de ponta a ponta contra uma consola ToutWAF simulada. **Não testado: uma consola ToutWAF real**, que ainda não implementa a sua parte; e o S3 apenas contra um simulado em memória, não um fornecedor real.
