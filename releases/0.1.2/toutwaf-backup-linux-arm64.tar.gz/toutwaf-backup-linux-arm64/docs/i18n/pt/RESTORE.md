[English](../en/RESTORE.md) | [Français](../fr/RESTORE.md) | [Español](../es/RESTORE.md) | [Deutsch](../de/RESTORE.md) | [Italiano](../it/RESTORE.md) | **Português** | [Nederlands](../nl/RESTORE.md) | [Русский](../ru/RESTORE.md) | [中文](../zh/RESTORE.md) | [العربية](../ar/RESTORE.md)

# Restauro e procedimento de recuperação de desastre

Uma cópia que nunca restaurou é apenas uma esperança. Leia isto uma vez **antes** de precisar e faça o ensaio final pelo menos de três em três meses.

## O que deve ter e onde guardar

| Item | Porquê e onde guardar |
|---|---|
| O **ficheiro de chave** e a sua **frase-passe** | decifram tudo; guarde-os num gestor de palavras-passe ou num cofre, não apenas na máquina de que se faz a cópia |
| A **chave em papel** impressa por `client key create` | reconstrói o ficheiro de chave se o ficheiro ou a frase-passe se perderem; imprima-o e guarde-o num cofre |
| A **impressão digital do servidor** e um token *leitor* (ou admin) | para alcançar o servidor; um token leitor pode ser criado de novo no servidor |
| Esta página e o binário `toutwaf-backup` do seu sistema | a ferramenta; guarde uma cópia numa pen USB, é um único ficheiro estático |

Se não tem o ficheiro de chave, nem a frase-passe, nem a chave em papel, **ninguém pode recuperar os dados.** Esse é o preço de um servidor que nunca tem uma chave.

## Restaurar um ficheiro ou um diretório (no dia a dia)

```sh
toutwaf-backup client snapshots --type host --id web1                         # find the snapshot
toutwaf-backup client ls host/web1/latest etc/nginx                            # look inside, no restore needed
toutwaf-backup client find host/web1/latest '*.conf'
toutwaf-backup client restore host/web1/20261023T023000Z --path etc/nginx --target /tmp/restore --verify
toutwaf-backup client cat host/web1/latest etc/hostname                        # one file to standard output
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop                 # a database dump straight into its importer
```

Os caminhos são os mostrados por `ls` (sem barra inicial); um caminho de origem `/etc/nginx` é restaurado em `<destino>/etc/nginx`. Os ficheiros existentes **nunca são substituídos** sem `--overwrite`. `client browse` abre uma página web local (127.0.0.1) para navegar e transferir.

## Restaurar uma máquina inteira

A ferramenta copia **ficheiros e informação do sistema, não imagens de disco**: não recria partições, carregadores de arranque nem o sistema operativo. Reconstrua primeiro o sistema base e depois restaure os dados.

1. Instale o sistema operativo (a mesma distribuição, se puder) e configure o nome do anfitrião e a rede.
2. Instale o cliente (`install.sh --role client`, ou copie o binário).
3. Recrie a ligação e a chave: só com a chave em papel use `client key import-paper` (verifica cada linha e pede uma nova frase-passe), depois `client init`.
4. Veja como era o anfitrião (`.twb-meta/system.json`: nome do anfitrião, kernel, montagens, pacotes instalados).
5. Restaure primeiro para um diretório de teste, ou diretamente para a raiz; execute como root para restaurar proprietários, atributos estendidos, ACL, nós de dispositivo e FIFO.
6. Reinstale o carregador de arranque e os pacotes se a raiz for nova, reinicie, verifique os serviços e faça uma cópia nova: é deduplicada em relação às antigas.

```sh
toutwaf-backup client key import-paper --keyfile /root/key.json < paper.txt        # only if the key file or the passphrase is lost
toutwaf-backup client init --server https://backup.example.net:8007 --fingerprint <hex> --token <reader token> --datastore main --namespace hosts/web1 --keyfile /root/key.json
toutwaf-backup client cat host/web1/latest .twb-meta/system.json                   # what the host was (when saved with --system-info)
toutwaf-backup client restore host/web1/latest --target /mnt/newroot --verify      # a new root mounted at /mnt/newroot
toutwaf-backup client restore host/web1/latest --target / --overwrite --verify     # in place, replaces files
```

## O ficheiro de chave ou a frase-passe perdeu-se

* Frase-passe perdida, **chave em papel guardada**: `client key import-paper --keyfile new.json < paper.txt`, defina uma nova frase-passe e atualize o perfil.
* Ficheiro de chave perdido, frase-passe guardada: use a chave em papel como acima. Sem ela nada pode ser feito. Uma **cópia de custódia** (`client key escrow`) abre-se com a sua própria frase-passe.
* Depois altere a frase-passe com `client key change-passphrase`. **Se os três se perderem, as cópias ficam ilegíveis, por conceção.**

## O servidor de cópias perdeu-se

1. Recupere os dados: o disco, uma cópia restaurada ou a **cópia externa** que uma tarefa de sincronização enviou para um segundo servidor ou disco. O diretório do datastore descreve-se a si próprio.
2. Numa máquina nova: `install.sh --role server --no-init`, depois `toutwaf-backup server init --state /var/lib/toutwaf-backup --listen :8007 --external-url https://... --datastore main=/caminho/para/o/datastore/recuperado` (um diretório existente é adotado, nada é reescrito). Anote o novo token de administração e a **nova impressão digital do certificado**.
3. Crie tokens para os seus clientes (`server token create`) e execute de novo `client init` com a nova impressão digital.
4. Verifique com `toutwaf-backup server verify --datastore main --scrub`, restaure um ficheiro com um cliente e crie de novo a tarefa de cópia externa.

## O servidor e o seu disco perderam-se e a cópia está num bucket S3

Se uma tarefa *Cópia externa para S3* correu (ou se o próprio datastore vive num bucket), o bucket contém tudo menos a chave: os fragmentos e, em `meta/`, as definições e a lista de instantâneos. Precisa do bucket, do prefixo da cópia (`offsite-<id da tarefa>` a não ser que tenha escolhido outro), de chaves S3 que o possam ler e do seu ficheiro de chave ou da sua **chave em papel**. No servidor novo, na interface web (Datastores, *Criar um datastore*, **Retomar a partir do S3**) ou na linha de comandos:

```sh
printf '{"access_key_id":"...","secret_access_key":"..."}' | toutwaf-backup datastore import-s3 main \
  --s3-credentials-stdin --s3-bucket my-backups --s3-provider wasabi --s3-region eu-central-1 --s3-prefix offsite-main
```

Um prefixo errado ou vazio é recusado («o bucket não contém nenhum espelho de metadados») e nada é criado. Depois crie os tokens, execute de novo `client init`, restaure com `client restore` e crie de novo a tarefa de cópia externa (adota a cópia que já está no bucket se indicar o mesmo bucket e prefixo). [S3.md](S3.md) descreve as três funcionalidades S3.

## O datastore está danificado (corrupção silenciosa, falha parcial do disco)

```sh
toutwaf-backup server verify --datastore main --scrub     # reads every snapshot and chunk file; damaged chunks are moved aside, never deleted
toutwaf-backup client verify host/web1/latest --read-data  # needs the key: proves every chunk decrypts and matches its id
```

Um fragmento **em falta ou danificado** faz falhar a verificação dos instantâneos que o usam. A cópia seguinte dos mesmos dados volta a enviar o fragmento e o datastore repara-se; os instantâneos mais antigos que precisavam de um fragmento que os dados atuais já não contêm ficam danificados: restaure-os a partir da réplica (uma sincronização `pull` copia apenas o que falta) ou aceite a perda desses ficheiros. O restauro indica exatamente que ficheiros não conseguiu restaurar (estado de saída 1); o resto é restaurado.

## O ensaio (faça-o e anote a data)

1. Numa máquina de reserva (ou num diretório temporário) com **apenas** os segredos documentados: ficheiro de chave ou chave em papel, frase-passe, token, impressão digital.
2. `client restore <grupo importante>/latest --target /tmp/drill --verify`, abra alguns ficheiros; para uma base de dados, importe o dump numa instância de teste.
3. `client verify <instantâneo> --read-data` prova que cada fragmento decifra e corresponde ao seu id.
4. Cronometre (um restauro a 70 MiB/s demora cerca de 4 horas por terabyte), anote tudo o que o surpreendeu e corrija este procedimento.
