[English](../en/README.md) | [Français](../fr/README.md) | [Español](../es/README.md) | [Deutsch](../de/README.md) | [Italiano](../it/README.md) | **Português** | [Nederlands](../nl/README.md) | [Русский](../ru/README.md) | [中文](../zh/README.md) | [العربية](../ar/README.md)

# ToutWAF Backup

Um sistema de cópias de segurança independente num único binário estático: um **servidor** que armazena cópias deduplicadas, comprimidas e cifradas no cliente, um **cliente** que copia ficheiros, diretórios e dumps de bases de dados, uma **interface web** e uma **ligação documentada ao ToutWAF**. Instala-se no seu próprio servidor e não precisa de nada do ToutWAF para funcionar.

* **Os seus dados são cifrados antes de saírem da sua máquina** (XChaCha20-Poly1305, chave derivada da sua frase-passe com Argon2id). O servidor nunca tem a chave e não consegue ler nomes de ficheiros, conteúdos nem a árvore.
* **Deduplicação e compressão**: fragmentos delimitados pelo conteúdo, endereçamento por SHA-256, zstd. Uma segunda cópia de dados inalterados não envia nada; entre clientes que partilham uma chave, o mesmo dado é armazenado uma só vez.
* **Resistente a ransomware**: os tokens de escrita não podem ler nem apagar; os datastores e os tokens podem ser *só acrescentar* (desativá-lo exige a própria máquina do servidor); um período de imutabilidade; tarefas de verificação e de scrub; cópias externas; notificações quando uma cópia se atrasa ou uma verificação falha.
* **Cliente completo**: regras de inclusão e exclusão, incremental rápido, permissões, proprietários, atributos estendidos e ACL, `mysqldump | toutwaf-backup client backup --stdin`, scripts antes e depois, restauro parcial e verificado, `ls`, `find` e `cat` de qualquer instantâneo sem restaurar, limites de largura de banda, geração de temporizador systemd ou tarefa do Windows.
* **Quotas e limites**: quotas de bytes por token e por espaço de nomes (aviso flexível, recusa rígida), número de instantâneos e de fragmentos, limites de largura de banda; visíveis na interface, na API e na linha de comandos.
* **Cópias em S3, como funcionalidade de primeira classe** (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO, qualquer serviço compatível com S3): manter um datastore **num bucket**, agendar uma **cópia externa para S3** de qualquer datastore (limite de largura de banda, verificação por releitura) e **retomar a partir do S3** num servidor novo quando o antigo se perde. As chaves escritas na interface ficam no servidor e nunca voltam a ser mostradas; teste de ligação; Object Lock opcional. Ver `S3.md`.
* **Montar um instantâneo** só de leitura em Linux (`client mount`, FUSE) e explorá-lo com as ferramentas habituais; no Windows use `ls`, `find`, `cat` e `restore`.
* **API HTTPS e HTTP/2** com tokens de âmbito limitado (admin, escritor, leitor, auditoria), certificado autoassinado fixado, limitação de pedidos, registo de auditoria encadeado por hash, métricas Prometheus, ponto de saúde.
* **Interface web em dez idiomas** (inglês, francês, espanhol, alemão, italiano, português, neerlandês, russo, chinês, árabe com disposição da direita para a esquerda), clara e escura, utilizável com teclado e leitor de ecrã: datastores e utilização, clientes, navegador de instantâneos com transferência de ficheiros, tarefas, verificação, limpeza e libertação de espaço, tokens, utilizadores, definições, auditoria. A linha de comandos, os instaladores e as notificações falam os mesmos dez idiomas.

**Política de instalação.** O ToutWAF Backup é opcional. O **servidor corre numa máquina diferente da do ToutWAF** (os instaladores e `server run` recusam caso contrário): uma cópia guardada na máquina que protege não sobrevive à perda dessa máquina. A opção `--with-backup-client` do lado do ToutWAF instala apenas o cliente. As versões são assinadas com a mesma chave Ed25519 do ToutWAF e publicadas no ramo `toutwaf-backup` do repositório público do ToutWAF.

**Estado: versão 0.1.2.** Tudo foi testado em Linux; nada foi executado numa máquina Windows real, e o S3 foi testado contra um S3 simulado em memória, não contra um fornecedor real (ver `TESTING.md` na documentação em inglês). Sem auditoria de segurança de terceiros. A licença ainda não foi escolhida.

## Início rápido

```sh
# on the backup server
sudo ./install.sh --role server --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start
toutwaf-backup server token create --name web1 --role writer --datastore main --append-only

# on the machine to protect
sudo ./install.sh --role client
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --create-key
toutwaf-backup client backup --path /etc --path /var/www --id web1
toutwaf-backup client snapshots
toutwaf-backup client restore host/web1/latest --target /tmp/restore --verify
```

`toutwaf-backup --help` e `toutwaf-backup <comando> --help` documentam cada opção, no idioma do seu sistema (ou `--lang fr`, `--lang es` ...).

## Documentação

| Página | Conteúdo |
|---|---|
| [INSTALL.md](INSTALL.md) | instalação em Linux e Windows, primeiros passos, atualização |
| [S3.md](S3.md) | armazenamento de objetos S3: datastore num bucket, cópia externa, retoma, chaves, Object Lock |
| [RESTORE.md](RESTORE.md) | restauro e procedimento de recuperação de desastre, o ensaio |
| [SECURITY.md](SECURITY.md) | o que o servidor pode e não pode ver, modelo de ameaças, chaves |
| [TOUTWAF-LINK.md](TOUTWAF-LINK.md) | emparelhamento com uma consola ToutWAF, datastore local ou S3 por máquina |
| [Documentação em inglês](../../) | a referência completa: formato do repositório, API, desempenho, testes |

## Idiomas

Estas páginas existem em dez idiomas. As traduções foram escritas por uma máquina e **não foram revistas por falantes nativos**: se uma frase soar estranha ou um detalhe divergir, a documentação em inglês em `docs/` é a referência. As correções são bem-vindas.
