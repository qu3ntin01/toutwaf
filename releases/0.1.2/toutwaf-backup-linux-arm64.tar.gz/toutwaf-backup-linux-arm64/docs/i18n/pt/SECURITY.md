[English](../en/SECURITY.md) | [Français](../fr/SECURITY.md) | [Español](../es/SECURITY.md) | [Deutsch](../de/SECURITY.md) | [Italiano](../it/SECURITY.md) | **Português** | [Nederlands](../nl/SECURITY.md) | [Русский](../ru/SECURITY.md) | [中文](../zh/SECURITY.md) | [العربية](../ar/SECURITY.md)

# Modelo de segurança (resumo)

Isto é um resumo. O modelo de ameaças completo, a criptografia e o formato do repositório estão na documentação em inglês (`docs/SECURITY.md`, `docs/ARCHITECTURE.md`). **Nenhum terceiro auditou este software.**

## O que o servidor pode e não pode ver

| O servidor pode ver | O servidor não pode ver |
|---|---|
| que existe um cliente com um token válido, o seu endereço, quando se liga | a chave, a frase-passe, o conteúdo de qualquer ficheiro |
| o nome do grupo de cópia (por exemplo `host/web1`), o espaço de nomes, as datas dos instantâneos, os tamanhos totais e o número de ficheiros, o tamanho e o número de fragmentos armazenados | os nomes dos ficheiros, a estrutura de diretórios, o tamanho de cada ficheiro, os proprietários, as permissões, que fragmento pertence a que ficheiro, se dois ficheiros partilham conteúdo |
| que dois instantâneos partilham fragmentos (mesma chave) | nada que lhe permita testar uma suposição sobre os seus dados em claro: os ids dos fragmentos usam chave (HMAC) e os limites dos fragmentos também |

O tamanho e os tempos vazam por conceção: um observador do servidor ou da rede sabe quanto mudou e quando. Com `--no-encrypt` o servidor consegue ler tudo; um datastore pode ser configurado com `require_encryption` para recusar dados em claro.

## Modelo de ameaças

| Adversário | O que obtém e porquê |
|---|---|
| Observador de rede ou intermediário | apenas tamanhos e tempos: TLS, e o cliente fixa a impressão digital do certificado do servidor; outro certificado é recusado antes de enviar um único byte |
| Disco de cópias roubado, ou acesso de leitura ao servidor | texto cifrado, nomes de grupos, tamanhos e tempos: a chave nunca chega ao servidor |
| Comprometimento do servidor com acesso de escrita | pode apagar ou reter cópias (disponibilidade); não pode falsificar, alterar nem emendar instantâneos sem ser detetado: cada fragmento é autenticado com o seu id e cada manifesto é selado com a chave |
| Cliente comprometido | pode enviar lixo, mas não pode apagar nem substituir cópias existentes se o seu token for de escrita (ou o datastore for só acrescentar); um cliente que tem a chave pode ler as suas próprias cópias |
| Token de administração comprometido | pode alterar definições e tokens, mas não pode apagar num datastore só acrescentar, desativar o modo só acrescentar nem encurtar o período de imutabilidade: essas definições só mudam na própria máquina do servidor; cada ação fica no registo de auditoria encadeado por hash |
| Ransomware, ou root na máquina do servidor | o ransomware num cliente cifra os dados ativos, não as cópias; root no servidor pode apagar tudo (disponibilidade): mantenha uma cópia externa (um segundo servidor, um disco ou um bucket S3 com Object Lock) para garantias contra ransomware |

**Não coberto:** um servidor que esconde os seus instantâneos mais recentes (compare `client snapshots` com os seus próprios registos, ou alerte sobre cópias em atraso); a perda da chave; um cliente malicioso a falar com um datastore que não exige cifra; um escritor que enche o disco (defina uma quota); o acesso físico à máquina que guarda ao mesmo tempo o ficheiro de chave e a frase-passe.

## Criptografia

De frase-passe para chave: **Argon2id**. Cifra autenticada: **XChaCha20-Poly1305** (nonce aleatório de 192 bits). Subchaves: **HKDF-SHA-256**. Ids de fragmentos: HMAC-SHA-256 com uma subchave (SHA-256 sem cifra). TLS 1.2 ou posterior com um certificado ECDSA P-256 autoassinado; as assinaturas das versões são Ed25519. Nada é de fabrico próprio; o formato está descrito para poder ser auditado.

## Gestão de chaves

* `client key create` cria o ficheiro de chave e mostra a **chave em papel**. O ficheiro de chave pode ser copiado sem risco (não revela nada sem a frase-passe); a chave em papel é a chave mestra em claro: imprima-a, guarde-a num cofre, nunca na mesma máquina dos dados.
* `client key change-passphrase` volta a embrulhar a mesma chave mestra (as cópias antigas do ficheiro de chave ainda abrem com a frase-passe antiga: destrua-as). `client key escrow` escreve a chave protegida por uma segunda frase-passe distinta para uma pessoa de confiança.
* Ficheiro de chave e frase-passe perdidos mas chave em papel guardada: `client key import-paper` reconstrói um ficheiro de chave. **Perdidos os três: as cópias ficam ilegíveis, por conceção.**
* Para substituir a chave mestra (após suspeita de comprometimento), crie uma chave nova e faça cópias novas: não são deduplicadas em relação às antigas, que continuam legíveis com a chave antiga até serem limpas. Teste a recuperação, não apenas a cópia: o ensaio está em [RESTORE.md](RESTORE.md).

## Tokens de API e funções

| Função | Pode / não pode |
|---|---|
| **admin** | tudo, incluindo tokens, datastores, tarefas e definições; não pode desativar o modo só acrescentar nem encurtar o período de imutabilidade (só na máquina do servidor) |
| **writer** | verifica e envia fragmentos, confirma instantâneos, lista; não pode ler fragmentos, apagar nem limpar (salvo autorização, e então só os seus próprios instantâneos, nunca em só acrescentar) |
| **reader** | lista, lê fragmentos e índices, navega e transfere instantâneos não cifrados; não pode escrever |
| **audit** | lê os metadados dos instantâneos, o registo de auditoria, as métricas, os alertas e o estado das tarefas; não pode ler os dados dos fragmentos nem alterar nada |

## Operação

* **O servidor nunca corre na máquina que protege, nem junto ao ToutWAF.** Os instaladores e `server run` recusam-no, e o contrato de emparelhamento leva um hash do identificador da máquina para que o ToutWAF e o servidor recusem ambos um emparelhamento na mesma máquina. Existe uma exceção de laboratório; não deve ser usada em produção.
* As quotas (limites de bytes rígidos e flexíveis, número de instantâneos e de fragmentos, limites de largura de banda) por token e por espaço de nomes são uma ferramenta de equidade, não uma fronteira de segurança face a um token que tem a sua própria chave de cliente.
* As credenciais S3 vivem no ambiente do servidor, num ficheiro que só o serviço pode ler, ou (escritas na interface ou enviadas pela consola do ToutWAF) em `<estado>/secrets/s3/` com modo 0600. São de só escrita: nunca num ficheiro de configuração, num espelho no bucket, numa resposta da API, numa página, no registo de auditoria, numa linha de registo ou num argumento da linha de comandos. O diretório de estado é por isso um segredo. Com Object Lock em modo Compliance e um datastore só acrescentar, nem uma chave S3 roubada consegue apagar fragmentos antes do fim da retenção. Ver [S3.md](S3.md).
* O serviço corre como utilizador sem privilégios com uma unidade systemd reforçada; a porta é aberta apenas aos seus clientes. A limitação por endereço e o bloqueio após falhas de autenticação estão ativos por predefinição; o registo de auditoria é encadeado por hash (`server audit-verify` deteta qualquer alteração). A interface web aplica uma Content-Security-Policy rigorosa, sem script embutido nem origem externa.

## Comunicar uma vulnerabilidade

Comunique uma vulnerabilidade em privado ao proprietário do projeto ToutWAF (ver o contacto do repositório); não abra uma issue pública.
