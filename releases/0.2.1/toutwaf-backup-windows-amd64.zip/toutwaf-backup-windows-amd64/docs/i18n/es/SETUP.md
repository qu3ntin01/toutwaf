[English](../en/SETUP.md) | [Français](../fr/SETUP.md) | **Español** | [Deutsch](../de/SETUP.md) | [Italiano](../it/SETUP.md) | [Português](../pt/SETUP.md) | [Nederlands](../nl/SETUP.md) | [Русский](../ru/SETUP.md) | [中文](../zh/SETUP.md) | [العربية](../ar/SETUP.md)

# Configuración inicial

Un servidor nuevo permanece cerrado hasta que su administrador lo configura. La última pantalla del instalador muestra un bloque: qué se instaló y dónde, un **enlace de configuración de un solo uso** (`https://HOST:8007/setup/CLAVE`), la huella del certificado, el recordatorio del cortafuegos, cómo obtener un enlace nuevo y cómo desinstalar. El enlace abre un asistente en diez idiomas; hasta que termine, la interfaz web y la API rechazan todo salvo el asistente (la página de inicio indica que la configuración está pendiente).

## Los cuatro pasos del asistente

1. **Administrador**: elija el nombre de usuario y la contraseña (indicador de seguridad, al menos 12 caracteres, nada de la lista de contraseñas más comunes, sin secuencias de teclas, sin el nombre de usuario, y 16 caracteres o tres tipos de caracteres). Opcionalmente active el doble factor: escanee el código QR, confirme con un código y guarde los ocho **códigos de recuperación** (se muestran una vez; cada uno permite iniciar sesión una vez si pierde el teléfono).
2. **Token de acceso**: el primer token de administración, mostrado **una sola vez** con un botón de copia, con lo que es un token, lo que permiten los roles (administrador, escritura, lectura, auditoría) y cómo revocarlo (Acceso, Tokens de API, o `toutwaf-backup server token revoke ID`). También puede crear un token para ToutWAF, con las instrucciones de emparejamiento.
3. **Servidor**: nombre, dirección externa (el servidor comprueba que alcanza esa dirección por HTTPS, que el certificado que responde allí es el suyo y que cubre el nombre), dirección de escucha, primer almacén de datos (una carpeta, con comprobación de escritura y espacio libre, o un bucket S3 con prueba de conexión), retención predeterminada, notificaciones por correo y webhook, canal de actualización y actualizaciones automáticas (telemetría: ninguna, no hay nada que activar).
4. **Resumen y «Terminar»**: todo se guarda paso a paso; «Terminar» consume el enlace, activa el inicio de sesión normal y da los siguientes pasos (instalar el cliente en las máquinas, emparejar con ToutWAF). Una nueva dirección de escucha y los ajustes de actualización que requieren root se muestran con los comandos exactos.

## Qué protege el enlace

* La clave del enlace tiene 256 bits aleatorios; el servidor solo guarda su SHA-256 y nunca escribe la clave en un registro, en el registro de auditoría ni en un archivo. Solo la muestra el instalador, una vez.
* El enlace es válido 60 minutos, funciona hasta que termina el asistente y se **consume** con «Terminar». Está ligado a la huella del certificado del servidor: si el certificado cambia, el enlace se rechaza.
* Compare la huella mostrada por el instalador con la de la parte superior del asistente antes de escribir nada: si difieren, no está hablando con su servidor.
* Las claves erróneas están limitadas (5 por dirección, luego un bloqueo de 5 minutos; 40 para todo el servidor). Nada más que el asistente responde hasta que termina, salvo `/health` y las llamadas a la API con un token creado por root en la máquina (así sigue funcionando el despliegue remoto de ToutWAF).
* La contraseña del administrador se guarda como hash Argon2id, los códigos de recuperación y los tokens como hashes SHA-256. Cada paso se registra en el registro de auditoría (nunca la clave, la contraseña ni un token).
* Si se pierde la página, la clave o los 60 minutos, no se pierde nada: cree un enlace nuevo en el servidor (abajo). El antiguo deja de funcionar al instante.

## Obtener un enlace de nuevo

```sh
sudo toutwaf-backup server setup-link               # status: is a link valid, until when (it cannot be shown again)
sudo toutwaf-backup server setup-link --new         # a new link: the previous one stops working
sudo toutwaf-backup server setup-link --new --reopen   # on a finished setup: lock the web interface again until the wizard is completed once more
```

## Instalaciones desatendidas

El asistente es para personas. Los scripts conservan su propio camino: `--no-setup-link` mantiene el comportamiento antiguo (se muestra un primer token de administración), y pueden predefinirse un administrador y un primer token; con un administrador predefinido el asistente omite su primer paso, y la persona aún puede abrir el enlace para elegir su propio usuario, contraseña y doble factor.

```sh
# no wizard: print a first admin token instead (as before 0.2.0)
sudo bash install.sh --role server --no-setup-link
# your own first token, and the administrator preset (nothing secret is printed)
toutwaf-backup server user hash --password-file pw.txt > admin.hash
sudo bash install.sh --role server --admin-token-file token.txt --admin-user ops --admin-password-hash-file admin.hash
```

## Con ToutWAF

Cuando ToutWAF despliega el servidor, crea su propio token de administración por SSH, lo guarda sellado en su bóveda y guarda también sellado el enlace de configuración: en la tarjeta del servidor, «Configurar el servidor» abre el enlace (tras volver a introducir su contraseña de ToutWAF). Ese enlace es para el administrador humano: su propio usuario, contraseña y doble factor, y los ajustes del servidor; ToutWAF sigue usando su propio token.
