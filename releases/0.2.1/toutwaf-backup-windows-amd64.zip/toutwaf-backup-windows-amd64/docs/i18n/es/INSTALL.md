[English](../en/INSTALL.md) | [Français](../fr/INSTALL.md) | **Español** | [Deutsch](../de/INSTALL.md) | [Italiano](../it/INSTALL.md) | [Português](../pt/INSTALL.md) | [Nederlands](../nl/INSTALL.md) | [Русский](../ru/INSTALL.md) | [中文](../zh/INSTALL.md) | [العربية](../ar/INSTALL.md)

# Instalación

Admitidos: Linux (amd64 y arm64, con systemd) y Windows (amd64, **sin probar en una máquina Windows real**). El instalador de Linux necesita `bash`, `curl` o `wget`, `tar`, `sha256sum`, `base64` y **OpenSSL 3** para verificar la firma. El binario en sí es un único archivo estático.

## Dónde va el servidor (lea esto primero)

Instalar ToutWAF Backup es **opcional**. El **servidor debe ejecutarse en una máquina distinta de la de ToutWAF**: una copia guardada en la máquina que protege no sobrevive a la pérdida de esa máquina (fallo de disco, ransomware, incendio, robo). `install.sh --role server` e `install.ps1 -Role server` buscan ToutWAF en el host y **se niegan**, con código de salida 3, si lo encuentran; `toutwaf-backup server run` hace la misma comprobación al arrancar. El rol de cliente nunca se rechaza.

## Instalación en Linux

```sh
# server (the machine that stores the backups)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role server \
    --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start

# client (every machine to protect)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role client
```

El instalador descarga `channel.json`, luego `SHA256SUMS` y su firma; **verifica la firma Ed25519** con la clave pública incorporada en el script, luego el **SHA-256 del archivo** frente a la lista firmada, y rechaza una versión retirada. Instala `toutwaf-backup` de forma atómica (el binario anterior se conserva como `toutwaf-backup.prev`). Para el rol de servidor crea además el usuario del sistema, el directorio de estado, la unidad systemd y, en la primera instalación, la configuración: muestra un bloque con un enlace de configuración de un solo uso (válido 60 minutos, mostrado una sola vez) y la huella del certificado: abra el enlace para elegir el administrador, obtener el primer token y configurar el servidor (véase SETUP.md). Nada arranca sin `--start`. Es idempotente: vuelva a ejecutarlo para actualizar.

**Idioma de los instaladores.** `install.sh` e `install.ps1` hablan los diez idiomas: siguen `--lang fr` (o `--fr`, `--es`, `--de` ...; `-Lang fr` en Windows), luego `TWB_LANG`, luego el idioma del sistema (`LC_ALL`, `LANG`; el idioma de pantalla de Windows) y por último el inglés. Los acentos y las escrituras no latinas requieren un terminal UTF-8; si no, el instalador habla inglés. Los nombres de opciones, los comandos y los nombres de archivo nunca se traducen.

## Servidor: primeros pasos

```sh
systemctl enable --now toutwaf-backup-server       # if you did not pass --start
toutwaf-backup server token create --name web1 --role writer --datastore main --namespace hosts/web1 --append-only
toutwaf-backup server datastore set main --require-encryption=true --quota 2T --immutable-days 7
```

* Abra el puerto (8007 por defecto) solo a sus clientes. La interfaz web es `https://HOST:8007/` (inicie sesión con el token de administración). El certificado es autofirmado, así que los navegadores avisan: compare la huella que aparece en **Ajustes** con `toutwaf-backup server fingerprint`.
* Cree un token por cliente y no comparta nunca el token de administración. Un token `writer` puede copiar pero no puede leer ni borrar.
* El modo *solo añadir* en un datastore significa que nadie puede borrar a través de la API; desactivarlo exige `toutwaf-backup server datastore set main --append-only=false` en la propia máquina del servidor.
* Programe las tareas propias del servidor en la interfaz web (**Tareas**): una verificación semanal, una depuración diaria (no en un datastore de solo añadir), una liberación de espacio semanal y una copia externa a un segundo servidor, un disco o un bucket S3. Las notificaciones (correo, webhooks firmados) están en **Ajustes**.
* Haga una copia del estado propio del servidor (`/var/lib/toutwaf-backup`: configuración, tokens, clave TLS, registro de auditoría) con un cliente hacia otro servidor. Perder la clave TLS obliga a cada cliente a fijar la huella nueva.

## Cliente: primeros pasos

```sh
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --namespace hosts/web1 --create-key
toutwaf-backup client backup --path /etc --path /var/www --id $(hostname) --one-file-system --exclude '*.tmp'
toutwaf-backup client snapshots
toutwaf-backup client schedule --daily 02:30 --id $(hostname) --path /etc --path /var/www --install
systemctl daemon-reload && systemctl enable --now toutwaf-backup-$(hostname).timer
```

`client init --create-key` muestra la huella del servidor para que la confirme, escribe el perfil y crea el archivo de clave, y luego muestra la **clave en papel**. **Guarde el archivo de clave, su frase de contraseña y la clave en papel lejos de la máquina**: sin ellos nadie puede restaurar (véase `RESTORE.md`). Para ejecuciones desatendidas ponga la frase de contraseña en un archivo legible solo por root y refiérala en el perfil. Código de salida: 0 éxito, 1 fallo (nada confirmado), 2 confirmado con advertencias. Las bases de datos no necesitan archivo temporal:

```sh
mysqldump --single-transaction shop | toutwaf-backup client backup --type db --id shop --stdin --stdin-name shop.sql
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop
```

## Almacenamiento de objetos S3

Un datastore puede guardar sus fragmentos en un bucket compatible con S3 (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO), y cualquier datastore puede copiarse a un bucket según un horario. En la interfaz web: Datastores, *Crear un datastore*, **Almacenamiento de objetos S3**, luego *Probar la conexión*. La guía completa, la línea de comandos y el procedimiento de recuperación están en [S3.md](S3.md).

## Montar una instantánea (Linux)

```sh
toutwaf-backup client mount host/web1/latest /mnt/snap        # read-only; Ctrl-C or: fusermount3 -u /mnt/snap
```

La instantánea aparece como un árbol de directorios de solo lectura: no se restaura nada; los fragmentos de un archivo solo se descargan, descifran y autentican cuando un programa los lee. Un fragmento que no se puede autenticar da un error de E/S, nunca datos erróneos. Como usuario normal, el montaje necesita el paquete `fuse3`.

## Windows

> **SIN PROBAR en una máquina Windows real en esta versión.** El binario de Windows está compilado de forma cruzada y el motor de copia y restauración es el mismo código que se prueba en Linux, pero todo lo específico de Windows se escribió según la documentación y nunca se ha ejecutado. Pruébelo primero en una máquina no crítica.

```powershell
# in an elevated PowerShell
irm https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.ps1 -OutFile install.ps1    # read it, then:
.\install.ps1 -Role server -ExternalUrl https://backup.example.net:8007 -Datastore main=D:\Backups\main -Start
.\install.ps1 -Role client
```

Las mismas opciones existen como parámetros (`-Channel`, `-Version`, `-BaseUrl`, `-InstallDir`, `-StateDir`, `-Listen`, `-NoInit`, `-Start`, `-NoFirewall`, `-Uninstall`, `-Purge`, `-Force`, `-Yes`, `-Lang`). El script verifica la firma Ed25519 en PowerShell puro, instala `toutwaf-backup.exe`, lo añade al PATH del sistema y, para el servidor, restringe el directorio de estado, instala el servicio de Windows y una regla de cortafuegos (solo perfiles Dominio y Privado). Lo que difiere de Linux:

* `client mount` solo existe en Linux; en Windows use `client ls`, `client find`, `client cat` y `client restore`.
* La copia desde una instantánea de volumen (`--vss`) está **sin probar y desactivada** salvo que se defina la variable de entorno `TWB_ENABLE_UNTESTED_VSS=1`.
* Los descriptores de seguridad NTFS se registran en cada copia, pero su **restauración** no está probada y queda desactivada salvo que se defina `TWB_ENABLE_UNTESTED_WIN_ACL=1`. Las rutas largas, las uniones, los flujos de datos alternativos y EFS no están probados o no se gestionan.
* `install.ps1`, su comprobación de firma en PowerShell puro, el servicio de Windows, la regla de cortafuegos y el archivo del Programador de tareas generado por `client schedule --target windows` nunca se han ejecutado en Windows.

## Actualización, vuelta atrás, desinstalación

```sh
sudo ./install.sh --role server                         # run it again with the same options: upgrade
sudo mv /usr/local/bin/toutwaf-backup.prev /usr/local/bin/toutwaf-backup && sudo systemctl restart toutwaf-backup-server    # rollback
sudo ./install.sh --role server --uninstall            # keeps the data; add --purge to remove the configuration, the state and the user
```

El formato 1 y la API 1 son estables, así que servidores y clientes de distintas versiones 0.x interoperan. Desinstalar conserva los datos salvo que añada `--purge`; los datastores fuera del directorio de estado nunca se eliminan.
