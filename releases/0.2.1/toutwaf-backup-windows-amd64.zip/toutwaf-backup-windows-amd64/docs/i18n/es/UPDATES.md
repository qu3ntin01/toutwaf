[English](../en/UPDATES.md) | [Français](../fr/UPDATES.md) | **Español** | [Deutsch](../de/UPDATES.md) | [Italiano](../it/UPDATES.md) | [Português](../pt/UPDATES.md) | [Nederlands](../nl/UPDATES.md) | [Русский](../ru/UPDATES.md) | [中文](../zh/UPDATES.md) | [العربية](../ar/UPDATES.md)

# Actualizaciones

ToutWAF Backup busca, verifica e instala sus propias actualizaciones: el comando `toutwaf-backup update` (servidor y cliente, Linux y Windows), la página **Actualizaciones** de la interfaz web y, en Linux, un temporizador diario. Cada versión está firmada con Ed25519 y cada archivo se comprueba con SHA-256 antes de reemplazar nada.

## Comandos

```sh
toutwaf-backup update status            # version, channel, whether an update is available, last check
toutwaf-backup update check             # look for an update; exit status 10 when there is one
toutwaf-backup update apply             # download, verify, install, restart the service, roll back if it does not stay up
toutwaf-backup update apply --version 0.2.1
toutwaf-backup update rollback          # put the previous version back (again: forward again)
toutwaf-backup update auto on|off       # the daily timer installs updates by itself, or only checks
toutwaf-backup update channel stable|dev
toutwaf-backup update ... --json        # machine-readable output, stable exit codes
toutwaf-backup update setup             # (root, once) the daily timer and the unit that serves the web interface
```

## Canales

`stable` lleva las versiones probadas y `dev` las de desarrollo. El canal se lee de `channel.json` de la rama pública; una versión retirada (yanked) nunca se ofrece y se rechaza salvo con `--force`. Una versión que exige un instalador más reciente (`min_installer`) se rechaza y se pide ejecutar `install.sh` de nuevo. El programa nunca retrocede de versión en silencio.

Cada canal tiene su propio archivo en la rama pública: `channels/stable.json` y `channels/dev.json` (los leen el instalador 3 y el gestor de actualizaciones). `channel.json` en la raíz es el puntero del canal estable para los instaladores más antiguos. Un canal en el que aún no se ha publicado nada es un error (código de salida 11), nunca un cambio silencioso a otro canal.

## Qué hace `update apply`

1. Lee `channel.json` y comprueba que la versión no esté retirada y que el nivel de instalador se entienda.
2. Verifica la firma Ed25519 de `SHA256SUMS` con la clave pública integrada en el programa (no se confía en nada antes).
3. Compara el SHA-256 del archivo con la lista firmada.
4. Reemplaza el ejecutable de forma atómica; el anterior queda al lado como `toutwaf-backup.prev` (lo usa `rollback`).
5. Reinicia el servicio del servidor (systemd) si está en marcha.
6. Comprueba que el servicio sigue activo (20 s para arrancar y 4 s de estabilidad); si no, se restaura el ejecutable anterior y se reinicia el servicio (código de salida 13).

## Códigos de salida

* `0`: hecho, o ya actualizado.
* `1`: error (canal inaccesible, descarga fallida, ejecutable no modificable).
* `10`: `check` encontró una actualización.
* `11`: rechazado (versión retirada, o versión que exige un instalador más reciente).
* `12`: firma o suma de comprobación incorrecta: no se instaló nada.
* `13`: la nueva versión no se mantuvo activa; se restauró la anterior.
* `14`: `rollback` no tiene versión anterior.
* `64`: uso incorrecto.

## Interfaz web y API

La página **Actualizaciones** (solo administradores; cada acción queda en el registro de auditoría) muestra la versión instalada, el canal, la actualización disponible con sus notas, los botones Comprobar, Instalar y Volver atrás, el interruptor de instalación automática y el resultado de la última operación. La API: `GET /api/v1/system/update`, `POST /api/v1/system/update/check`, `POST /api/v1/system/update/apply`, `POST /api/v1/system/update/rollback` y `PUT /api/v1/system/update/settings`. El servidor no se ejecuta como root (su unidad prohíbe escribir bajo /usr), así que no puede reemplazarse a sí mismo: Comprobar funciona directamente, mientras que Instalar, Volver atrás y los ajustes son peticiones que ejecuta una unidad root. Instale esa unidad una vez:

```sh
sudo toutwaf-backup update setup --state /var/lib/toutwaf-backup
```

`update setup` escribe las unidades `toutwaf-backup-update.timer` (comprobación diaria hacia las 03:30), `toutwaf-backup-update.service`, `toutwaf-backup-update.path` y `toutwaf-backup-update-request.service`. Sin ellas, la página sigue comprobando e indica qué comando ejecutar.

## Archivos de ajustes

`/etc/toutwaf-backup/update.conf` (canal, instalación automática, ubicación de las versiones) y `update.state` (última comprobación y resultado) son los mismos archivos del gestor de actualizaciones del instalador, `toutwaf-backup-update`: ambas herramientas pueden usarse en la misma máquina y ven los mismos ajustes. `TOUTWAF_BACKUP_BASE_URL` o `--base-url` apunta a otra ubicación (https o un espejo local file://).

## Windows

En Windows, el comando descarga, verifica y reemplaza `toutwaf-backup.exe` del mismo modo, pero no reinicia el servicio: reinícielo usted (o ejecute de nuevo el instalador). La actualización de paquetes del sistema de `install.sh` solo existe en Linux.
