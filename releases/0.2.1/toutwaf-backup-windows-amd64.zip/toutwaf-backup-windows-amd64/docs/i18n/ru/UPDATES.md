[English](../en/UPDATES.md) | [Français](../fr/UPDATES.md) | [Español](../es/UPDATES.md) | [Deutsch](../de/UPDATES.md) | [Italiano](../it/UPDATES.md) | [Português](../pt/UPDATES.md) | [Nederlands](../nl/UPDATES.md) | **Русский** | [中文](../zh/UPDATES.md) | [العربية](../ar/UPDATES.md)

# Обновления

ToutWAF Backup сам ищет, проверяет и устанавливает свои обновления: команда `toutwaf-backup update` (сервер и клиент, Linux и Windows), страница **Обновления** веб-интерфейса и, в Linux, ежедневный таймер. Каждый выпуск подписан Ed25519, а каждый архив проверяется по SHA-256 до любой замены.

## Команды

```sh
toutwaf-backup update status            # version, channel, whether an update is available, last check
toutwaf-backup update check             # look for an update; exit status 10 when there is one
toutwaf-backup update apply             # download, verify, install, restart the service, roll back if it does not stay up
toutwaf-backup update apply --version 0.2.1
toutwaf-backup update rollback          # put the previous version back (again: forward again)
toutwaf-backup update auto on|off       # the daily timer installs updates by itself, or only checks
toutwaf-backup update channel stable|dev
toutwaf-backup update ... --json        # machine-readable output, stable exit codes
toutwaf-backup update setup             # (root, once) the daily timer and the unit that serves the web interface
```

## Каналы

`stable` содержит проверенные выпуски, `dev` — сборки разработки. Канал читается из `channel.json` публичной ветки; отозванная (yanked) версия никогда не предлагается и отклоняется без `--force`. Выпуск, требующий более нового установщика (`min_installer`), отклоняется с просьбой снова запустить `install.sh`. Программа никогда не понижает версию молча.

У каждого канала есть свой файл в публичной ветке: `channels/stable.json` и `channels/dev.json` (их читают установщик 3 и менеджер обновлений). `channel.json` в корне — указатель стабильного канала для более старых установщиков. Канал, в котором ещё ничего не опубликовано, — это ошибка (код выхода 11), а не тихое переключение на другой канал.

## Что делает `update apply`

1. Читает `channel.json`, проверяет, что версия не отозвана и уровень установщика поддерживается.
2. Проверяет подпись Ed25519 файла `SHA256SUMS` встроенным в программу открытым ключом (до этого ничему не доверяет).
3. Сравнивает SHA-256 архива с подписанным списком.
4. Атомарно заменяет исполняемый файл; прежний остаётся рядом как `toutwaf-backup.prev` (его использует `rollback`).
5. Перезапускает службу сервера (systemd), если она запущена.
6. Проверяет, что служба остаётся активной (20 с на запуск, затем 4 с стабильности); иначе возвращает прежний файл и перезапускает службу (код выхода 13).

## Коды выхода

* `0`: выполнено или уже актуально.
* `1`: ошибка (канал недоступен, загрузка не удалась, файл нельзя изменить).
* `10`: `check` нашёл обновление.
* `11`: отклонено (отозванная версия или выпуск, требующий более нового установщика).
* `12`: неверная подпись или контрольная сумма: ничего не установлено.
* `13`: новая версия не осталась в работе; предыдущая восстановлена.
* `14`: у `rollback` нет предыдущей версии.
* `64`: неверное использование.

## Веб-интерфейс и API

Страница **Обновления** (только для администраторов; каждое действие записывается в журнал аудита) показывает установленную версию, канал, доступное обновление с примечаниями, кнопки «Проверить», «Установить» и «Откатиться», переключатель автоустановки и результат последней операции. API: `GET /api/v1/system/update`, `POST /api/v1/system/update/check`, `POST /api/v1/system/update/apply`, `POST /api/v1/system/update/rollback` и `PUT /api/v1/system/update/settings`. Сервер работает не от root (его unit запрещает запись в /usr) и не может заменить сам себя: проверка работает напрямую, а установка, откат и настройки — это запросы, которые выполняет root-unit. Установите этот unit один раз:

```sh
sudo toutwaf-backup update setup --state /var/lib/toutwaf-backup
```

`update setup` записывает units `toutwaf-backup-update.timer` (ежедневная проверка около 03:30), `toutwaf-backup-update.service`, `toutwaf-backup-update.path` и `toutwaf-backup-update-request.service`. Без них страница всё равно проверяет и подсказывает, какую команду выполнить.

## Файлы настроек

`/etc/toutwaf-backup/update.conf` (канал, автоустановка, расположение выпусков) и `update.state` (последняя проверка и результат) — это те же файлы, что использует менеджер обновлений установщика `toutwaf-backup-update`: оба инструмента можно применять на одной машине, они видят одни и те же настройки. `TOUTWAF_BACKUP_BASE_URL` или `--base-url` указывает другое расположение (https или локальное зеркало file://).

## Windows

В Windows команда так же скачивает, проверяет и заменяет `toutwaf-backup.exe`, но не перезапускает службу: перезапустите её сами (или снова запустите установщик). Обновление системных пакетов в `install.sh` есть только в Linux.
