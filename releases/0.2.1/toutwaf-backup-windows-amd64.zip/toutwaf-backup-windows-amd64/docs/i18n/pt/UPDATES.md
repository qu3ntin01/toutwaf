[English](../en/UPDATES.md) | [Français](../fr/UPDATES.md) | [Español](../es/UPDATES.md) | [Deutsch](../de/UPDATES.md) | [Italiano](../it/UPDATES.md) | **Português** | [Nederlands](../nl/UPDATES.md) | [Русский](../ru/UPDATES.md) | [中文](../zh/UPDATES.md) | [العربية](../ar/UPDATES.md)

# Atualizações

O ToutWAF Backup procura, verifica e instala as suas próprias atualizações: o comando `toutwaf-backup update` (servidor e cliente, Linux e Windows), a página **Atualizações** da interface web e, em Linux, um temporizador diário. Cada versão é assinada com Ed25519 e cada arquivo é verificado com SHA-256 antes de substituir seja o que for.

## Comandos

```sh
toutwaf-backup update status            # version, channel, whether an update is available, last check
toutwaf-backup update check             # look for an update; exit status 10 when there is one
toutwaf-backup update apply             # download, verify, install, restart the service, roll back if it does not stay up
toutwaf-backup update apply --version 0.2.1
toutwaf-backup update rollback          # put the previous version back (again: forward again)
toutwaf-backup update auto on|off       # the daily timer installs updates by itself, or only checks
toutwaf-backup update channel stable|dev
toutwaf-backup update ... --json        # machine-readable output, stable exit codes
toutwaf-backup update setup             # (root, once) the daily timer and the unit that serves the web interface
```

## Canais

`stable` contém as versões testadas, `dev` as de desenvolvimento. O canal é lido de `channel.json` do ramo público; uma versão retirada (yanked) nunca é oferecida e é recusada salvo com `--force`. Uma versão que exige um instalador mais recente (`min_installer`) é recusada, com o pedido de executar `install.sh` de novo. O programa nunca recua de versão em silêncio.

Cada canal tem o seu próprio ficheiro no ramo público: `channels/stable.json` e `channels/dev.json` (o instalador 3 e o gestor de atualizações leem-nos). `channel.json` na raiz é o ponteiro do canal stable para os instaladores mais antigos. Um canal em que ainda nada foi publicado é um erro (código de saída 11), nunca uma mudança silenciosa para outro canal.

## O que faz `update apply`

1. Lê `channel.json` e verifica que a versão não foi retirada e que o nível do instalador é compreendido.
2. Verifica a assinatura Ed25519 de `SHA256SUMS` com a chave pública integrada no programa (nada é aceite antes disso).
3. Compara o SHA-256 do arquivo com a lista assinada.
4. Substitui o executável de forma atómica; o anterior fica ao lado como `toutwaf-backup.prev` (é o que `rollback` usa).
5. Reinicia o serviço do servidor (systemd) se estiver em execução.
6. Verifica que o serviço se mantém ativo (20 s para arrancar e 4 s de estabilidade); caso contrário repõe o executável anterior e reinicia o serviço (código de saída 13).

## Códigos de saída

* `0`: feito, ou já atualizado.
* `1`: erro (canal inacessível, download falhado, executável não modificável).
* `10`: `check` encontrou uma atualização.
* `11`: recusado (versão retirada, ou versão que exige um instalador mais recente).
* `12`: assinatura ou soma de verificação incorreta: nada foi instalado.
* `13`: a nova versão não se manteve ativa; a anterior foi reposta.
* `14`: `rollback` não tem versão anterior.
* `64`: utilização incorreta.

## Interface web e API

A página **Atualizações** (apenas administradores; cada ação fica no registo de auditoria) mostra a versão instalada, o canal, a atualização disponível com as notas, os botões Verificar, Instalar e Voltar atrás, o interruptor de instalação automática e o resultado da última operação. A API: `GET /api/v1/system/update`, `POST /api/v1/system/update/check`, `POST /api/v1/system/update/apply`, `POST /api/v1/system/update/rollback` e `PUT /api/v1/system/update/settings`. O servidor não corre como root (a sua unidade proíbe escrever em /usr), pelo que não se pode substituir a si próprio: Verificar funciona diretamente, enquanto Instalar, Voltar atrás e as definições são pedidos executados por uma unidade root. Instale essa unidade uma vez:

```sh
sudo toutwaf-backup update setup --state /var/lib/toutwaf-backup
```

`update setup` escreve as unidades `toutwaf-backup-update.timer` (verificação diária por volta das 03:30), `toutwaf-backup-update.service`, `toutwaf-backup-update.path` e `toutwaf-backup-update-request.service`. Sem elas, a página continua a verificar e indica o comando a executar.

## Ficheiros de definições

`/etc/toutwaf-backup/update.conf` (canal, instalação automática, localização das versões) e `update.state` (última verificação e resultado) são exatamente os ficheiros do gestor de atualizações do instalador, `toutwaf-backup-update`: as duas ferramentas podem ser usadas na mesma máquina e veem as mesmas definições. `TOUTWAF_BACKUP_BASE_URL` ou `--base-url` indica outra localização (https ou um espelho local file://).

## Windows

Em Windows o comando descarrega, verifica e substitui `toutwaf-backup.exe` da mesma forma, mas não reinicia o serviço: reinicie-o você (ou execute de novo o instalador). A atualização dos pacotes do sistema do `install.sh` só existe em Linux.
