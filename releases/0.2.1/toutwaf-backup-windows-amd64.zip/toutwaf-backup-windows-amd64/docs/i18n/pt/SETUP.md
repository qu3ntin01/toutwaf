[English](../en/SETUP.md) | [Français](../fr/SETUP.md) | [Español](../es/SETUP.md) | [Deutsch](../de/SETUP.md) | [Italiano](../it/SETUP.md) | **Português** | [Nederlands](../nl/SETUP.md) | [Русский](../ru/SETUP.md) | [中文](../zh/SETUP.md) | [العربية](../ar/SETUP.md)

# Configuração inicial

Um servidor novo fica fechado até o administrador o configurar. O último ecrã do instalador mostra um bloco: o que foi instalado e onde, uma **ligação de configuração de uso único** (`https://HOST:8007/setup/CHAVE`), a impressão digital do certificado, o lembrete da firewall, como obter uma nova ligação e como desinstalar. A ligação abre um assistente em dez idiomas; até ser concluído, a interface web e a API recusam tudo exceto o assistente (a página inicial indica que a configuração está pendente).

## Os quatro passos do assistente

1. **Administrador**: escolha o nome de utilizador e a palavra-passe (indicador de robustez, pelo menos 12 caracteres, nada da lista das palavras-passe mais comuns, sem sequências de teclas, sem o nome de utilizador, e 16 caracteres ou três tipos de caracteres). Opcionalmente ative a autenticação de dois fatores: leia o código QR, confirme com um código e guarde os oito **códigos de recuperação** (mostrados uma vez; cada um permite iniciar sessão uma vez se perder o telemóvel).
2. **Token de acesso**: o primeiro token de administração, mostrado **uma só vez** com um botão de cópia, com o que é um token, o que as funções permitem (administrador, escrita, leitura, auditoria) e como revogá-lo (Acesso, Tokens de API, ou `toutwaf-backup server token revoke ID`). Também pode criar um token para o ToutWAF, com as instruções de emparelhamento.
3. **Servidor**: nome, endereço externo (o servidor verifica que alcança esse endereço por HTTPS, que o certificado que responde aí é o seu e que cobre o nome), endereço de escuta, primeiro armazenamento de dados (uma pasta, com verificação de escrita e espaço livre, ou um bucket S3 com teste de ligação), retenção predefinida, notificações por e-mail e webhook, canal de atualização e atualizações automáticas (telemetria: nenhuma, não há nada a ativar).
4. **Resumo e «Concluir»**: tudo é guardado passo a passo; «Concluir» consome a ligação, ativa o início de sessão normal e indica os passos seguintes (instalar o cliente nas máquinas, emparelhar com o ToutWAF). Um novo endereço de escuta e as definições de atualização que exigem root são listados com os comandos exatos.

## O que protege a ligação

* A chave da ligação tem 256 bits aleatórios; o servidor guarda apenas o seu SHA-256 e nunca escreve a chave num registo, no registo de auditoria ou num ficheiro. É mostrada uma só vez, pelo instalador.
* A ligação é válida 60 minutos, funciona até ao fim do assistente e é **consumida** por «Concluir». Está associada à impressão digital do certificado do servidor: se o certificado mudar, a ligação é recusada.
* Compare a impressão digital mostrada pelo instalador com a que está no topo do assistente antes de escrever o que quer que seja: se diferirem, não está a falar com o seu servidor.
* As chaves erradas são limitadas (5 por endereço, depois um bloqueio de 5 minutos; 40 para todo o servidor). Nada além do assistente responde até ser concluído, exceto `/health` e as chamadas à API com um token criado por root na máquina (é assim que a implementação remota do ToutWAF continua a funcionar).
* A palavra-passe do administrador é guardada como hash Argon2id, os códigos de recuperação e os tokens como hashes SHA-256. Cada passo fica registado no registo de auditoria (nunca a chave, a palavra-passe ou um token).
* Se a página, a chave ou os 60 minutos se perderem, nada se perde: crie uma nova ligação no servidor (abaixo). A antiga deixa de funcionar de imediato.

## Obter uma ligação de novo

```sh
sudo toutwaf-backup server setup-link               # status: is a link valid, until when (it cannot be shown again)
sudo toutwaf-backup server setup-link --new         # a new link: the previous one stops working
sudo toutwaf-backup server setup-link --new --reopen   # on a finished setup: lock the web interface again until the wizard is completed once more
```

## Instalações não assistidas

O assistente é para pessoas. Os scripts mantêm o seu caminho: `--no-setup-link` mantém o comportamento antigo (é mostrado um primeiro token de administração), e podem predefinir-se um administrador e um primeiro token; com um administrador predefinido o assistente salta o primeiro passo, e a pessoa pode sempre abrir a ligação para escolher o seu utilizador, palavra-passe e autenticação de dois fatores.

```sh
# no wizard: print a first admin token instead (as before 0.2.0)
sudo bash install.sh --role server --no-setup-link
# your own first token, and the administrator preset (nothing secret is printed)
toutwaf-backup server user hash --password-file pw.txt > admin.hash
sudo bash install.sh --role server --admin-token-file token.txt --admin-user ops --admin-password-hash-file admin.hash
```

## Com o ToutWAF

Quando o ToutWAF implementa o servidor, cria por SSH o seu próprio token de administração, guarda-o selado no seu cofre e guarda também selada a ligação de configuração: no cartão do servidor, «Configurar o servidor» abre a ligação (depois de reintroduzir a sua palavra-passe do ToutWAF). Essa ligação é para o administrador humano: o seu próprio utilizador, palavra-passe e autenticação de dois fatores, e as definições do servidor; o ToutWAF continua a usar o seu próprio token.
