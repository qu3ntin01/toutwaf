[English](../en/INSTALL.md) | [Français](../fr/INSTALL.md) | [Español](../es/INSTALL.md) | [Deutsch](../de/INSTALL.md) | [Italiano](../it/INSTALL.md) | **Português** | [Nederlands](../nl/INSTALL.md) | [Русский](../ru/INSTALL.md) | [中文](../zh/INSTALL.md) | [العربية](../ar/INSTALL.md)

# Instalação

Suportados: Linux (amd64 e arm64, com systemd) e Windows (amd64, **não testado numa máquina Windows real**). O instalador de Linux precisa de `bash`, `curl` ou `wget`, `tar`, `sha256sum`, `base64` e **OpenSSL 3** para verificar a assinatura. O binário em si é um único ficheiro estático.

## Onde instalar o servidor (leia isto primeiro)

Instalar o ToutWAF Backup é **opcional**. O **servidor deve correr numa máquina diferente da do ToutWAF**: uma cópia guardada na máquina que protege não sobrevive à perda dessa máquina (falha de disco, ransomware, incêndio, roubo). `install.sh --role server` e `install.ps1 -Role server` procuram o ToutWAF no anfitrião e **recusam**, com estado de saída 3, se o encontrarem; `toutwaf-backup server run` faz a mesma verificação ao arrancar. O papel de cliente nunca é recusado.

## Instalação em Linux

```sh
# server (the machine that stores the backups)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role server \
    --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start

# client (every machine to protect)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role client
```

O instalador transfere `channel.json`, depois `SHA256SUMS` e a sua assinatura; **verifica a assinatura Ed25519** com a chave pública incorporada no script, depois o **SHA-256 do arquivo** em relação à lista assinada, e recusa uma versão retirada. Instala `toutwaf-backup` de forma atómica (o binário anterior fica guardado como `toutwaf-backup.prev`). Para o papel de servidor cria também o utilizador do sistema, o diretório de estado, a unidade systemd e, na primeira instalação, a configuração: mostra um bloco com uma ligação de configuração de uso único (válida 60 minutos, mostrada uma só vez) e a impressão digital do certificado: abra a ligação para escolher o administrador, obter o primeiro token e configurar o servidor (ver SETUP.md). Nada arranca sem `--start`. É idempotente: execute-o de novo para atualizar.

**Idioma dos instaladores.** `install.sh` e `install.ps1` falam os dez idiomas: seguem `--lang fr` (ou `--fr`, `--es`, `--de` ...; `-Lang fr` no Windows), depois `TWB_LANG`, depois o idioma do sistema (`LC_ALL`, `LANG`; o idioma de apresentação do Windows) e por fim o inglês. Os acentos e as escritas não latinas exigem um terminal UTF-8; caso contrário o instalador fala inglês. Os nomes das opções, os comandos e os nomes dos ficheiros nunca são traduzidos.

## Servidor: primeiros passos

```sh
systemctl enable --now toutwaf-backup-server       # if you did not pass --start
toutwaf-backup server token create --name web1 --role writer --datastore main --namespace hosts/web1 --append-only
toutwaf-backup server datastore set main --require-encryption=true --quota 2T --immutable-days 7
```

* Abra a porta (8007 por predefinição) apenas aos seus clientes. A interface web é `https://HOST:8007/` (inicie sessão com o token de administração). O certificado é autoassinado, por isso os navegadores avisam: compare a impressão digital mostrada em **Definições** com `toutwaf-backup server fingerprint`.
* Crie um token por cliente e nunca partilhe o token de administração. Um token `writer` pode copiar mas não pode ler nem apagar.
* O modo *só acrescentar* num datastore significa que ninguém pode apagar através da API; desativá-lo exige `toutwaf-backup server datastore set main --append-only=false` na própria máquina do servidor.
* Agende as tarefas do próprio servidor na interface web (**Tarefas**): uma verificação semanal, uma limpeza diária (não num datastore só acrescentar), uma libertação de espaço semanal e uma cópia externa para um segundo servidor, um disco ou um bucket S3. As notificações (correio eletrónico, webhooks assinados) estão em **Definições**.
* Faça cópia do estado do próprio servidor (`/var/lib/toutwaf-backup`: configuração, tokens, chave TLS, registo de auditoria) com um cliente para outro servidor. Perder a chave TLS obriga cada cliente a fixar a nova impressão digital.

## Cliente: primeiros passos

```sh
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --namespace hosts/web1 --create-key
toutwaf-backup client backup --path /etc --path /var/www --id $(hostname) --one-file-system --exclude '*.tmp'
toutwaf-backup client snapshots
toutwaf-backup client schedule --daily 02:30 --id $(hostname) --path /etc --path /var/www --install
systemctl daemon-reload && systemctl enable --now toutwaf-backup-$(hostname).timer
```

`client init --create-key` mostra a impressão digital do servidor para a confirmar, escreve o perfil e cria o ficheiro de chave, e depois mostra a **chave em papel**. **Guarde o ficheiro de chave, a sua frase-passe e a chave em papel longe da máquina**: sem eles ninguém pode restaurar (ver `RESTORE.md`). Para execuções sem supervisão ponha a frase-passe num ficheiro legível só por root e referencie-o no perfil. Estado de saída: 0 sucesso, 1 falha (nada confirmado), 2 confirmado com avisos. As bases de dados não precisam de ficheiro temporário:

```sh
mysqldump --single-transaction shop | toutwaf-backup client backup --type db --id shop --stdin --stdin-name shop.sql
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop
```

## Armazenamento de objetos S3

Um datastore pode guardar os seus fragmentos num bucket compatível com S3 (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO), e qualquer datastore pode ser copiado para um bucket de forma agendada. Na interface web: Datastores, *Criar um datastore*, **Armazenamento de objetos S3**, depois *Testar a ligação*. O guia completo, a linha de comandos e o procedimento de recuperação estão em [S3.md](S3.md).

## Montar um instantâneo (Linux)

```sh
toutwaf-backup client mount host/web1/latest /mnt/snap        # read-only; Ctrl-C or: fusermount3 -u /mnt/snap
```

O instantâneo aparece como uma árvore de diretórios só de leitura: nada é restaurado; os fragmentos de um ficheiro só são transferidos, decifrados e autenticados quando um programa os lê. Um fragmento que não pode ser autenticado dá um erro de E/S, nunca dados errados. Como utilizador normal, a montagem precisa do pacote `fuse3`.

## Windows

> **NÃO testado numa máquina Windows real nesta versão.** O binário do Windows é compilado de forma cruzada e o motor de cópia e restauro é o mesmo código testado em Linux, mas tudo o que é específico do Windows foi escrito segundo a documentação e nunca foi executado. Experimente primeiro numa máquina não crítica.

```powershell
# in an elevated PowerShell
irm https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.ps1 -OutFile install.ps1    # read it, then:
.\install.ps1 -Role server -ExternalUrl https://backup.example.net:8007 -Datastore main=D:\Backups\main -Start
.\install.ps1 -Role client
```

As mesmas opções existem como parâmetros (`-Channel`, `-Version`, `-BaseUrl`, `-InstallDir`, `-StateDir`, `-Listen`, `-NoInit`, `-Start`, `-NoFirewall`, `-Uninstall`, `-Purge`, `-Force`, `-Yes`, `-Lang`). O script verifica a assinatura Ed25519 em PowerShell puro, instala `toutwaf-backup.exe`, adiciona-o ao PATH do sistema e, para o servidor, restringe o diretório de estado, instala o serviço do Windows e uma regra de firewall (apenas perfis Domínio e Privado). O que difere do Linux:

* `client mount` existe apenas em Linux; no Windows use `client ls`, `client find`, `client cat` e `client restore`.
* A cópia a partir de uma Cópia de Sombra de Volume (`--vss`) está **não testada e desativada** a menos que a variável de ambiente `TWB_ENABLE_UNTESTED_VSS=1` esteja definida.
* Os descritores de segurança NTFS são registados em cada cópia, mas o seu **restauro** não está testado e fica desativado a menos que `TWB_ENABLE_UNTESTED_WIN_ACL=1` esteja definido. Caminhos longos, junções, fluxos de dados alternativos e EFS não estão testados ou não são tratados.
* `install.ps1`, a sua verificação de assinatura em PowerShell puro, o serviço do Windows, a regra de firewall e o ficheiro do Agendador de Tarefas gerado por `client schedule --target windows` nunca foram executados no Windows.

## Atualização, reversão, desinstalação

```sh
sudo ./install.sh --role server                         # run it again with the same options: upgrade
sudo mv /usr/local/bin/toutwaf-backup.prev /usr/local/bin/toutwaf-backup && sudo systemctl restart toutwaf-backup-server    # rollback
sudo ./install.sh --role server --uninstall            # keeps the data; add --purge to remove the configuration, the state and the user
```

O formato 1 e a API 1 são estáveis, por isso servidores e clientes de versões 0.x diferentes interoperam. A desinstalação mantém os dados, a menos que adicione `--purge`; os datastores fora do diretório de estado nunca são apagados.
