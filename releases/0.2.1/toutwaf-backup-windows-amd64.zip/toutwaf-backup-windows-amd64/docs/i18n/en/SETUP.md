**English** | [Français](../fr/SETUP.md) | [Español](../es/SETUP.md) | [Deutsch](../de/SETUP.md) | [Italiano](../it/SETUP.md) | [Português](../pt/SETUP.md) | [Nederlands](../nl/SETUP.md) | [Русский](../ru/SETUP.md) | [中文](../zh/SETUP.md) | [العربية](../ar/SETUP.md)

# First-run setup

A new server is closed until its administrator has set it up. The last screen of the installer prints one block: what was installed and where, a **single-use setup link** (`https://HOST:8007/setup/KEY`), the certificate fingerprint, the firewall reminder, how to get a new link and how to uninstall. Opening the link shows a wizard in ten languages; until it is finished, the web interface and the API refuse everything except the wizard (the home page says that the setup is pending).

## The four steps of the wizard

1. **Administrator**: choose the user name and the password (strength meter, at least 12 characters, nothing from the list of the most common passwords, no keyboard run, not containing the user name, and 16 characters or three kinds of characters). Optionally turn on two-factor authentication: scan the QR code, confirm with a code, and keep the eight **recovery codes** (shown once; each signs you in once if you lose your phone).
2. **Access token**: the first administrator token, shown **once** with a copy button, with what a token is, what the roles allow (administrator, writer, reader, auditor) and how to revoke it (Access, API tokens, or `toutwaf-backup server token revoke ID`). You can also create a token for ToutWAF, with the pairing instructions.
3. **Server**: name, external address (the server checks that it reaches that address over HTTPS, that the certificate answering there is its own and that it covers the name), listen address, the first datastore (a folder, with a writability and free-space check, or an S3 bucket with the connection test), default retention, e-mail and webhook notifications, update channel and automatic updates (telemetry: none, there is nothing to switch on).
4. **Summary and “Finish”**: everything is saved step by step; “Finish” consumes the link, turns on the normal sign-in and gives the next steps (install the client on the machines, pair with ToutWAF). A new listen address and the update settings that need root are listed with the exact commands.

## What protects the link

* The key in the link is 256 bits of randomness; the server keeps only its SHA-256 and never writes the key to a log, the audit log or a file. It is shown once, by the installer.
* The link is valid for 60 minutes, works until the wizard is finished and is **consumed** by “Finish”. It is tied to the fingerprint of the server certificate: if the certificate changes, the link is refused.
* Compare the fingerprint printed by the installer with the one at the top of the wizard before typing anything: if they differ, you are not talking to your server.
* Wrong keys are rate limited (5 per address, then a block of 5 minutes; 40 for the whole server). Nothing but the wizard answers until it is finished, except `/health` and API calls that carry a token root made on the machine (that is how ToutWAF's remote deployment keeps working).
* The administrator's password is stored as an Argon2id hash, recovery codes as SHA-256 hashes; tokens as SHA-256 hashes. Every step is recorded in the audit log (never the key, the password or a token).
* If the page, the key or the 60 minutes are lost, nothing is lost: make a new link on the server (below). The old one stops working at once.

## Get a link again

```sh
sudo toutwaf-backup server setup-link               # status: is a link valid, until when (it cannot be shown again)
sudo toutwaf-backup server setup-link --new         # a new link: the previous one stops working
sudo toutwaf-backup server setup-link --new --reopen   # on a finished setup: lock the web interface again until the wizard is completed once more
```

## Unattended installations

The wizard is for people. Scripts keep their own path: `--no-setup-link` keeps the old behaviour (a first admin token is printed), and an administrator and a first token can be preset; with a preset administrator the wizard skips its first step, the human can still open the link to set a user, a password and two-factor authentication of his own.

```sh
# no wizard: print a first admin token instead (as before 0.2.0)
sudo bash install.sh --role server --no-setup-link
# your own first token, and the administrator preset (nothing secret is printed)
toutwaf-backup server user hash --password-file pw.txt > admin.hash
sudo bash install.sh --role server --admin-token-file token.txt --admin-user ops --admin-password-hash-file admin.hash
```

## With ToutWAF

When ToutWAF deploys the server itself, it creates its own administrator token over SSH, keeps it sealed in its vault and keeps the setup link sealed too: on the server card, “Configure the server” opens the link (after you re-enter your ToutWAF password). That link is for the human administrator: his own user, password and two-factor authentication, and the server settings; ToutWAF keeps using its own token.
