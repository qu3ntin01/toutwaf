**English** | [Français](../fr/UPDATES.md) | [Español](../es/UPDATES.md) | [Deutsch](../de/UPDATES.md) | [Italiano](../it/UPDATES.md) | [Português](../pt/UPDATES.md) | [Nederlands](../nl/UPDATES.md) | [Русский](../ru/UPDATES.md) | [中文](../zh/UPDATES.md) | [العربية](../ar/UPDATES.md)

# Updates

ToutWAF Backup looks for, verifies and installs its own updates: the `toutwaf-backup update` command (server and client, Linux and Windows), the **Updates** page of the web interface, and on Linux a daily timer. Every release is signed with Ed25519 and every archive is checked with SHA-256 before anything is replaced.

## Commands

```sh
toutwaf-backup update status            # version, channel, whether an update is available, last check
toutwaf-backup update check             # look for an update; exit status 10 when there is one
toutwaf-backup update apply             # download, verify, install, restart the service, roll back if it does not stay up
toutwaf-backup update apply --version 0.2.1
toutwaf-backup update rollback          # put the previous version back (again: forward again)
toutwaf-backup update auto on|off       # the daily timer installs updates by itself, or only checks
toutwaf-backup update channel stable|dev
toutwaf-backup update ... --json        # machine-readable output, stable exit codes
toutwaf-backup update setup             # (root, once) the daily timer and the unit that serves the web interface
```

## Channels

`stable` carries the tested releases, `dev` the development builds. The channel is read from `channel.json` of the public release branch; a withdrawn (yanked) version is never offered and is refused unless `--force` is given. A release that needs a newer installer (`min_installer`) is refused with a request to run `install.sh` again. The program never downgrades silently.

Each channel has its own file on the public branch: `channels/stable.json` and `channels/dev.json` (installer 3 and the update manager read them). `channel.json` at the root is the pointer of the stable channel for older installers. A channel nobody has published on yet is an error (exit status 11), never a silent switch to another channel.

## What `update apply` does

1. Reads `channel.json`, checks that the version is not withdrawn and that the installer level is understood.
2. Verifies the Ed25519 signature of `SHA256SUMS` with the public key built into the program (nothing is trusted before that).
3. Compares the SHA-256 of the archive with the signed list.
4. Replaces the executable atomically; the previous one stays next to it as `toutwaf-backup.prev` (that is what `rollback` uses).
5. Restarts the server service (systemd) when it is running.
6. Checks that the service stays active (20 s to start, then 4 s of stability); otherwise the previous executable is put back and the service restarted (exit status 13).

## Exit status

* `0`: done, or already up to date.
* `1`: error (channel unreachable, download failed, executable not writable).
* `10`: `check` found an update.
* `11`: refused (withdrawn version, or a release that needs a newer installer).
* `12`: bad signature or checksum: nothing was installed.
* `13`: the new version did not stay up; the previous one was put back.
* `14`: `rollback` has no previous version.
* `64`: wrong usage.

## Web interface and API

The **Updates** page (administrators only, every action is written to the audit log) shows the installed version, the channel, the available update with its notes, the buttons Check, Install and Go back, the automatic-installation switch and the result of the last operation. The API is `GET /api/v1/system/update`, `POST /api/v1/system/update/check`, `POST /api/v1/system/update/apply`, `POST /api/v1/system/update/rollback` and `PUT /api/v1/system/update/settings`. The server does not run as root (its unit forbids writing below /usr), so it cannot replace itself: Check works directly, while Install, Go back and the settings are requests that a root unit executes. Install that unit once:

```sh
sudo toutwaf-backup update setup --state /var/lib/toutwaf-backup
```

`update setup` writes the units `toutwaf-backup-update.timer` (daily check at about 03:30), `toutwaf-backup-update.service`, `toutwaf-backup-update.path` and `toutwaf-backup-update-request.service`. Without them the page still checks, and tells you which command to run.

## Settings files

`/etc/toutwaf-backup/update.conf` (channel, automatic installation, release location) and `update.state` (last check and result) are the very files of the installer's update manager `toutwaf-backup-update`: both tools can be used on the same machine and see the same settings. `TOUTWAF_BACKUP_BASE_URL` or `--base-url` points to another release location (https, or a local file:// mirror).

## Windows

On Windows the command downloads, verifies and replaces `toutwaf-backup.exe` the same way, but it does not restart the service: restart it yourself (or run the installer again). The system package update of `install.sh` is Linux-only.
