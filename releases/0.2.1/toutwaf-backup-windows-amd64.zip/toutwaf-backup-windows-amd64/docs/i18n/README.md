# ToutWAF Backup: documentation in ten languages

The translations were written by a machine and have **not been reviewed by native speakers**. The English documents in [`docs/`](../) are the reference; the pages below cover installation, S3, restore and recovery, security and the ToutWAF link.

| Language | Pages |
|---|---|
| English | [INSTALL.md](en/INSTALL.md), [TOUTWAF-LINK.md](en/TOUTWAF-LINK.md), [README.md](en/README.md), [RESTORE.md](en/RESTORE.md), [S3.md](en/S3.md), [SECURITY.md](en/SECURITY.md), [SETUP.md](en/SETUP.md), [UPDATES.md](en/UPDATES.md) |
| Français | [INSTALL.md](fr/INSTALL.md), [TOUTWAF-LINK.md](fr/TOUTWAF-LINK.md), [README.md](fr/README.md), [RESTORE.md](fr/RESTORE.md), [S3.md](fr/S3.md), [SECURITY.md](fr/SECURITY.md), [SETUP.md](fr/SETUP.md), [UPDATES.md](fr/UPDATES.md) |
| Español | [INSTALL.md](es/INSTALL.md), [TOUTWAF-LINK.md](es/TOUTWAF-LINK.md), [README.md](es/README.md), [RESTORE.md](es/RESTORE.md), [S3.md](es/S3.md), [SECURITY.md](es/SECURITY.md), [SETUP.md](es/SETUP.md), [UPDATES.md](es/UPDATES.md) |
| Deutsch | [INSTALL.md](de/INSTALL.md), [TOUTWAF-LINK.md](de/TOUTWAF-LINK.md), [README.md](de/README.md), [RESTORE.md](de/RESTORE.md), [S3.md](de/S3.md), [SECURITY.md](de/SECURITY.md), [SETUP.md](de/SETUP.md), [UPDATES.md](de/UPDATES.md) |
| Italiano | [INSTALL.md](it/INSTALL.md), [TOUTWAF-LINK.md](it/TOUTWAF-LINK.md), [README.md](it/README.md), [RESTORE.md](it/RESTORE.md), [S3.md](it/S3.md), [SECURITY.md](it/SECURITY.md), [SETUP.md](it/SETUP.md), [UPDATES.md](it/UPDATES.md) |
| Português | [INSTALL.md](pt/INSTALL.md), [TOUTWAF-LINK.md](pt/TOUTWAF-LINK.md), [README.md](pt/README.md), [RESTORE.md](pt/RESTORE.md), [S3.md](pt/S3.md), [SECURITY.md](pt/SECURITY.md), [SETUP.md](pt/SETUP.md), [UPDATES.md](pt/UPDATES.md) |
| Nederlands | [INSTALL.md](nl/INSTALL.md), [TOUTWAF-LINK.md](nl/TOUTWAF-LINK.md), [README.md](nl/README.md), [RESTORE.md](nl/RESTORE.md), [S3.md](nl/S3.md), [SECURITY.md](nl/SECURITY.md), [SETUP.md](nl/SETUP.md), [UPDATES.md](nl/UPDATES.md) |
| Русский | [INSTALL.md](ru/INSTALL.md), [TOUTWAF-LINK.md](ru/TOUTWAF-LINK.md), [README.md](ru/README.md), [RESTORE.md](ru/RESTORE.md), [S3.md](ru/S3.md), [SECURITY.md](ru/SECURITY.md), [SETUP.md](ru/SETUP.md), [UPDATES.md](ru/UPDATES.md) |
| 中文 | [INSTALL.md](zh/INSTALL.md), [TOUTWAF-LINK.md](zh/TOUTWAF-LINK.md), [README.md](zh/README.md), [RESTORE.md](zh/RESTORE.md), [S3.md](zh/S3.md), [SECURITY.md](zh/SECURITY.md), [SETUP.md](zh/SETUP.md), [UPDATES.md](zh/UPDATES.md) |
| العربية | [INSTALL.md](ar/INSTALL.md), [TOUTWAF-LINK.md](ar/TOUTWAF-LINK.md), [README.md](ar/README.md), [RESTORE.md](ar/RESTORE.md), [S3.md](ar/S3.md), [SECURITY.md](ar/SECURITY.md), [SETUP.md](ar/SETUP.md), [UPDATES.md](ar/UPDATES.md) |
