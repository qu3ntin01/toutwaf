[English](../en/UPDATES.md) | **Français** | [Español](../es/UPDATES.md) | [Deutsch](../de/UPDATES.md) | [Italiano](../it/UPDATES.md) | [Português](../pt/UPDATES.md) | [Nederlands](../nl/UPDATES.md) | [Русский](../ru/UPDATES.md) | [中文](../zh/UPDATES.md) | [العربية](../ar/UPDATES.md)

# Mises à jour

ToutWAF Backup cherche, vérifie et installe lui-même ses mises à jour : la commande `toutwaf-backup update` (serveur et client, Linux et Windows), la page **Mises à jour** de l'interface web et, sous Linux, une minuterie quotidienne. Chaque version est signée en Ed25519 et chaque archive est contrôlée en SHA-256 avant tout remplacement.

## Commandes

```sh
toutwaf-backup update status            # version, channel, whether an update is available, last check
toutwaf-backup update check             # look for an update; exit status 10 when there is one
toutwaf-backup update apply             # download, verify, install, restart the service, roll back if it does not stay up
toutwaf-backup update apply --version 0.2.1
toutwaf-backup update rollback          # put the previous version back (again: forward again)
toutwaf-backup update auto on|off       # the daily timer installs updates by itself, or only checks
toutwaf-backup update channel stable|dev
toutwaf-backup update ... --json        # machine-readable output, stable exit codes
toutwaf-backup update setup             # (root, once) the daily timer and the unit that serves the web interface
```

## Canaux

`stable` porte les versions testées, `dev` les versions de développement. Le canal est lu dans `channel.json` de la branche publique ; une version retirée (yanked) n'est jamais proposée et est refusée sauf avec `--force`. Une version qui exige un installateur plus récent (`min_installer`) est refusée, avec l'invitation à relancer `install.sh`. Le programme ne rétrograde jamais en silence.

Chaque canal a son propre fichier sur la branche publique : `channels/stable.json` et `channels/dev.json` (l'installateur 3 et le gestionnaire de mises à jour les lisent). `channel.json` à la racine est le pointeur du canal stable pour les installateurs plus anciens. Un canal sur lequel rien n'a encore été publié est une erreur (code de sortie 11), jamais un basculement silencieux vers un autre canal.

## Ce que fait `update apply`

1. Lit `channel.json`, vérifie que la version n'est pas retirée et que le niveau d'installateur est compris.
2. Vérifie la signature Ed25519 de `SHA256SUMS` avec la clé publique intégrée au programme (rien n'est cru avant cela).
3. Compare le SHA-256 de l'archive à la liste signée.
4. Remplace l'exécutable de façon atomique ; l'ancien reste à côté sous le nom `toutwaf-backup.prev` (c'est ce que `rollback` utilise).
5. Redémarre le service du serveur (systemd) s'il tourne.
6. Vérifie que le service reste actif (20 s pour démarrer, puis 4 s de stabilité) ; sinon l'ancien exécutable est remis et le service redémarré (code de sortie 13).

## Codes de sortie

* `0` : fait, ou déjà à jour.
* `1` : erreur (canal inaccessible, téléchargement échoué, exécutable non modifiable).
* `10` : `check` a trouvé une mise à jour.
* `11` : refusé (version retirée, ou version qui exige un installateur plus récent).
* `12` : signature ou somme de contrôle incorrecte : rien n'a été installé.
* `13` : la nouvelle version n'est pas restée en service ; l'ancienne a été remise.
* `14` : `rollback` n'a pas de version précédente.
* `64` : mauvaise utilisation.

## Interface web et API

La page **Mises à jour** (administrateurs seulement, chaque action est inscrite au journal d'audit) montre la version installée, le canal, la mise à jour disponible avec ses notes, les boutons Vérifier, Installer et Revenir en arrière, l'interrupteur d'installation automatique et le résultat de la dernière opération. L'API : `GET /api/v1/system/update`, `POST /api/v1/system/update/check`, `POST /api/v1/system/update/apply`, `POST /api/v1/system/update/rollback` et `PUT /api/v1/system/update/settings`. Le serveur ne tourne pas en root (son unité interdit d'écrire sous /usr) : il ne peut donc pas se remplacer lui-même. La vérification marche directement ; l'installation, le retour arrière et les réglages sont des demandes qu'une unité root exécute. Installez cette unité une fois :

```sh
sudo toutwaf-backup update setup --state /var/lib/toutwaf-backup
```

`update setup` écrit les unités `toutwaf-backup-update.timer` (vérification quotidienne vers 03 h 30), `toutwaf-backup-update.service`, `toutwaf-backup-update.path` et `toutwaf-backup-update-request.service`. Sans elles, la page vérifie quand même et indique la commande à lancer.

## Fichiers de réglages

`/etc/toutwaf-backup/update.conf` (canal, installation automatique, emplacement des versions) et `update.state` (dernière vérification et résultat) sont exactement les fichiers du gestionnaire de mises à jour de l'installateur, `toutwaf-backup-update` : les deux outils peuvent servir sur la même machine et voient les mêmes réglages. `TOUTWAF_BACKUP_BASE_URL` ou `--base-url` désigne un autre emplacement (https, ou un miroir local file://).

## Windows

Sous Windows, la commande télécharge, vérifie et remplace `toutwaf-backup.exe` de la même façon, mais ne redémarre pas le service : redémarrez-le vous-même (ou relancez l'installateur). La mise à jour des paquets système de `install.sh` n'existe que sous Linux.
