[English](../en/SETUP.md) | **Français** | [Español](../es/SETUP.md) | [Deutsch](../de/SETUP.md) | [Italiano](../it/SETUP.md) | [Português](../pt/SETUP.md) | [Nederlands](../nl/SETUP.md) | [Русский](../ru/SETUP.md) | [中文](../zh/SETUP.md) | [العربية](../ar/SETUP.md)

# Configuration initiale

Un nouveau serveur reste fermé tant que son administrateur ne l'a pas configuré. Le dernier écran de l'installeur affiche un bloc : ce qui a été installé et où, un **lien de configuration à usage unique** (`https://HOTE:8007/setup/CLE`), l'empreinte du certificat, le rappel du pare-feu, comment obtenir un nouveau lien et comment désinstaller. Le lien ouvre un assistant en dix langues ; tant qu'il n'est pas terminé, l'interface web et l'API refusent tout sauf l'assistant (la page d'accueil indique que la configuration est en attente).

## Les quatre étapes de l'assistant

1. **Administrateur** : choisissez le nom d'utilisateur et le mot de passe (jauge de robustesse, au moins 12 caractères, rien de la liste des mots de passe les plus courants, pas de suite de touches, sans le nom d'utilisateur, et 16 caractères ou trois types de caractères). En option, activez la double authentification : scannez le QR code, confirmez avec un code et conservez les huit **codes de secours** (affichés une fois ; chacun permet de se connecter une fois si vous perdez votre téléphone).
2. **Jeton d'accès** : le premier jeton d'administration, affiché **une seule fois** avec un bouton de copie, avec ce qu'est un jeton, ce que permettent les rôles (administrateur, écriture, lecture, audit) et comment le révoquer (Accès, Jetons d'API, ou `toutwaf-backup server token revoke ID`). Vous pouvez aussi créer un jeton pour ToutWAF, avec les instructions d'appairage.
3. **Serveur** : nom, adresse externe (le serveur vérifie qu'il joint cette adresse en HTTPS, que le certificat qui y répond est le sien et qu'il couvre le nom), adresse d'écoute, premier espace de stockage (un dossier, avec contrôle d'écriture et d'espace libre, ou un bucket S3 avec test de connexion), rétention par défaut, notifications par e-mail et webhook, canal de mise à jour et mises à jour automatiques (télémétrie : aucune, il n'y a rien à activer).
4. **Résumé et « Terminer »** : tout est enregistré étape par étape ; « Terminer » consomme le lien, active la connexion normale et donne les étapes suivantes (installer le client sur les machines, appairer avec ToutWAF). Une nouvelle adresse d'écoute et les réglages de mise à jour qui demandent root sont listés avec les commandes exactes.

## Ce qui protège le lien

* La clé du lien fait 256 bits aléatoires ; le serveur n'en garde que le SHA-256 et n'écrit jamais la clé dans un journal, dans le journal d'audit ou dans un fichier. Elle n'est affichée qu'une fois, par l'installeur.
* Le lien est valable 60 minutes, fonctionne jusqu'à la fin de l'assistant et est **consommé** par « Terminer ». Il est lié à l'empreinte du certificat du serveur : si le certificat change, le lien est refusé.
* Comparez l'empreinte affichée par l'installeur avec celle en haut de l'assistant avant de saisir quoi que ce soit : si elles diffèrent, vous ne parlez pas à votre serveur.
* Les clés fausses sont limitées (5 par adresse, puis blocage de 5 minutes ; 40 pour tout le serveur). Rien d'autre que l'assistant ne répond tant qu'il n'est pas terminé, sauf `/health` et les appels d'API portant un jeton créé par root sur la machine (c'est ainsi que le déploiement distant de ToutWAF continue de fonctionner).
* Le mot de passe de l'administrateur est stocké sous forme de hachage Argon2id, les codes de secours et les jetons sous forme de hachages SHA-256. Chaque étape est consignée dans le journal d'audit (jamais la clé, le mot de passe ni un jeton).
* Si la page, la clé ou les 60 minutes sont perdues, rien n'est perdu : créez un nouveau lien sur le serveur (ci-dessous). L'ancien cesse de fonctionner aussitôt.

## Obtenir de nouveau un lien

```sh
sudo toutwaf-backup server setup-link               # status: is a link valid, until when (it cannot be shown again)
sudo toutwaf-backup server setup-link --new         # a new link: the previous one stops working
sudo toutwaf-backup server setup-link --new --reopen   # on a finished setup: lock the web interface again until the wizard is completed once more
```

## Installations sans surveillance

L'assistant est pour les personnes. Les scripts gardent leur chemin : `--no-setup-link` conserve l'ancien comportement (un premier jeton d'administration est affiché), et un administrateur et un premier jeton peuvent être pré-définis ; avec un administrateur pré-défini l'assistant saute sa première étape, et la personne peut toujours ouvrir le lien pour choisir son propre utilisateur, mot de passe et double authentification.

```sh
# no wizard: print a first admin token instead (as before 0.2.0)
sudo bash install.sh --role server --no-setup-link
# your own first token, and the administrator preset (nothing secret is printed)
toutwaf-backup server user hash --password-file pw.txt > admin.hash
sudo bash install.sh --role server --admin-token-file token.txt --admin-user ops --admin-password-hash-file admin.hash
```

## Avec ToutWAF

Quand ToutWAF déploie lui-même le serveur, il crée son propre jeton d'administration par SSH, le garde scellé dans son coffre et garde aussi le lien de configuration scellé : sur la carte du serveur, « Configurer le serveur » ouvre le lien (après nouvelle saisie de votre mot de passe ToutWAF). Ce lien est destiné à l'administrateur humain : son propre utilisateur, mot de passe et double authentification, et les réglages du serveur ; ToutWAF continue d'utiliser son propre jeton.
