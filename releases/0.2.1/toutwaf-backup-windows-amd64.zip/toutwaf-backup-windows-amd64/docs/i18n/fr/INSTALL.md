[English](../en/INSTALL.md) | **Français** | [Español](../es/INSTALL.md) | [Deutsch](../de/INSTALL.md) | [Italiano](../it/INSTALL.md) | [Português](../pt/INSTALL.md) | [Nederlands](../nl/INSTALL.md) | [Русский](../ru/INSTALL.md) | [中文](../zh/INSTALL.md) | [العربية](../ar/INSTALL.md)

# Installation

Pris en charge : Linux (amd64 et arm64, avec systemd) et Windows (amd64, **non testé sur une vraie machine Windows**). L'installeur Linux a besoin de `bash`, `curl` ou `wget`, `tar`, `sha256sum`, `base64` et **OpenSSL 3** pour vérifier la signature. Le binaire lui-même est un seul fichier statique.

## Où installer le serveur (à lire en premier)

Installer ToutWAF Backup est **optionnel**. Le **serveur doit tourner sur une autre machine que ToutWAF** : une sauvegarde stockée sur la machine qu'elle protège ne survit pas à la perte de cette machine (panne de disque, rançongiciel, incendie, vol). `install.sh --role server` et `install.ps1 -Role server` cherchent ToutWAF sur l'hôte et **refusent**, avec le code de sortie 3, s'ils le trouvent ; `toutwaf-backup server run` fait la même vérification au démarrage. Le rôle client n'est jamais refusé.

## Installation sous Linux

```sh
# server (the machine that stores the backups)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role server \
    --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start

# client (every machine to protect)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role client
```

L'installeur télécharge `channel.json`, puis `SHA256SUMS` et sa signature ; il **vérifie la signature Ed25519** avec la clé publique intégrée au script, puis le **SHA-256 de l'archive** par rapport à la liste signée, et refuse une version retirée. Il installe `toutwaf-backup` de façon atomique (le binaire précédent est conservé sous `toutwaf-backup.prev`). Pour le rôle serveur, il crée aussi l'utilisateur système, le répertoire d'état, l'unité systemd et, à la première installation, la configuration : il affiche un bloc avec un lien de configuration à usage unique (valable 60 minutes, affiché une seule fois) et l'empreinte du certificat : ouvrez le lien pour choisir l'administrateur, obtenir le premier jeton et configurer le serveur (voir SETUP.md). Rien ne démarre sans `--start`. Il est idempotent : relancez-le pour mettre à jour.

**Langue des installeurs.** `install.sh` et `install.ps1` parlent les dix langues : ils suivent `--lang fr` (ou `--fr`, `--es`, `--de` ... ; `-Lang fr` sous Windows), puis `TWB_LANG`, puis la langue du système (`LC_ALL`, `LANG` ; la langue d'affichage de Windows), puis l'anglais. Les accents et les écritures non latines demandent un terminal UTF-8 ; sinon l'installeur parle anglais. Les noms d'options, les commandes et les noms de fichiers ne sont jamais traduits.

## Serveur : premiers pas

```sh
systemctl enable --now toutwaf-backup-server       # if you did not pass --start
toutwaf-backup server token create --name web1 --role writer --datastore main --namespace hosts/web1 --append-only
toutwaf-backup server datastore set main --require-encryption=true --quota 2T --immutable-days 7
```

* Ouvrez le port (8007 par défaut) à vos clients uniquement. L'interface web est `https://HOTE:8007/` (connexion avec le jeton d'administration). Le certificat est autosigné, les navigateurs avertissent donc : comparez l'empreinte affichée dans **Paramètres** avec `toutwaf-backup server fingerprint`.
* Créez un jeton par client et ne partagez jamais le jeton d'administration. Un jeton `writer` peut sauvegarder mais ne peut ni lire ni supprimer.
* Le mode *ajout seul* sur un datastore signifie que personne ne peut supprimer via l'API ; le désactiver exige `toutwaf-backup server datastore set main --append-only=false` sur la machine du serveur elle-même.
* Planifiez les tâches propres du serveur dans l'interface web (**Tâches**) : une vérification hebdomadaire, un élagage quotidien (pas sur un datastore en ajout seul), une libération d'espace hebdomadaire, et une copie hors site vers un second serveur, un disque ou un bucket S3. Les notifications (courriel, webhooks signés) sont dans **Paramètres**.
* Sauvegardez l'état propre du serveur (`/var/lib/toutwaf-backup` : configuration, jetons, clé TLS, journal d'audit) avec un client vers un autre serveur. Perdre la clé TLS oblige chaque client à épingler la nouvelle empreinte.

## Client : premiers pas

```sh
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --namespace hosts/web1 --create-key
toutwaf-backup client backup --path /etc --path /var/www --id $(hostname) --one-file-system --exclude '*.tmp'
toutwaf-backup client snapshots
toutwaf-backup client schedule --daily 02:30 --id $(hostname) --path /etc --path /var/www --install
systemctl daemon-reload && systemctl enable --now toutwaf-backup-$(hostname).timer
```

`client init --create-key` affiche l'empreinte du serveur pour que vous la confirmiez, écrit le profil et crée le fichier de clé, puis affiche la **clé papier**. **Conservez le fichier de clé, sa phrase secrète et la clé papier hors de la machine** : sans eux, personne ne peut restaurer (voir `RESTORE.md`). Pour les exécutions sans surveillance, mettez la phrase secrète dans un fichier lisible par root seul et référencez-le dans le profil. Code de sortie : 0 succès, 1 échec (rien de validé), 2 validé avec avertissements. Les bases de données n'ont pas besoin de fichier temporaire :

```sh
mysqldump --single-transaction shop | toutwaf-backup client backup --type db --id shop --stdin --stdin-name shop.sql
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop
```

## Stockage objet S3

Un datastore peut garder ses fragments dans un bucket compatible S3 (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO), et n'importe quel datastore peut être copié vers un bucket selon un calendrier. Dans l'interface web : Datastores, *Créer un datastore*, **Stockage objet S3**, puis *Tester la connexion*. Le guide complet, la ligne de commande et la procédure de reprise sont dans [S3.md](S3.md).

## Monter un instantané (Linux)

```sh
toutwaf-backup client mount host/web1/latest /mnt/snap        # read-only; Ctrl-C or: fusermount3 -u /mnt/snap
```

L'instantané apparaît comme une arborescence en lecture seule : rien n'est restauré ; les fragments d'un fichier ne sont téléchargés, déchiffrés et authentifiés que lorsqu'un programme les lit. Un fragment impossible à authentifier donne une erreur d'E/S, jamais de mauvaises données. En utilisateur normal, le montage demande le paquet `fuse3`.

## Windows

> **NON TESTÉ sur une vraie machine Windows dans cette version.** Le binaire Windows est compilé en croisé et le moteur de sauvegarde et de restauration est le même code que celui testé sous Linux, mais tout ce qui est propre à Windows a été écrit d'après la documentation et n'a jamais été exécuté. Essayez d'abord sur une machine non critique.

```powershell
# in an elevated PowerShell
irm https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.ps1 -OutFile install.ps1    # read it, then:
.\install.ps1 -Role server -ExternalUrl https://backup.example.net:8007 -Datastore main=D:\Backups\main -Start
.\install.ps1 -Role client
```

Les mêmes options existent comme paramètres (`-Channel`, `-Version`, `-BaseUrl`, `-InstallDir`, `-StateDir`, `-Listen`, `-NoInit`, `-Start`, `-NoFirewall`, `-Uninstall`, `-Purge`, `-Force`, `-Yes`, `-Lang`). Le script vérifie la signature Ed25519 en PowerShell pur, installe `toutwaf-backup.exe`, l'ajoute au PATH système et, pour le serveur, restreint le répertoire d'état, installe le service Windows et une règle de pare-feu (profils Domaine et Privé uniquement). Ce qui diffère de Linux :

* `client mount` n'existe que sous Linux ; sous Windows, utilisez `client ls`, `client find`, `client cat` et `client restore`.
* La sauvegarde depuis un cliché instantané de volume (`--vss`) est **non testée et désactivée** sauf si la variable d'environnement `TWB_ENABLE_UNTESTED_VSS=1` est définie.
* Les descripteurs de sécurité NTFS sont enregistrés dans chaque sauvegarde, mais leur **restauration** n'est pas testée et reste désactivée sauf si `TWB_ENABLE_UNTESTED_WIN_ACL=1` est défini. Les chemins longs, les jonctions, les flux de données alternatifs et EFS ne sont pas testés ou pas gérés.
* `install.ps1`, sa vérification de signature en PowerShell pur, le service Windows, la règle de pare-feu et le fichier du Planificateur de tâches produit par `client schedule --target windows` n'ont jamais été exécutés sous Windows.

## Mise à jour, retour arrière, désinstallation

```sh
sudo ./install.sh --role server                         # run it again with the same options: upgrade
sudo mv /usr/local/bin/toutwaf-backup.prev /usr/local/bin/toutwaf-backup && sudo systemctl restart toutwaf-backup-server    # rollback
sudo ./install.sh --role server --uninstall            # keeps the data; add --purge to remove the configuration, the state and the user
```

Le format 1 et l'API 1 sont stables : serveurs et clients de versions 0.x différentes interopèrent. La désinstallation conserve les données sauf avec `--purge` ; les datastores situés hors du répertoire d'état ne sont jamais supprimés.
