[English](../en/INSTALL.md) | [Français](../fr/INSTALL.md) | [Español](../es/INSTALL.md) | [Deutsch](../de/INSTALL.md) | [Italiano](../it/INSTALL.md) | [Português](../pt/INSTALL.md) | [Nederlands](../nl/INSTALL.md) | [Русский](../ru/INSTALL.md) | [中文](../zh/INSTALL.md) | **العربية**

<div dir="rtl">

# التثبيت

المدعوم: Linux (amd64 وarm64 مع systemd) وWindows (amd64، **لم يُختبر على جهاز Windows حقيقي**). يحتاج مثبّت Linux إلى `bash` و`curl` أو `wget` و`tar` و`sha256sum` و`base64` و**OpenSSL 3** للتحقق من التوقيع. الملف التنفيذي نفسه ملف ثابت واحد.

## أين يوضع الخادم (اقرأ هذا أولًا)

تثبيت ToutWAF Backup **اختياري**. **يجب أن يعمل الخادم على جهاز مختلف عن جهاز ToutWAF**: النسخة المخزَّنة على الجهاز الذي تحميه لا تنجو من فقدانه (عطل القرص أو برمجيات الفدية أو الحريق أو السرقة). يبحث `install.sh --role server` و`install.ps1 -Role server` عن ToutWAF على المضيف و**يرفضان** بحالة خروج 3 إذا وجداه؛ ويجري `toutwaf-backup server run` الفحص نفسه عند البدء. دور العميل لا يُرفض أبدًا.

## التثبيت على Linux

```sh
# server (the machine that stores the backups)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role server \
    --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start

# client (every machine to protect)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role client
```

ينزّل المثبّت `channel.json` ثم `SHA256SUMS` وتوقيعه؛ و**يتحقق من توقيع Ed25519** بالمفتاح العام المضمَّن في السكربت، ثم من **SHA-256 للأرشيف** مقابل القائمة الموقَّعة، ويرفض الإصدار المسحوب. ويثبّت `toutwaf-backup` بشكل ذري (يُحفظ الملف التنفيذي السابق باسم `toutwaf-backup.prev`). وفي دور الخادم ينشئ أيضًا مستخدم النظام ودليل الحالة ووحدة systemd، وعند أول تثبيت الإعدادات: يعرض كتلة فيها رابط إعداد لمرة واحدة (صالح 60 دقيقة ويُعرض مرة واحدة) وبصمة الشهادة: افتح الرابط لاختيار المسؤول والحصول على أول رمز وإعداد الخادم (انظر SETUP.md). لا يبدأ شيء دون `--start`. وهو متكرر الأمان: شغّله مجددًا للترقية.

**لغة المثبّتات.** يتحدث `install.sh` و`install.ps1` اللغات العشر: يتبعان `--lang fr` (أو `--fr` و`--es` و`--de` ...؛ وعلى Windows `-Lang fr`) ثم `TWB_LANG` ثم لغة النظام (`LC_ALL` و`LANG`؛ ولغة العرض في Windows) ثم الإنجليزية. تحتاج الحروف المُشكَّلة والكتابات غير اللاتينية إلى طرفية UTF-8، وإلا تحدث المثبّت بالإنجليزية. أسماء الخيارات والأوامر وأسماء الملفات لا تُترجم أبدًا.

## الخادم: الخطوات الأولى

```sh
systemctl enable --now toutwaf-backup-server       # if you did not pass --start
toutwaf-backup server token create --name web1 --role writer --datastore main --namespace hosts/web1 --append-only
toutwaf-backup server datastore set main --require-encryption=true --quota 2T --immutable-days 7
```

* افتح المنفذ (8007 افتراضيًا) لعملائك فقط. واجهة الويب هي `https://HOST:8007/` (سجّل الدخول برمز المسؤول). الشهادة موقّعة ذاتيًا لذلك تحذّر المتصفحات: قارن البصمة المعروضة في **إعدادات** بناتج `toutwaf-backup server fingerprint`.
* أنشئ رمزًا لكل عميل ولا تشارك رمز المسؤول أبدًا. يستطيع رمز `writer` النسخ لكنه لا يستطيع القراءة ولا الحذف.
* وضع *الإضافة فقط* على مخزن بيانات يعني أن لا أحد يستطيع الحذف عبر واجهة API؛ ولإيقافه يلزم تنفيذ `toutwaf-backup server datastore set main --append-only=false` على جهاز الخادم نفسه.
* جدول مهام الخادم نفسه في واجهة الويب (**المهام**): تحقق أسبوعي، وتنظيف يومي (ليس على مخزن بيانات للإضافة فقط)، واسترداد مساحة أسبوعي، ونسخة خارج الموقع إلى خادم ثانٍ أو قرص أو حاوية S3. الإشعارات (البريد وwebhook الموقَّعة) في **إعدادات**.
* انسخ حالة الخادم نفسه (`/var/lib/toutwaf-backup`: الإعدادات والرموز ومفتاح TLS وسجل التدقيق) بواسطة عميل إلى خادم آخر. فقدان مفتاح TLS يعني أن على كل عميل تثبيت البصمة الجديدة.

## العميل: الخطوات الأولى

```sh
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --namespace hosts/web1 --create-key
toutwaf-backup client backup --path /etc --path /var/www --id $(hostname) --one-file-system --exclude '*.tmp'
toutwaf-backup client snapshots
toutwaf-backup client schedule --daily 02:30 --id $(hostname) --path /etc --path /var/www --install
systemctl daemon-reload && systemctl enable --now toutwaf-backup-$(hostname).timer
```

يعرض `client init --create-key` بصمة الخادم لتؤكدها، ويكتب الملف الشخصي وينشئ ملف المفتاح، ثم يطبع **المفتاح الورقي**. **احتفظ بملف المفتاح وعبارته السرية والمفتاح الورقي بعيدًا عن الجهاز**: بدونها لا يستطيع أحد الاستعادة (انظر `RESTORE.md`). للتشغيل دون إشراف ضع العبارة السرية في ملف يقرؤه root فقط وأشر إليه في الملف الشخصي. حالة الخروج: 0 نجاح، 1 فشل (لم يُثبَّت شيء)، 2 ثُبِّتت مع تحذيرات. لا تحتاج قواعد البيانات إلى ملف مؤقت:

```sh
mysqldump --single-transaction shop | toutwaf-backup client backup --type db --id shop --stdin --stdin-name shop.sql
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop
```

## تخزين الكائنات S3

يمكن لمخزن البيانات أن يحتفظ بأجزائه في حاوية متوافقة مع S3 (AWS S3 وBackblaze B2 وWasabi وScaleway وOVH وCloudflare R2 وMinIO)، ويمكن نسخ أي مخزن بيانات إلى حاوية وفق جدول. في واجهة الويب: مخازن البيانات، *إنشاء مخزن بيانات*، **تخزين الكائنات S3**، ثم *اختبار الاتصال*. الدليل الكامل وسطر الأوامر وإجراء الاستعادة في [S3.md](S3.md).

## تركيب لقطة (Linux)

```sh
toutwaf-backup client mount host/web1/latest /mnt/snap        # read-only; Ctrl-C or: fusermount3 -u /mnt/snap
```

تظهر اللقطة كشجرة أدلة للقراءة فقط: لا تُستعاد أي بيانات؛ وتُنزَّل أجزاء الملف وتُفك وتُوثَّق فقط عندما يقرأها برنامج. الجزء الذي لا يمكن توثيقه يعطي خطأ إدخال/إخراج وليس بيانات خاطئة. يحتاج المستخدم العادي إلى الحزمة `fuse3` للتركيب.

## Windows

> **لم يُختبر على جهاز Windows حقيقي في هذا الإصدار.** الملف التنفيذي لـ Windows مُجمَّع تجميعًا متقاطعًا، ومحرك النسخ والاستعادة هو الشيفرة نفسها المختبرة على Linux، لكن كل ما هو خاص بـ Windows كُتب وفق الوثائق ولم يعمل قط. جرّبه أولًا على جهاز غير حرج.

```powershell
# in an elevated PowerShell
irm https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.ps1 -OutFile install.ps1    # read it, then:
.\install.ps1 -Role server -ExternalUrl https://backup.example.net:8007 -Datastore main=D:\Backups\main -Start
.\install.ps1 -Role client
```

الخيارات نفسها متاحة كمعاملات (`-Channel` و`-Version` و`-BaseUrl` و`-InstallDir` و`-StateDir` و`-Listen` و`-NoInit` و`-Start` و`-NoFirewall` و`-Uninstall` و`-Purge` و`-Force` و`-Yes` و`-Lang`). يتحقق السكربت من توقيع Ed25519 بـ PowerShell الخالص، ويثبّت `toutwaf-backup.exe` ويضيفه إلى PATH للنظام، وللخادم يقيّد دليل الحالة ويثبّت خدمة Windows وقاعدة جدار حماية (ملفا النطاق والخاص فقط). ما يختلف عن Linux:

* `client mount` متاح على Linux فقط؛ وعلى Windows استخدم `client ls` و`client find` و`client cat` و`client restore`.
* النسخ من نسخة الظل للوحدة (`--vss`) **غير مختبر ومعطّل** ما لم يُضبط متغير البيئة `TWB_ENABLE_UNTESTED_VSS=1`.
* تُسجَّل واصفات أمان NTFS في كل نسخة، لكن **استعادتها** غير مختبرة ومعطّلة ما لم يُضبط `TWB_ENABLE_UNTESTED_WIN_ACL=1`. المسارات الطويلة ونقاط الوصل وتدفقات البيانات البديلة وEFS غير مختبرة أو غير مدعومة.
* لم يُشغَّل `install.ps1` ولا فحص التوقيع فيه بـ PowerShell الخالص ولا خدمة Windows ولا قاعدة جدار الحماية ولا ملف مجدول المهام الذي ينتجه `client schedule --target windows` على Windows قط.

## الترقية والتراجع وإزالة التثبيت

```sh
sudo ./install.sh --role server                         # run it again with the same options: upgrade
sudo mv /usr/local/bin/toutwaf-backup.prev /usr/local/bin/toutwaf-backup && sudo systemctl restart toutwaf-backup-server    # rollback
sudo ./install.sh --role server --uninstall            # keeps the data; add --purge to remove the configuration, the state and the user
```

التنسيق 1 وواجهة API 1 مستقران، لذلك تعمل الخوادم والعملاء من إصدارات 0.x مختلفة معًا. تُبقي الإزالة البيانات ما لم تضف `--purge`؛ ولا تُحذف مخازن البيانات الواقعة خارج دليل الحالة أبدًا.

</div>
