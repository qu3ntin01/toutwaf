[English](../en/UPDATES.md) | [Français](../fr/UPDATES.md) | [Español](../es/UPDATES.md) | [Deutsch](../de/UPDATES.md) | [Italiano](../it/UPDATES.md) | [Português](../pt/UPDATES.md) | [Nederlands](../nl/UPDATES.md) | [Русский](../ru/UPDATES.md) | [中文](../zh/UPDATES.md) | **العربية**

<div dir="rtl">

# التحديثات

يبحث ToutWAF Backup عن تحديثاته ويتحقق منها ويثبّتها بنفسه: الأمر `toutwaf-backup update` (الخادم والعميل، Linux وWindows)، وصفحة **التحديثات** في واجهة الويب، ومؤقّت يومي على Linux. كل إصدار موقّع بـ Ed25519 وكل أرشيف يُفحص بـ SHA-256 قبل استبدال أي شيء.

## الأوامر

```sh
toutwaf-backup update status            # version, channel, whether an update is available, last check
toutwaf-backup update check             # look for an update; exit status 10 when there is one
toutwaf-backup update apply             # download, verify, install, restart the service, roll back if it does not stay up
toutwaf-backup update apply --version 0.2.1
toutwaf-backup update rollback          # put the previous version back (again: forward again)
toutwaf-backup update auto on|off       # the daily timer installs updates by itself, or only checks
toutwaf-backup update channel stable|dev
toutwaf-backup update ... --json        # machine-readable output, stable exit codes
toutwaf-backup update setup             # (root, once) the daily timer and the unit that serves the web interface
```

## القنوات

تحتوي `stable` على الإصدارات المختبرة و`dev` على نسخ التطوير. تُقرأ القناة من `channel.json` في الفرع العام؛ لا يُعرض إصدار مسحوب (yanked) أبدًا ويُرفض ما لم يُستخدم `--force`. يُرفض الإصدار الذي يتطلب مثبّتًا أحدث (`min_installer`) مع طلب تشغيل `install.sh` مجددًا. لا يتراجع البرنامج إلى إصدار أقدم بصمت.

لكل قناة ملفها الخاص في الفرع العام: `channels/stable.json` و`channels/dev.json` (يقرؤهما المثبّت 3 ومدير التحديثات). أما `channel.json` في الجذر فهو مؤشر القناة المستقرة للمثبّتات الأقدم. القناة التي لم يُنشر عليها شيء بعد تُعدّ خطأ (رمز الخروج 11) ولا تُحوَّل بصمت إلى قناة أخرى.

## ما يفعله `update apply`

1. يقرأ `channel.json` ويتحقق من أن الإصدار غير مسحوب وأن مستوى المثبّت مفهوم.
2. يتحقق من توقيع Ed25519 للملف `SHA256SUMS` بالمفتاح العام المدمج في البرنامج (لا يُوثق بأي شيء قبل ذلك).
3. يقارن SHA-256 للأرشيف بالقائمة الموقّعة.
4. يستبدل الملف التنفيذي ذريًا؛ ويبقى السابق بجانبه باسم `toutwaf-backup.prev` (وهو ما يستخدمه `rollback`).
5. يعيد تشغيل خدمة الخادم (systemd) إن كانت تعمل.
6. يتحقق من بقاء الخدمة نشطة (20 ثانية للإقلاع ثم 4 ثوانٍ من الاستقرار)؛ وإلا يعيد الملف التنفيذي السابق ويعيد تشغيل الخدمة (رمز الخروج 13).

## رموز الخروج

* `0`: تم، أو محدَّث بالفعل.
* `1`: خطأ (القناة غير متاحة، فشل التنزيل، الملف التنفيذي غير قابل للكتابة).
* `10`: وجد `check` تحديثًا.
* `11`: مرفوض (إصدار مسحوب، أو إصدار يتطلب مثبّتًا أحدث).
* `12`: توقيع أو مجموع تحقق غير صحيح: لم يتم تثبيت أي شيء.
* `13`: لم يستمر الإصدار الجديد في العمل؛ تمت استعادة السابق.
* `14`: لا يوجد إصدار سابق لـ `rollback`.
* `64`: استخدام خاطئ.

## واجهة الويب وواجهة API

تعرض صفحة **التحديثات** (للمسؤولين فقط، وكل إجراء يُسجَّل في سجل التدقيق) الإصدار المثبّت والقناة والتحديث المتاح مع ملاحظاته وأزرار الفحص والتثبيت والتراجع ومفتاح التثبيت التلقائي ونتيجة آخر عملية. واجهة API: `GET /api/v1/system/update` و`POST /api/v1/system/update/check` و`POST /api/v1/system/update/apply` و`POST /api/v1/system/update/rollback` و`PUT /api/v1/system/update/settings`. لا يعمل الخادم بصلاحية root (وحدته تمنع الكتابة تحت /usr) فلا يستطيع استبدال نفسه: الفحص يعمل مباشرة، أما التثبيت والتراجع والإعدادات فطلبات تنفّذها وحدة root. ثبّت هذه الوحدة مرة واحدة:

```sh
sudo toutwaf-backup update setup --state /var/lib/toutwaf-backup
```

يكتب `update setup` الوحدات `toutwaf-backup-update.timer` (فحص يومي نحو الساعة 03:30) و`toutwaf-backup-update.service` و`toutwaf-backup-update.path` و`toutwaf-backup-update-request.service`. بدونها تظل الصفحة تفحص وتخبرك بالأمر الواجب تشغيله.

## ملفات الإعدادات

الملفان `/etc/toutwaf-backup/update.conf` (القناة، التثبيت التلقائي، موقع الإصدارات) و`update.state` (آخر فحص ونتيجته) هما نفس ملفي مدير التحديثات في المثبّت `toutwaf-backup-update`: يمكن استخدام الأداتين على الجهاز نفسه وترى الإعدادات ذاتها. يشير `TOUTWAF_BACKUP_BASE_URL` أو `--base-url` إلى موقع آخر (https أو مرآة محلية file://).

## Windows

على Windows ينزّل الأمر الملف `toutwaf-backup.exe` ويتحقق منه ويستبدله بالطريقة نفسها لكنه لا يعيد تشغيل الخدمة: أعد تشغيلها بنفسك (أو شغّل المثبّت مجددًا). تحديث حزم النظام في `install.sh` متاح على Linux فقط.

</div>
