[English](../en/UPDATES.md) | [Français](../fr/UPDATES.md) | [Español](../es/UPDATES.md) | [Deutsch](../de/UPDATES.md) | [Italiano](../it/UPDATES.md) | [Português](../pt/UPDATES.md) | [Nederlands](../nl/UPDATES.md) | [Русский](../ru/UPDATES.md) | **中文** | [العربية](../ar/UPDATES.md)

# 更新

ToutWAF Backup 会自行查找、验证并安装更新：`toutwaf-backup update` 命令（服务器和客户端，Linux 和 Windows）、网页界面的**更新**页面，以及 Linux 上的每日定时器。每个版本都使用 Ed25519 签名，每个压缩包在替换任何文件之前都用 SHA-256 校验。

## 命令

```sh
toutwaf-backup update status            # version, channel, whether an update is available, last check
toutwaf-backup update check             # look for an update; exit status 10 when there is one
toutwaf-backup update apply             # download, verify, install, restart the service, roll back if it does not stay up
toutwaf-backup update apply --version 0.2.1
toutwaf-backup update rollback          # put the previous version back (again: forward again)
toutwaf-backup update auto on|off       # the daily timer installs updates by itself, or only checks
toutwaf-backup update channel stable|dev
toutwaf-backup update ... --json        # machine-readable output, stable exit codes
toutwaf-backup update setup             # (root, once) the daily timer and the unit that serves the web interface
```

## 渠道

`stable` 提供经过测试的版本，`dev` 提供开发构建。渠道从公共分支的 `channel.json` 读取；已撤回（yanked）的版本不会被提供，除非使用 `--force` 否则会被拒绝。需要更新安装程序的版本（`min_installer`）会被拒绝，并提示重新运行 `install.sh`。程序绝不会悄悄降级。

每个渠道在公共分支上都有自己的文件：`channels/stable.json` 和 `channels/dev.json`（安装程序 3 和更新管理器读取它们）。根目录的 `channel.json` 是供旧版安装程序使用的 stable 渠道指针。尚未发布任何版本的渠道会报错（退出码 11），绝不会悄悄切换到其他渠道。

## `update apply` 的步骤

1. 读取 `channel.json`，检查版本未被撤回且能识别安装程序级别。
2. 使用程序内置的公钥验证 `SHA256SUMS` 的 Ed25519 签名（在此之前不信任任何内容）。
3. 将压缩包的 SHA-256 与已签名的清单比对。
4. 原子地替换可执行文件；旧版本以 `toutwaf-backup.prev` 保留在旁边（`rollback` 使用它）。
5. 如果服务器服务正在运行，则重启它（systemd）。
6. 检查服务保持运行（启动 20 秒，随后稳定 4 秒）；否则恢复旧的可执行文件并重启服务（退出码 13）。

## 退出码

* `0`：完成，或已是最新。
* `1`：错误（渠道不可达、下载失败、可执行文件不可写）。
* `10`：`check` 发现了更新。
* `11`：被拒绝（版本已撤回，或需要更新的安装程序）。
* `12`：签名或校验和错误：未安装任何内容。
* `13`：新版本未能保持运行；已恢复旧版本。
* `14`：`rollback` 没有上一版本。
* `64`：用法错误。

## 网页界面与 API

**更新**页面（仅管理员可用，每个操作都会写入审计日志）显示已安装版本、渠道、带说明的可用更新、“检查”“安装”“回退”按钮、自动安装开关以及上次操作的结果。API 为 `GET /api/v1/system/update`、`POST /api/v1/system/update/check`、`POST /api/v1/system/update/apply`、`POST /api/v1/system/update/rollback` 和 `PUT /api/v1/system/update/settings`。服务器不以 root 运行（其单元禁止写入 /usr 之下），因此无法替换自身：检查可直接进行，而安装、回退和设置是由 root 单元执行的请求。请安装该单元一次：

```sh
sudo toutwaf-backup update setup --state /var/lib/toutwaf-backup
```

`update setup` 会写入单元 `toutwaf-backup-update.timer`（每日约 03:30 检查）、`toutwaf-backup-update.service`、`toutwaf-backup-update.path` 和 `toutwaf-backup-update-request.service`。没有它们时，页面仍可检查，并提示要运行的命令。

## 设置文件

`/etc/toutwaf-backup/update.conf`（渠道、自动安装、发布位置）和 `update.state`（上次检查及结果）正是安装程序的更新管理器 `toutwaf-backup-update` 所用的文件：两个工具可在同一台机器上使用，看到相同的设置。`TOUTWAF_BACKUP_BASE_URL` 或 `--base-url` 可指向其他位置（https 或本地 file:// 镜像）。

## Windows

在 Windows 上，该命令以同样方式下载、验证并替换 `toutwaf-backup.exe`，但不会重启服务：请自行重启（或重新运行安装程序）。`install.sh` 的系统软件包更新仅限 Linux。
