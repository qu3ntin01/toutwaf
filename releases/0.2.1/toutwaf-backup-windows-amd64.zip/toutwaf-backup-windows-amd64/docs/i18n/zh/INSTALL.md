[English](../en/INSTALL.md) | [Français](../fr/INSTALL.md) | [Español](../es/INSTALL.md) | [Deutsch](../de/INSTALL.md) | [Italiano](../it/INSTALL.md) | [Português](../pt/INSTALL.md) | [Nederlands](../nl/INSTALL.md) | [Русский](../ru/INSTALL.md) | **中文** | [العربية](../ar/INSTALL.md)

# 安装

支持：Linux（amd64 和 arm64，使用 systemd）和 Windows（amd64，**尚未在真实的 Windows 机器上测试**）。Linux 安装程序需要 `bash`、`curl` 或 `wget`、`tar`、`sha256sum`、`base64` 以及用于验证签名的 **OpenSSL 3**。可执行文件本身是单个静态文件。

## 服务器装在哪里（请先阅读）

安装 ToutWAF Backup 是**可选的**。**服务器必须运行在与 ToutWAF 不同的机器上**：存放在被保护机器本身的备份，无法在该机器丢失时幸存（磁盘故障、勒索软件、火灾、失窃）。`install.sh --role server` 和 `install.ps1 -Role server` 会在主机上查找 ToutWAF，找到则**拒绝**并以退出状态 3 结束；`toutwaf-backup server run` 在启动时做同样的检查。客户端角色从不被拒绝。

## 在 Linux 上安装

```sh
# server (the machine that stores the backups)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role server \
    --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start

# client (every machine to protect)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role client
```

安装程序先下载 `channel.json`，再下载 `SHA256SUMS` 及其签名；用脚本内置的公钥**验证 Ed25519 签名**，然后对照已签名列表验证**压缩包的 SHA-256**，并拒绝已撤回的版本。它以原子方式安装 `toutwaf-backup`（旧的可执行文件保留为 `toutwaf-backup.prev`）。服务器角色还会创建系统用户、状态目录、systemd 单元，首次安装时还会创建配置：显示一个包含一次性设置链接（有效期 60 分钟，只显示一次）和证书指纹的信息块：打开链接即可选择管理员、获取第一个令牌并配置服务器（见 SETUP.md）。不加 `--start` 则不会启动任何服务。安装程序是幂等的：再次运行即可升级。

**安装程序的语言。** `install.sh` 和 `install.ps1` 支持十种语言：依次遵循 `--lang fr`（或 `--fr`、`--es`、`--de` ...；Windows 上用 `-Lang fr`）、`TWB_LANG`、系统语言（`LC_ALL`、`LANG`；Windows 的显示语言），最后是英语。带重音的字母和非拉丁文字需要 UTF-8 终端，否则安装程序使用英语。选项名称、命令和文件名从不翻译。

## 服务器：初次使用

```sh
systemctl enable --now toutwaf-backup-server       # if you did not pass --start
toutwaf-backup server token create --name web1 --role writer --datastore main --namespace hosts/web1 --append-only
toutwaf-backup server datastore set main --require-encryption=true --quota 2T --immutable-days 7
```

* 只对您的客户端开放端口（默认 8007）。网页界面是 `https://HOST:8007/`（用管理员令牌登录）。证书是自签名的，所以浏览器会警告：请把**设置**中显示的指纹与 `toutwaf-backup server fingerprint` 的输出核对。
* 为每个客户端创建一个令牌，绝不共享管理员令牌。`writer` 令牌可以备份，但不能读取或删除。
* 数据存储的*仅追加*模式意味着任何人都无法通过 API 删除；要关闭它，必须在服务器本机上运行 `toutwaf-backup server datastore set main --append-only=false`。
* 在网页界面的**作业**中安排服务器自身的例行任务：每周一次验证、每日一次清理（仅追加的数据存储除外）、每周一次垃圾回收，以及到第二台服务器、磁盘或 S3 存储桶的异地副本。通知（电子邮件、已签名的 webhook）在**设置**中。
* 用客户端把服务器自身的状态（`/var/lib/toutwaf-backup`：配置、令牌、TLS 密钥、审计日志）备份到另一台服务器。丢失 TLS 密钥意味着每个客户端都必须重新固定新指纹。

## 客户端：初次使用

```sh
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --namespace hosts/web1 --create-key
toutwaf-backup client backup --path /etc --path /var/www --id $(hostname) --one-file-system --exclude '*.tmp'
toutwaf-backup client snapshots
toutwaf-backup client schedule --daily 02:30 --id $(hostname) --path /etc --path /var/www --install
systemctl daemon-reload && systemctl enable --now toutwaf-backup-$(hostname).timer
```

`client init --create-key` 会显示服务器指纹供您确认，写入配置档案并创建密钥文件，然后输出**纸质密钥**。**请把密钥文件、其口令和纸质密钥保存在这台机器之外**：没有它们，任何人都无法恢复（参见 `RESTORE.md`）。无人值守运行时，把口令放在只有 root 可读的文件中，并在配置档案里引用。退出状态：0 成功，1 失败（未提交任何内容），2 已提交但有警告。数据库备份不需要临时文件：

```sh
mysqldump --single-transaction shop | toutwaf-backup client backup --type db --id shop --stdin --stdin-name shop.sql
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop
```

## S3 对象存储

数据存储可以把数据块保存在兼容 S3 的存储桶中（AWS S3、Backblaze B2、Wasabi、Scaleway、OVH、Cloudflare R2、MinIO），任何数据存储也可以按计划复制到存储桶。在网页界面中：数据存储，*创建数据存储*，**S3 对象存储**，然后*测试连接*。完整指南、命令行和恢复流程见 [S3.md](S3.md)。

## 挂载快照（Linux）

```sh
toutwaf-backup client mount host/web1/latest /mnt/snap        # read-only; Ctrl-C or: fusermount3 -u /mnt/snap
```

快照以只读目录树的形式出现：不会恢复任何内容；只有当程序读取文件时，才会下载、解密并验证相应数据块。无法通过验证的数据块会产生 I/O 错误，而不会给出错误数据。普通用户挂载需要 `fuse3` 软件包。

## Windows

> **此版本尚未在真实的 Windows 机器上测试。** Windows 可执行文件是交叉编译的，备份与恢复引擎与在 Linux 上测试过的代码相同，但所有 Windows 专有部分都是对照文档编写的，从未运行过。请先在非关键机器上试用。

```powershell
# in an elevated PowerShell
irm https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.ps1 -OutFile install.ps1    # read it, then:
.\install.ps1 -Role server -ExternalUrl https://backup.example.net:8007 -Datastore main=D:\Backups\main -Start
.\install.ps1 -Role client
```

同样的选项以参数形式提供（`-Channel`、`-Version`、`-BaseUrl`、`-InstallDir`、`-StateDir`、`-Listen`、`-NoInit`、`-Start`、`-NoFirewall`、`-Uninstall`、`-Purge`、`-Force`、`-Yes`、`-Lang`）。脚本用纯 PowerShell 验证 Ed25519 签名，安装 `toutwaf-backup.exe` 并加入系统 PATH；对服务器角色，还会限制状态目录的访问权限，安装 Windows 服务和防火墙规则（仅限“域”和“专用”配置文件）。与 Linux 的不同之处：

* `client mount` 仅限 Linux；在 Windows 上请使用 `client ls`、`client find`、`client cat` 和 `client restore`。
* 从卷影复制（`--vss`）备份**尚未测试且默认禁用**，除非设置环境变量 `TWB_ENABLE_UNTESTED_VSS=1`。
* NTFS 安全描述符会记录在每次备份中，但**恢复**它们尚未测试，除非设置 `TWB_ENABLE_UNTESTED_WIN_ACL=1`，否则默认禁用。长路径、联接点、备用数据流和 EFS 要么未测试，要么不处理。
* `install.ps1`、它的纯 PowerShell 签名检查、Windows 服务、防火墙规则，以及 `client schedule --target windows` 生成的任务计划程序文件，都从未在 Windows 上运行过。

## 升级、回滚、卸载

```sh
sudo ./install.sh --role server                         # run it again with the same options: upgrade
sudo mv /usr/local/bin/toutwaf-backup.prev /usr/local/bin/toutwaf-backup && sudo systemctl restart toutwaf-backup-server    # rollback
sudo ./install.sh --role server --uninstall            # keeps the data; add --purge to remove the configuration, the state and the user
```

格式 1 和 API 1 是稳定的，因此不同 0.x 版本的服务器和客户端可以互通。卸载默认保留数据，除非加上 `--purge`；状态目录之外的数据存储永远不会被删除。
