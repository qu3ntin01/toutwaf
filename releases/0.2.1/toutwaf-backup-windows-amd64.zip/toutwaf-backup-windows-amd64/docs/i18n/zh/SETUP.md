[English](../en/SETUP.md) | [Français](../fr/SETUP.md) | [Español](../es/SETUP.md) | [Deutsch](../de/SETUP.md) | [Italiano](../it/SETUP.md) | [Português](../pt/SETUP.md) | [Nederlands](../nl/SETUP.md) | [Русский](../ru/SETUP.md) | **中文** | [العربية](../ar/SETUP.md)

# 首次设置

新服务器在管理员完成设置之前保持关闭。安装程序的最后一屏会打印一个信息块：安装了什么、装在哪里、**一次性设置链接**（`https://主机:8007/setup/密钥`）、证书指纹、防火墙提醒、如何获取新链接以及如何卸载。打开链接会显示十种语言的向导；在向导完成之前，网页界面和 API 会拒绝向导以外的一切请求（首页会提示设置尚未完成）。

## 向导的四个步骤

1. **管理员**：选择用户名和密码（强度指示，至少 12 个字符，不在最常见密码列表中，不含键盘连续字符，不含用户名，并且达到 16 个字符或包含三类字符）。可选择启用双因素认证：扫描二维码，用验证码确认，并保存八个**恢复码**（只显示一次；丢失手机时每个恢复码可登录一次）。
2. **访问令牌**：第一个管理员令牌，**只显示一次**并带复制按钮，同时说明什么是令牌、各角色的权限（管理员、写入、读取、审计）以及如何撤销（访问 → API 令牌，或 `toutwaf-backup server token revoke ID`）。还可以为 ToutWAF 创建令牌，并附有配对说明。
3. **服务器**：名称、外部地址（服务器会检查自己能否通过 HTTPS 访问该地址、该地址上响应的证书是否是自己的、证书是否覆盖该名称）、监听地址、第一个数据存储（文件夹，并检查可写性和剩余空间；或 S3 存储桶，并进行连接测试）、默认保留策略、电子邮件和 webhook 通知、更新通道和自动更新（遥测：无，没有可开启的选项）。
4. **摘要与“完成”**：每一步都会即时保存；“完成”会用掉链接、启用正常登录，并给出后续步骤（在各机器上安装客户端、与 ToutWAF 配对）。新的监听地址和需要 root 的更新设置会连同确切命令一起列出。

## 链接如何受到保护

* 链接中的密钥是 256 位随机数；服务器只保存其 SHA-256，绝不会把密钥写入日志、审计日志或文件。安装程序只显示一次。
* 链接有效期 60 分钟，在向导完成之前一直可用，并在点击“完成”时被**用掉**。它绑定到服务器证书的指纹：证书一旦更换，链接即被拒绝。
* 在输入任何内容之前，请将安装程序打印的指纹与向导顶部的指纹进行比对：若不一致，说明您连接的不是您的服务器。
* 错误的密钥会被限速（每个地址 5 次，然后封锁 5 分钟；整个服务器 40 次）。在向导完成之前，除向导外只有 `/health` 以及携带 root 在本机创建的令牌的 API 调用会得到响应（ToutWAF 的远程部署就是这样继续工作的）。
* 管理员密码以 Argon2id 哈希保存，恢复码和令牌以 SHA-256 哈希保存。每一步都会记录在审计日志中（绝不记录密钥、密码或令牌）。
* 如果页面、密钥或 60 分钟的时间丢失，不会有任何损失：在服务器上生成新链接即可（见下）。旧链接会立即失效。

## 再次获取链接

```sh
sudo toutwaf-backup server setup-link               # status: is a link valid, until when (it cannot be shown again)
sudo toutwaf-backup server setup-link --new         # a new link: the previous one stops working
sudo toutwaf-backup server setup-link --new --reopen   # on a finished setup: lock the web interface again until the wizard is completed once more
```

## 无人值守安装

向导是给人用的。脚本保留自己的路径：`--no-setup-link` 保持旧行为（打印第一个管理员令牌），也可预设管理员和第一个令牌；预设管理员后向导会跳过第一步，管理员本人仍可打开链接设置自己的用户、密码和双因素认证。

```sh
# no wizard: print a first admin token instead (as before 0.2.0)
sudo bash install.sh --role server --no-setup-link
# your own first token, and the administrator preset (nothing secret is printed)
toutwaf-backup server user hash --password-file pw.txt > admin.hash
sudo bash install.sh --role server --admin-token-file token.txt --admin-user ops --admin-password-hash-file admin.hash
```

## 与 ToutWAF 配合

当 ToutWAF 自行部署服务器时，它会通过 SSH 创建自己的管理员令牌并加密保存在保险库中，同样加密保存设置链接：在服务器卡片上点击“配置服务器”即可打开该链接（需重新输入 ToutWAF 密码）。该链接供人工管理员使用：设置他自己的用户、密码和双因素认证以及服务器设置；ToutWAF 继续使用自己的令牌。
