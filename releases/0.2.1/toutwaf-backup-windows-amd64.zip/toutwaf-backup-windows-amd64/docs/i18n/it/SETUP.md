[English](../en/SETUP.md) | [Français](../fr/SETUP.md) | [Español](../es/SETUP.md) | [Deutsch](../de/SETUP.md) | **Italiano** | [Português](../pt/SETUP.md) | [Nederlands](../nl/SETUP.md) | [Русский](../ru/SETUP.md) | [中文](../zh/SETUP.md) | [العربية](../ar/SETUP.md)

# Configurazione iniziale

Un nuovo server resta chiuso finché il suo amministratore non lo ha configurato. L'ultima schermata dell'installer mostra un blocco: cosa è stato installato e dove, un **link di configurazione monouso** (`https://HOST:8007/setup/CHIAVE`), l'impronta del certificato, il promemoria del firewall, come ottenere un nuovo link e come disinstallare. Il link apre una procedura guidata in dieci lingue; finché non è completata, l'interfaccia web e l'API rifiutano tutto tranne la procedura (la home page indica che la configurazione è in sospeso).

## I quattro passaggi della procedura

1. **Amministratore**: scegli nome utente e password (indicatore di robustezza, almeno 12 caratteri, nulla dall'elenco delle password più comuni, nessuna sequenza di tasti, senza il nome utente, e 16 caratteri o tre tipi di caratteri). Facoltativamente attiva l'autenticazione a due fattori: scansiona il QR code, conferma con un codice e conserva gli otto **codici di ripristino** (mostrati una volta; ciascuno permette di accedere una volta se perdi il telefono).
2. **Token di accesso**: il primo token di amministrazione, mostrato **una sola volta** con un pulsante di copia, con cosa è un token, cosa consentono i ruoli (amministratore, scrittura, lettura, audit) e come revocarlo (Accesso, Token API, oppure `toutwaf-backup server token revoke ID`). Puoi anche creare un token per ToutWAF, con le istruzioni di abbinamento.
3. **Server**: nome, indirizzo esterno (il server verifica di raggiungere quell'indirizzo via HTTPS, che il certificato che risponde sia il proprio e che copra il nome), indirizzo di ascolto, primo datastore (una cartella, con controllo di scrittura e spazio libero, o un bucket S3 con test di connessione), retention predefinita, notifiche e-mail e webhook, canale di aggiornamento e aggiornamenti automatici (telemetria: nessuna, non c'è nulla da attivare).
4. **Riepilogo e «Termina»**: tutto viene salvato passo per passo; «Termina» consuma il link, attiva l'accesso normale e indica i passi successivi (installare il client sulle macchine, abbinare a ToutWAF). Un nuovo indirizzo di ascolto e le impostazioni di aggiornamento che richiedono root sono elencati con i comandi esatti.

## Cosa protegge il link

* La chiave nel link è di 256 bit casuali; il server ne conserva solo lo SHA-256 e non scrive mai la chiave in un log, nel log di audit o in un file. Viene mostrata una sola volta, dall'installer.
* Il link è valido 60 minuti, funziona fino alla fine della procedura ed è **consumato** da «Termina». È legato all'impronta del certificato del server: se il certificato cambia, il link viene rifiutato.
* Confronta l'impronta mostrata dall'installer con quella in alto nella procedura prima di digitare qualsiasi cosa: se differiscono, non stai parlando con il tuo server.
* Le chiavi errate sono limitate (5 per indirizzo, poi un blocco di 5 minuti; 40 per tutto il server). Finché non è terminata risponde solo la procedura, eccetto `/health` e le chiamate API con un token creato da root sulla macchina (così continua a funzionare il deployment remoto di ToutWAF).
* La password dell'amministratore è conservata come hash Argon2id, i codici di ripristino e i token come hash SHA-256. Ogni passaggio è registrato nel log di audit (mai la chiave, la password o un token).
* Se la pagina, la chiave o i 60 minuti sono persi, non si perde nulla: crea un nuovo link sul server (sotto). Il vecchio smette subito di funzionare.

## Ottenere di nuovo un link

```sh
sudo toutwaf-backup server setup-link               # status: is a link valid, until when (it cannot be shown again)
sudo toutwaf-backup server setup-link --new         # a new link: the previous one stops working
sudo toutwaf-backup server setup-link --new --reopen   # on a finished setup: lock the web interface again until the wizard is completed once more
```

## Installazioni automatiche

La procedura è per le persone. Gli script mantengono il loro percorso: `--no-setup-link` mantiene il comportamento precedente (viene stampato un primo token di amministrazione), e si possono impostare in anticipo un amministratore e un primo token; con un amministratore predefinito la procedura salta il primo passo, e la persona può comunque aprire il link per scegliere il proprio utente, password e autenticazione a due fattori.

```sh
# no wizard: print a first admin token instead (as before 0.2.0)
sudo bash install.sh --role server --no-setup-link
# your own first token, and the administrator preset (nothing secret is printed)
toutwaf-backup server user hash --password-file pw.txt > admin.hash
sudo bash install.sh --role server --admin-token-file token.txt --admin-user ops --admin-password-hash-file admin.hash
```

## Con ToutWAF

Quando ToutWAF distribuisce il server, crea via SSH un proprio token di amministrazione, lo conserva sigillato nel suo caveau e conserva sigillato anche il link di configurazione: sulla scheda del server, «Configura il server» apre il link (dopo aver reinserito la tua password ToutWAF). Quel link è per l'amministratore umano: il suo utente, la sua password e l'autenticazione a due fattori, e le impostazioni del server; ToutWAF continua a usare il proprio token.
