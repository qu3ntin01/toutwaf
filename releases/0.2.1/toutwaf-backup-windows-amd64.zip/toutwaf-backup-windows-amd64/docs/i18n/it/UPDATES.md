[English](../en/UPDATES.md) | [Français](../fr/UPDATES.md) | [Español](../es/UPDATES.md) | [Deutsch](../de/UPDATES.md) | **Italiano** | [Português](../pt/UPDATES.md) | [Nederlands](../nl/UPDATES.md) | [Русский](../ru/UPDATES.md) | [中文](../zh/UPDATES.md) | [العربية](../ar/UPDATES.md)

# Aggiornamenti

ToutWAF Backup cerca, verifica e installa da solo i propri aggiornamenti: il comando `toutwaf-backup update` (server e client, Linux e Windows), la pagina **Aggiornamenti** dell'interfaccia web e, su Linux, un timer giornaliero. Ogni versione è firmata con Ed25519 e ogni archivio è controllato con SHA-256 prima di sostituire qualsiasi cosa.

## Comandi

```sh
toutwaf-backup update status            # version, channel, whether an update is available, last check
toutwaf-backup update check             # look for an update; exit status 10 when there is one
toutwaf-backup update apply             # download, verify, install, restart the service, roll back if it does not stay up
toutwaf-backup update apply --version 0.2.1
toutwaf-backup update rollback          # put the previous version back (again: forward again)
toutwaf-backup update auto on|off       # the daily timer installs updates by itself, or only checks
toutwaf-backup update channel stable|dev
toutwaf-backup update ... --json        # machine-readable output, stable exit codes
toutwaf-backup update setup             # (root, once) the daily timer and the unit that serves the web interface
```

## Canali

`stable` contiene le versioni testate, `dev` quelle di sviluppo. Il canale è letto da `channel.json` del ramo pubblico; una versione ritirata (yanked) non viene mai proposta ed è rifiutata salvo `--force`. Una versione che richiede un installer più recente (`min_installer`) è rifiutata, con l'invito a rieseguire `install.sh`. Il programma non torna mai indietro in silenzio.

Ogni canale ha il proprio file sul ramo pubblico: `channels/stable.json` e `channels/dev.json` (li leggono l'installer 3 e il gestore di aggiornamenti). `channel.json` nella radice è il puntatore del canale stable per gli installer più vecchi. Un canale su cui non è ancora stato pubblicato nulla è un errore (codice di uscita 11), mai un passaggio silenzioso a un altro canale.

## Cosa fa `update apply`

1. Legge `channel.json` e verifica che la versione non sia ritirata e che il livello dell'installer sia compreso.
2. Verifica la firma Ed25519 di `SHA256SUMS` con la chiave pubblica incorporata nel programma (prima non ci si fida di nulla).
3. Confronta lo SHA-256 dell'archivio con l'elenco firmato.
4. Sostituisce l'eseguibile in modo atomico; il precedente resta accanto come `toutwaf-backup.prev` (lo usa `rollback`).
5. Riavvia il servizio del server (systemd) se è in esecuzione.
6. Verifica che il servizio resti attivo (20 s per avviarsi, poi 4 s di stabilità); altrimenti rimette l'eseguibile precedente e riavvia il servizio (codice di uscita 13).

## Codici di uscita

* `0`: fatto, o già aggiornato.
* `1`: errore (canale irraggiungibile, download fallito, eseguibile non modificabile).
* `10`: `check` ha trovato un aggiornamento.
* `11`: rifiutato (versione ritirata, o versione che richiede un installer più recente).
* `12`: firma o checksum errati: non è stato installato nulla.
* `13`: la nuova versione non è rimasta attiva; è stata ripristinata la precedente.
* `14`: `rollback` non ha una versione precedente.
* `64`: uso errato.

## Interfaccia web e API

La pagina **Aggiornamenti** (solo amministratori; ogni azione è scritta nel registro di audit) mostra la versione installata, il canale, l'aggiornamento disponibile con le note, i pulsanti Controlla, Installa e Torna indietro, l'interruttore dell'installazione automatica e il risultato dell'ultima operazione. L'API: `GET /api/v1/system/update`, `POST /api/v1/system/update/check`, `POST /api/v1/system/update/apply`, `POST /api/v1/system/update/rollback` e `PUT /api/v1/system/update/settings`. Il server non gira come root (la sua unit vieta di scrivere sotto /usr), quindi non può sostituirsi da solo: Controlla funziona direttamente, mentre Installa, Torna indietro e le impostazioni sono richieste eseguite da una unit root. Installa quella unit una volta:

```sh
sudo toutwaf-backup update setup --state /var/lib/toutwaf-backup
```

`update setup` scrive le unit `toutwaf-backup-update.timer` (controllo giornaliero verso le 03:30), `toutwaf-backup-update.service`, `toutwaf-backup-update.path` e `toutwaf-backup-update-request.service`. Senza di esse la pagina controlla comunque e indica il comando da eseguire.

## File di impostazioni

`/etc/toutwaf-backup/update.conf` (canale, installazione automatica, posizione dei rilasci) e `update.state` (ultimo controllo e risultato) sono esattamente i file del gestore di aggiornamenti dell'installer, `toutwaf-backup-update`: i due strumenti possono essere usati sulla stessa macchina e vedono le stesse impostazioni. `TOUTWAF_BACKUP_BASE_URL` o `--base-url` indica un'altra posizione (https o un mirror locale file://).

## Windows

Su Windows il comando scarica, verifica e sostituisce `toutwaf-backup.exe` allo stesso modo, ma non riavvia il servizio: riavvialo tu (o riesegui l'installer). L'aggiornamento dei pacchetti di sistema di `install.sh` esiste solo su Linux.
