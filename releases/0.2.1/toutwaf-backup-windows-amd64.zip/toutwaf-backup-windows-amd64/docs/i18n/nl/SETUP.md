[English](../en/SETUP.md) | [Français](../fr/SETUP.md) | [Español](../es/SETUP.md) | [Deutsch](../de/SETUP.md) | [Italiano](../it/SETUP.md) | [Português](../pt/SETUP.md) | **Nederlands** | [Русский](../ru/SETUP.md) | [中文](../zh/SETUP.md) | [العربية](../ar/SETUP.md)

# Eerste configuratie

Een nieuwe server blijft dicht totdat de beheerder hem heeft geconfigureerd. Het laatste scherm van het installatieprogramma toont één blok: wat is geïnstalleerd en waar, een **eenmalige installatielink** (`https://HOST:8007/setup/SLEUTEL`), de vingerafdruk van het certificaat, de firewallherinnering, hoe u een nieuwe link krijgt en hoe u verwijdert. De link opent een wizard in tien talen; tot die klaar is, weigeren de webinterface en de API alles behalve de wizard (de startpagina meldt dat de configuratie in afwachting is).

## De vier stappen van de wizard

1. **Beheerder**: kies de gebruikersnaam en het wachtwoord (sterktemeter, minstens 12 tekens, niets uit de lijst van de meest gebruikte wachtwoorden, geen toetsenbordreeks, zonder de gebruikersnaam, en 16 tekens of drie soorten tekens). Schakel eventueel tweefactorauthenticatie in: scan de QR-code, bevestig met een code en bewaar de acht **herstelcodes** (eenmaal getoond; elk meldt u één keer aan als u uw telefoon kwijtraakt).
2. **Toegangstoken**: het eerste beheerderstoken, **eenmaal** getoond met een kopieerknop, met uitleg over wat een token is, wat de rollen toestaan (beheerder, schrijver, lezer, auditor) en hoe u het intrekt (Toegang, API-tokens, of `toutwaf-backup server token revoke ID`). U kunt ook een token voor ToutWAF maken, met de koppelingsinstructies.
3. **Server**: naam, extern adres (de server controleert of hij dat adres via HTTPS bereikt, of het certificaat dat daar antwoordt zijn eigen is en of het de naam dekt), luisteradres, eerste datastore (een map, met controle op schrijfrechten en vrije ruimte, of een S3-bucket met verbindingstest), standaardretentie, e-mail- en webhookmeldingen, updatekanaal en automatische updates (telemetrie: geen, er is niets in te schakelen).
4. **Samenvatting en “Voltooien”**: alles wordt stap voor stap opgeslagen; “Voltooien” verbruikt de link, schakelt de normale aanmelding in en geeft de volgende stappen (de client op de machines installeren, koppelen met ToutWAF). Een nieuw luisteradres en de update-instellingen die root vereisen worden met de exacte opdrachten getoond.

## Wat de link beschermt

* De sleutel in de link bestaat uit 256 willekeurige bits; de server bewaart alleen de SHA-256 ervan en schrijft de sleutel nooit naar een log, het auditlog of een bestand. Hij wordt maar één keer getoond, door het installatieprogramma.
* De link is 60 minuten geldig, werkt tot de wizard klaar is en wordt **verbruikt** door “Voltooien”. Hij is gebonden aan de vingerafdruk van het servercertificaat: verandert het certificaat, dan wordt de link geweigerd.
* Vergelijk de vingerafdruk van het installatieprogramma met die bovenaan de wizard voordat u iets invoert: verschillen ze, dan praat u niet met uw server.
* Foute sleutels worden begrensd (5 per adres, daarna 5 minuten blokkade; 40 voor de hele server). Tot de wizard klaar is, antwoordt niets anders dan de wizard, behalve `/health` en API-aanroepen met een token dat root op de machine heeft gemaakt (zo blijft de externe uitrol van ToutWAF werken).
* Het wachtwoord van de beheerder wordt als Argon2id-hash opgeslagen, herstelcodes en tokens als SHA-256-hashes. Elke stap wordt in het auditlog vastgelegd (nooit de sleutel, het wachtwoord of een token).
* Zijn de pagina, de sleutel of de 60 minuten kwijt, dan gaat er niets verloren: maak op de server een nieuwe link (hieronder). De oude werkt meteen niet meer.

## Opnieuw een link krijgen

```sh
sudo toutwaf-backup server setup-link               # status: is a link valid, until when (it cannot be shown again)
sudo toutwaf-backup server setup-link --new         # a new link: the previous one stops working
sudo toutwaf-backup server setup-link --new --reopen   # on a finished setup: lock the web interface again until the wizard is completed once more
```

## Installaties zonder toezicht

De wizard is voor mensen. Scripts behouden hun eigen pad: `--no-setup-link` behoudt het oude gedrag (een eerste beheerderstoken wordt getoond), en een beheerder en een eerste token kunnen vooraf worden ingesteld; met een vooraf ingestelde beheerder slaat de wizard zijn eerste stap over, de persoon kan de link nog steeds openen om een eigen gebruiker, wachtwoord en tweefactorauthenticatie te kiezen.

```sh
# no wizard: print a first admin token instead (as before 0.2.0)
sudo bash install.sh --role server --no-setup-link
# your own first token, and the administrator preset (nothing secret is printed)
toutwaf-backup server user hash --password-file pw.txt > admin.hash
sudo bash install.sh --role server --admin-token-file token.txt --admin-user ops --admin-password-hash-file admin.hash
```

## Met ToutWAF

Als ToutWAF de server zelf uitrolt, maakt het via SSH een eigen beheerderstoken, bewaart het verzegeld in zijn kluis en bewaart ook de installatielink verzegeld: op de serverkaart opent “De server configureren” de link (na opnieuw invoeren van uw ToutWAF-wachtwoord). Die link is voor de menselijke beheerder: eigen gebruiker, wachtwoord en tweefactorauthenticatie, en de serverinstellingen; ToutWAF blijft zijn eigen token gebruiken.
