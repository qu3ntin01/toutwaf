[English](../en/UPDATES.md) | [Français](../fr/UPDATES.md) | [Español](../es/UPDATES.md) | [Deutsch](../de/UPDATES.md) | [Italiano](../it/UPDATES.md) | [Português](../pt/UPDATES.md) | **Nederlands** | [Русский](../ru/UPDATES.md) | [中文](../zh/UPDATES.md) | [العربية](../ar/UPDATES.md)

# Updates

ToutWAF Backup zoekt, controleert en installeert zijn eigen updates: het commando `toutwaf-backup update` (server en client, Linux en Windows), de pagina **Updates** van de webinterface en op Linux een dagelijkse timer. Elke release is ondertekend met Ed25519 en elk archief wordt met SHA-256 gecontroleerd voordat iets wordt vervangen.

## Commando's

```sh
toutwaf-backup update status            # version, channel, whether an update is available, last check
toutwaf-backup update check             # look for an update; exit status 10 when there is one
toutwaf-backup update apply             # download, verify, install, restart the service, roll back if it does not stay up
toutwaf-backup update apply --version 0.2.1
toutwaf-backup update rollback          # put the previous version back (again: forward again)
toutwaf-backup update auto on|off       # the daily timer installs updates by itself, or only checks
toutwaf-backup update channel stable|dev
toutwaf-backup update ... --json        # machine-readable output, stable exit codes
toutwaf-backup update setup             # (root, once) the daily timer and the unit that serves the web interface
```

## Kanalen

`stable` bevat de geteste releases, `dev` de ontwikkelversies. Het kanaal wordt gelezen uit `channel.json` van de publieke branch; een ingetrokken (yanked) versie wordt nooit aangeboden en geweigerd tenzij `--force` wordt opgegeven. Een versie die een nieuwere installer vereist (`min_installer`) wordt geweigerd, met het verzoek `install.sh` opnieuw uit te voeren. Het programma gaat nooit stilzwijgend terug naar een oudere versie.

Elk kanaal heeft zijn eigen bestand op de publieke branch: `channels/stable.json` en `channels/dev.json` (installer 3 en het updatebeheer lezen ze). `channel.json` in de root is de verwijzing van het stabiele kanaal voor oudere installers. Een kanaal waarop nog niets is gepubliceerd is een fout (exitcode 11), nooit een stille overstap naar een ander kanaal.

## Wat `update apply` doet

1. Leest `channel.json` en controleert dat de versie niet is ingetrokken en het installerniveau wordt begrepen.
2. Controleert de Ed25519-handtekening van `SHA256SUMS` met de in het programma ingebouwde publieke sleutel (hiervoor wordt niets vertrouwd).
3. Vergelijkt de SHA-256 van het archief met de ondertekende lijst.
4. Vervangt het uitvoerbare bestand atomair; het vorige blijft ernaast als `toutwaf-backup.prev` (dat gebruikt `rollback`).
5. Herstart de serverdienst (systemd) als die draait.
6. Controleert dat de dienst actief blijft (20 s om te starten, daarna 4 s stabiliteit); anders wordt het vorige bestand teruggezet en de dienst herstart (exitcode 13).

## Exitcodes

* `0`: klaar, of al up-to-date.
* `1`: fout (kanaal onbereikbaar, download mislukt, bestand niet schrijfbaar).
* `10`: `check` vond een update.
* `11`: geweigerd (ingetrokken versie, of versie die een nieuwere installer vereist).
* `12`: onjuiste handtekening of controlesom: er is niets geïnstalleerd.
* `13`: de nieuwe versie bleef niet draaien; de vorige is teruggezet.
* `14`: `rollback` heeft geen vorige versie.
* `64`: onjuist gebruik.

## Webinterface en API

De pagina **Updates** (alleen beheerders; elke actie wordt in het auditlog vastgelegd) toont de geïnstalleerde versie, het kanaal, de beschikbare update met opmerkingen, de knoppen Controleren, Installeren en Teruggaan, de schakelaar voor automatisch installeren en het resultaat van de laatste bewerking. De API: `GET /api/v1/system/update`, `POST /api/v1/system/update/check`, `POST /api/v1/system/update/apply`, `POST /api/v1/system/update/rollback` en `PUT /api/v1/system/update/settings`. De server draait niet als root (zijn unit verbiedt schrijven onder /usr) en kan zichzelf dus niet vervangen: Controleren werkt direct, terwijl Installeren, Teruggaan en de instellingen verzoeken zijn die een root-unit uitvoert. Installeer die unit eenmalig:

```sh
sudo toutwaf-backup update setup --state /var/lib/toutwaf-backup
```

`update setup` schrijft de units `toutwaf-backup-update.timer` (dagelijkse controle rond 03:30), `toutwaf-backup-update.service`, `toutwaf-backup-update.path` en `toutwaf-backup-update-request.service`. Zonder deze controleert de pagina nog steeds en noemt het uit te voeren commando.

## Instellingenbestanden

`/etc/toutwaf-backup/update.conf` (kanaal, automatisch installeren, locatie van de releases) en `update.state` (laatste controle en resultaat) zijn precies de bestanden van het updatebeheer van de installer, `toutwaf-backup-update`: beide hulpmiddelen kunnen op dezelfde machine worden gebruikt en zien dezelfde instellingen. `TOUTWAF_BACKUP_BASE_URL` of `--base-url` wijst naar een andere locatie (https of een lokale file://-mirror).

## Windows

Onder Windows downloadt, controleert en vervangt het commando `toutwaf-backup.exe` op dezelfde manier, maar het herstart de dienst niet: herstart hem zelf (of voer de installer opnieuw uit). De update van systeempakketten van `install.sh` bestaat alleen op Linux.
