[English](../en/SETUP.md) | [Français](../fr/SETUP.md) | [Español](../es/SETUP.md) | **Deutsch** | [Italiano](../it/SETUP.md) | [Português](../pt/SETUP.md) | [Nederlands](../nl/SETUP.md) | [Русский](../ru/SETUP.md) | [中文](../zh/SETUP.md) | [العربية](../ar/SETUP.md)

# Ersteinrichtung

Ein neuer Server bleibt gesperrt, bis sein Administrator ihn eingerichtet hat. Der letzte Bildschirm des Installers zeigt einen Block: was installiert wurde und wo, einen **einmaligen Einrichtungslink** (`https://HOST:8007/setup/SCHLÜSSEL`), den Zertifikat-Fingerabdruck, den Firewall-Hinweis, wie man einen neuen Link erhält und wie man deinstalliert. Der Link öffnet einen Assistenten in zehn Sprachen; bis er abgeschlossen ist, verweigern Weboberfläche und API alles außer dem Assistenten (die Startseite meldet, dass die Einrichtung aussteht).

## Die vier Schritte des Assistenten

1. **Administrator**: Benutzername und Passwort wählen (Stärkeanzeige, mindestens 12 Zeichen, nichts aus der Liste der häufigsten Passwörter, keine Tastaturfolge, ohne den Benutzernamen, und 16 Zeichen oder drei Zeichenarten). Optional Zwei-Faktor-Authentifizierung einschalten: QR-Code scannen, mit einem Code bestätigen und die acht **Wiederherstellungscodes** aufbewahren (einmal angezeigt; jeder meldet Sie einmal an, wenn Sie Ihr Telefon verlieren).
2. **Zugriffstoken**: das erste Administrator-Token, **einmal** angezeigt mit Kopieren-Schaltfläche, mit der Erklärung, was ein Token ist, was die Rollen erlauben (Administrator, Schreiber, Leser, Auditor) und wie man es widerruft (Zugriff, API-Tokens, oder `toutwaf-backup server token revoke ID`). Sie können auch ein Token für ToutWAF erzeugen, mit der Kopplungsanleitung.
3. **Server**: Name, externe Adresse (der Server prüft, ob er diese Adresse per HTTPS erreicht, ob das dort antwortende Zertifikat sein eigenes ist und ob es den Namen abdeckt), Lauschadresse, erster Datenspeicher (ein Ordner, mit Schreib- und Platzprüfung, oder ein S3-Bucket mit Verbindungstest), Standard-Aufbewahrung, E-Mail- und Webhook-Benachrichtigungen, Update-Kanal und automatische Updates (Telemetrie: keine, es gibt nichts einzuschalten).
4. **Zusammenfassung und „Abschließen“**: Alles wird Schritt für Schritt gespeichert; „Abschließen“ verbraucht den Link, schaltet die normale Anmeldung frei und nennt die nächsten Schritte (Client auf den Rechnern installieren, mit ToutWAF koppeln). Eine neue Lauschadresse und die Update-Einstellungen, die root brauchen, werden mit den genauen Befehlen aufgelistet.

## Was den Link schützt

* Der Schlüssel im Link besteht aus 256 Zufallsbits; der Server speichert nur seinen SHA-256 und schreibt den Schlüssel nie in ein Log, das Audit-Log oder eine Datei. Er wird nur einmal vom Installer angezeigt.
* Der Link ist 60 Minuten gültig, funktioniert bis zum Ende des Assistenten und wird durch „Abschließen“ **verbraucht**. Er ist an den Fingerabdruck des Serverzertifikats gebunden: Ändert sich das Zertifikat, wird der Link abgelehnt.
* Vergleichen Sie den vom Installer angezeigten Fingerabdruck mit dem oben im Assistenten, bevor Sie etwas eingeben: Weichen sie ab, sprechen Sie nicht mit Ihrem Server.
* Falsche Schlüssel werden begrenzt (5 je Adresse, dann 5 Minuten Sperre; 40 für den ganzen Server). Bis zum Abschluss antwortet nur der Assistent, außer `/health` und API-Aufrufe mit einem Token, das root auf dem Rechner erzeugt hat (so funktioniert die Fernbereitstellung von ToutWAF weiter).
* Das Passwort des Administrators wird als Argon2id-Hash gespeichert, Wiederherstellungscodes und Tokens als SHA-256-Hashes. Jeder Schritt wird im Audit-Log festgehalten (nie der Schlüssel, das Passwort oder ein Token).
* Sind die Seite, der Schlüssel oder die 60 Minuten verloren, geht nichts verloren: Erzeugen Sie auf dem Server einen neuen Link (unten). Der alte funktioniert sofort nicht mehr.

## Einen Link erneut erhalten

```sh
sudo toutwaf-backup server setup-link               # status: is a link valid, until when (it cannot be shown again)
sudo toutwaf-backup server setup-link --new         # a new link: the previous one stops working
sudo toutwaf-backup server setup-link --new --reopen   # on a finished setup: lock the web interface again until the wizard is completed once more
```

## Unbeaufsichtigte Installationen

Der Assistent ist für Menschen. Skripte behalten ihren eigenen Weg: `--no-setup-link` behält das alte Verhalten (ein erstes Admin-Token wird ausgegeben), und ein Administrator sowie ein erstes Token können vorgegeben werden; bei vorgegebenem Administrator überspringt der Assistent seinen ersten Schritt, die Person kann den Link weiterhin öffnen, um eigenen Benutzer, eigenes Passwort und eigene Zwei-Faktor-Authentifizierung zu wählen.

```sh
# no wizard: print a first admin token instead (as before 0.2.0)
sudo bash install.sh --role server --no-setup-link
# your own first token, and the administrator preset (nothing secret is printed)
toutwaf-backup server user hash --password-file pw.txt > admin.hash
sudo bash install.sh --role server --admin-token-file token.txt --admin-user ops --admin-password-hash-file admin.hash
```

## Mit ToutWAF

Wenn ToutWAF den Server selbst bereitstellt, erzeugt es per SSH ein eigenes Administrator-Token, bewahrt es versiegelt im Tresor auf und hält auch den Einrichtungslink versiegelt: Auf der Serverkarte öffnet „Server konfigurieren“ den Link (nach erneuter Eingabe Ihres ToutWAF-Passworts). Dieser Link ist für den menschlichen Administrator: eigener Benutzer, eigenes Passwort und eigene Zwei-Faktor-Authentifizierung sowie die Servereinstellungen; ToutWAF nutzt weiter sein eigenes Token.
