[English](../en/INSTALL.md) | [Français](../fr/INSTALL.md) | [Español](../es/INSTALL.md) | **Deutsch** | [Italiano](../it/INSTALL.md) | [Português](../pt/INSTALL.md) | [Nederlands](../nl/INSTALL.md) | [Русский](../ru/INSTALL.md) | [中文](../zh/INSTALL.md) | [العربية](../ar/INSTALL.md)

# Installation

Unterstützt: Linux (amd64 und arm64, mit systemd) und Windows (amd64, **nicht auf einem echten Windows-Rechner getestet**). Der Linux-Installer braucht `bash`, `curl` oder `wget`, `tar`, `sha256sum`, `base64` und **OpenSSL 3**, um die Signatur zu prüfen. Die Programmdatei selbst ist eine einzige statische Datei.

## Wohin der Server gehört (zuerst lesen)

Die Installation von ToutWAF Backup ist **optional**. Der **Server muss auf einem anderen Rechner als ToutWAF laufen**: Eine Sicherung auf dem Rechner, den sie schützt, übersteht dessen Verlust nicht (Festplattenausfall, Ransomware, Brand, Diebstahl). `install.sh --role server` und `install.ps1 -Role server` suchen ToutWAF auf dem Host und **lehnen ab** (Exit-Status 3), wenn sie es finden; `toutwaf-backup server run` prüft dasselbe beim Start. Die Client-Rolle wird nie abgelehnt.

## Installation unter Linux

```sh
# server (the machine that stores the backups)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role server \
    --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start

# client (every machine to protect)
curl -fsSL https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.sh | sudo bash -s -- --role client
```

Der Installer lädt `channel.json`, dann `SHA256SUMS` und dessen Signatur herunter; er **prüft die Ed25519-Signatur** mit dem im Skript eingebauten öffentlichen Schlüssel, danach den **SHA-256 des Archivs** gegen die signierte Liste, und lehnt eine zurückgezogene Version ab. Er installiert `toutwaf-backup` atomar (die vorherige Programmdatei bleibt als `toutwaf-backup.prev` erhalten). Für die Server-Rolle legt er außerdem den Systembenutzer, das Statusverzeichnis, die systemd-Unit und bei der Erstinstallation die Konfiguration an: Er zeigt einen Block mit einem einmaligen Einrichtungslink (60 Minuten gültig, nur einmal angezeigt) und dem Zertifikat-Fingerabdruck: Über den Link wählen Sie den Administrator, erhalten das erste Token und konfigurieren den Server (siehe SETUP.md). Ohne `--start` startet nichts. Er ist idempotent: Zum Aktualisieren einfach erneut ausführen.

**Sprache der Installer.** `install.sh` und `install.ps1` sprechen die zehn Sprachen: Sie richten sich nach `--lang fr` (oder `--fr`, `--es`, `--de` ...; unter Windows `-Lang fr`), dann `TWB_LANG`, dann der Systemsprache (`LC_ALL`, `LANG`; die Anzeigesprache von Windows), dann Englisch. Akzente und nichtlateinische Schriften brauchen ein UTF-8-Terminal; sonst spricht der Installer Englisch. Optionsnamen, Befehle und Dateinamen werden nie übersetzt.

## Server: erste Schritte

```sh
systemctl enable --now toutwaf-backup-server       # if you did not pass --start
toutwaf-backup server token create --name web1 --role writer --datastore main --namespace hosts/web1 --append-only
toutwaf-backup server datastore set main --require-encryption=true --quota 2T --immutable-days 7
```

* Öffnen Sie den Port (standardmäßig 8007) nur für Ihre Clients. Die Weboberfläche ist `https://HOST:8007/` (Anmeldung mit dem Admin-Token). Das Zertifikat ist selbstsigniert, daher warnen Browser: Vergleichen Sie den unter **Einstellungen** angezeigten Fingerabdruck mit `toutwaf-backup server fingerprint`.
* Legen Sie pro Client ein Token an und geben Sie das Admin-Token nie weiter. Ein `writer`-Token kann sichern, aber weder lesen noch löschen.
* *Nur anhängen* bei einem Datastore bedeutet, dass über die API niemand löschen kann; zum Abschalten ist `toutwaf-backup server datastore set main --append-only=false` auf dem Server-Rechner selbst nötig.
* Planen Sie die eigenen Aufgaben des Servers in der Weboberfläche (**Aufträge**): eine wöchentliche Prüfung, eine tägliche Bereinigung (nicht bei einem Datastore mit „nur anhängen“), eine wöchentliche Speicherbereinigung und eine externe Kopie auf einen zweiten Server, einen Datenträger oder einen S3-Bucket. Benachrichtigungen (E-Mail, signierte Webhooks) finden Sie unter **Einstellungen**.
* Sichern Sie den eigenen Status des Servers (`/var/lib/toutwaf-backup`: Konfiguration, Tokens, TLS-Schlüssel, Audit-Protokoll) mit einem Client auf einen anderen Server. Geht der TLS-Schlüssel verloren, muss jeder Client den neuen Fingerabdruck pinnen.

## Client: erste Schritte

```sh
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --namespace hosts/web1 --create-key
toutwaf-backup client backup --path /etc --path /var/www --id $(hostname) --one-file-system --exclude '*.tmp'
toutwaf-backup client snapshots
toutwaf-backup client schedule --daily 02:30 --id $(hostname) --path /etc --path /var/www --install
systemctl daemon-reload && systemctl enable --now toutwaf-backup-$(hostname).timer
```

`client init --create-key` zeigt den Fingerabdruck des Servers zur Bestätigung an, schreibt das Profil und legt die Schlüsseldatei an, dann gibt es den **Papierschlüssel** aus. **Bewahren Sie Schlüsseldatei, Passphrase und Papierschlüssel getrennt von der Maschine auf**: Ohne sie kann niemand wiederherstellen (siehe `RESTORE.md`). Für unbeaufsichtigte Läufe legen Sie die Passphrase in eine nur für root lesbare Datei und verweisen im Profil darauf. Exit-Status: 0 Erfolg, 1 Fehler (nichts übernommen), 2 mit Warnungen übernommen. Datenbanken brauchen keine temporäre Datei:

```sh
mysqldump --single-transaction shop | toutwaf-backup client backup --type db --id shop --stdin --stdin-name shop.sql
toutwaf-backup client cat db/shop/latest shop.sql | mysql shop
```

## S3-Objektspeicher

Ein Datastore kann seine Chunks in einem S3-kompatiblen Bucket halten (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO), und jeder Datastore lässt sich nach Zeitplan in einen Bucket kopieren. In der Weboberfläche: Datastores, *Datastore anlegen*, **S3-Objektspeicher**, dann *Verbindung testen*. Die vollständige Anleitung, die Kommandozeile und das Wiederherstellungsverfahren stehen in [S3.md](S3.md).

## Einen Snapshot einbinden (Linux)

```sh
toutwaf-backup client mount host/web1/latest /mnt/snap        # read-only; Ctrl-C or: fusermount3 -u /mnt/snap
```

Der Snapshot erscheint als schreibgeschützter Verzeichnisbaum: Es wird nichts wiederhergestellt; die Chunks einer Datei werden erst heruntergeladen, entschlüsselt und authentifiziert, wenn ein Programm sie liest. Ein nicht authentifizierbarer Chunk ergibt einen E/A-Fehler, nie falsche Daten. Als normaler Benutzer braucht das Einbinden das Paket `fuse3`.

## Windows

> **In dieser Version NICHT auf einem echten Windows-Rechner getestet.** Die Windows-Programmdatei ist cross-kompiliert, und die Sicherungs- und Wiederherstellungs-Engine ist derselbe Code, der unter Linux getestet wird; alles Windows-Spezifische wurde jedoch nach der Dokumentation geschrieben und lief nie. Probieren Sie es zuerst auf einem unkritischen Rechner aus.

```powershell
# in an elevated PowerShell
irm https://repo.qu3ntin.com/toutwaf/toutwaf/-/raw/toutwaf-backup/install.ps1 -OutFile install.ps1    # read it, then:
.\install.ps1 -Role server -ExternalUrl https://backup.example.net:8007 -Datastore main=D:\Backups\main -Start
.\install.ps1 -Role client
```

Dieselben Optionen gibt es als Parameter (`-Channel`, `-Version`, `-BaseUrl`, `-InstallDir`, `-StateDir`, `-Listen`, `-NoInit`, `-Start`, `-NoFirewall`, `-Uninstall`, `-Purge`, `-Force`, `-Yes`, `-Lang`). Das Skript prüft die Ed25519-Signatur in reinem PowerShell, installiert `toutwaf-backup.exe`, trägt es in den System-PATH ein und schränkt für den Server das Statusverzeichnis ein, installiert den Windows-Dienst und eine Firewall-Regel (nur Profile Domäne und Privat). Was sich von Linux unterscheidet:

* `client mount` gibt es nur unter Linux; unter Windows verwenden Sie `client ls`, `client find`, `client cat` und `client restore`.
* Die Sicherung aus einer Volumeschattenkopie (`--vss`) ist **ungetestet und deaktiviert**, sofern nicht die Umgebungsvariable `TWB_ENABLE_UNTESTED_VSS=1` gesetzt ist.
* NTFS-Sicherheitsdeskriptoren werden in jeder Sicherung festgehalten, ihre **Wiederherstellung** ist aber ungetestet und deaktiviert, sofern nicht `TWB_ENABLE_UNTESTED_WIN_ACL=1` gesetzt ist. Lange Pfade, Junctions, alternative Datenströme und EFS sind ungetestet oder nicht behandelt.
* `install.ps1`, seine Signaturprüfung in reinem PowerShell, der Windows-Dienst, die Firewall-Regel und die von `client schedule --target windows` erzeugte Datei für die Aufgabenplanung wurden nie unter Windows ausgeführt.

## Aktualisieren, Zurückrollen, Deinstallieren

```sh
sudo ./install.sh --role server                         # run it again with the same options: upgrade
sudo mv /usr/local/bin/toutwaf-backup.prev /usr/local/bin/toutwaf-backup && sudo systemctl restart toutwaf-backup-server    # rollback
sudo ./install.sh --role server --uninstall            # keeps the data; add --purge to remove the configuration, the state and the user
```

Format 1 und API 1 sind stabil, daher arbeiten Server und Clients verschiedener 0.x-Versionen zusammen. Das Deinstallieren behält die Daten, außer mit `--purge`; Datastores außerhalb des Statusverzeichnisses werden nie gelöscht.
