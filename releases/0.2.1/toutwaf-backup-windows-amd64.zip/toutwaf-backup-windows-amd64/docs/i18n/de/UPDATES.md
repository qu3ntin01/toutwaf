[English](../en/UPDATES.md) | [Français](../fr/UPDATES.md) | [Español](../es/UPDATES.md) | **Deutsch** | [Italiano](../it/UPDATES.md) | [Português](../pt/UPDATES.md) | [Nederlands](../nl/UPDATES.md) | [Русский](../ru/UPDATES.md) | [中文](../zh/UPDATES.md) | [العربية](../ar/UPDATES.md)

# Updates

ToutWAF Backup sucht, prüft und installiert seine Updates selbst: der Befehl `toutwaf-backup update` (Server und Client, Linux und Windows), die Seite **Updates** der Weboberfläche und unter Linux ein täglicher Timer. Jede Version ist mit Ed25519 signiert, und jedes Archiv wird mit SHA-256 geprüft, bevor etwas ersetzt wird.

## Befehle

```sh
toutwaf-backup update status            # version, channel, whether an update is available, last check
toutwaf-backup update check             # look for an update; exit status 10 when there is one
toutwaf-backup update apply             # download, verify, install, restart the service, roll back if it does not stay up
toutwaf-backup update apply --version 0.2.1
toutwaf-backup update rollback          # put the previous version back (again: forward again)
toutwaf-backup update auto on|off       # the daily timer installs updates by itself, or only checks
toutwaf-backup update channel stable|dev
toutwaf-backup update ... --json        # machine-readable output, stable exit codes
toutwaf-backup update setup             # (root, once) the daily timer and the unit that serves the web interface
```

## Kanäle

`stable` enthält die getesteten Versionen, `dev` die Entwicklungsstände. Der Kanal wird aus `channel.json` des öffentlichen Branches gelesen; eine zurückgezogene (yanked) Version wird nie angeboten und ohne `--force` abgelehnt. Eine Version, die einen neueren Installer verlangt (`min_installer`), wird abgelehnt, mit der Aufforderung, `install.sh` erneut auszuführen. Das Programm geht nie stillschweigend auf eine ältere Version zurück.

Jeder Kanal hat auf dem öffentlichen Branch seine eigene Datei: `channels/stable.json` und `channels/dev.json` (Installer 3 und der Update-Manager lesen sie). `channel.json` im Stammverzeichnis ist der Zeiger des stabilen Kanals für ältere Installer. Ein Kanal, auf dem noch nichts veröffentlicht wurde, ist ein Fehler (Exit-Code 11), nie ein stiller Wechsel auf einen anderen Kanal.

## Was `update apply` tut

1. Liest `channel.json` und prüft, dass die Version nicht zurückgezogen ist und der Installer-Level verstanden wird.
2. Prüft die Ed25519-Signatur von `SHA256SUMS` mit dem im Programm eingebauten öffentlichen Schlüssel (vorher wird nichts vertraut).
3. Vergleicht das SHA-256 des Archivs mit der signierten Liste.
4. Ersetzt die ausführbare Datei atomar; die vorherige bleibt daneben als `toutwaf-backup.prev` (das nutzt `rollback`).
5. Startet den Server-Dienst (systemd) neu, wenn er läuft.
6. Prüft, dass der Dienst aktiv bleibt (20 s zum Starten, dann 4 s Stabilität); sonst wird die vorherige Datei zurückgelegt und der Dienst neu gestartet (Exit-Code 13).

## Exit-Codes

* `0`: erledigt oder bereits aktuell.
* `1`: Fehler (Kanal nicht erreichbar, Download fehlgeschlagen, Datei nicht schreibbar).
* `10`: `check` hat ein Update gefunden.
* `11`: abgelehnt (zurückgezogene Version oder Version, die einen neueren Installer braucht).
* `12`: falsche Signatur oder Prüfsumme: es wurde nichts installiert.
* `13`: die neue Version blieb nicht in Betrieb; die vorherige wurde wiederhergestellt.
* `14`: `rollback` hat keine vorherige Version.
* `64`: falsche Verwendung.

## Weboberfläche und API

Die Seite **Updates** (nur Administratoren, jede Aktion wird im Audit-Log festgehalten) zeigt die installierte Version, den Kanal, das verfügbare Update mit Hinweisen, die Schaltflächen Prüfen, Installieren und Zurückgehen, den Schalter für die automatische Installation und das Ergebnis des letzten Vorgangs. Die API: `GET /api/v1/system/update`, `POST /api/v1/system/update/check`, `POST /api/v1/system/update/apply`, `POST /api/v1/system/update/rollback` und `PUT /api/v1/system/update/settings`. Der Server läuft nicht als root (seine Unit verbietet Schreiben unter /usr) und kann sich daher nicht selbst ersetzen: Prüfen funktioniert direkt, Installieren, Zurückgehen und die Einstellungen sind Anfragen, die eine root-Unit ausführt. Installieren Sie diese Unit einmalig:

```sh
sudo toutwaf-backup update setup --state /var/lib/toutwaf-backup
```

`update setup` schreibt die Units `toutwaf-backup-update.timer` (tägliche Prüfung gegen 03:30 Uhr), `toutwaf-backup-update.service`, `toutwaf-backup-update.path` und `toutwaf-backup-update-request.service`. Ohne sie prüft die Seite trotzdem und nennt den auszuführenden Befehl.

## Einstellungsdateien

`/etc/toutwaf-backup/update.conf` (Kanal, automatische Installation, Ort der Releases) und `update.state` (letzte Prüfung und Ergebnis) sind genau die Dateien des Update-Managers des Installers, `toutwaf-backup-update`: beide Werkzeuge können auf derselben Maschine genutzt werden und sehen dieselben Einstellungen. `TOUTWAF_BACKUP_BASE_URL` oder `--base-url` verweist auf einen anderen Ort (https oder ein lokaler file://-Spiegel).

## Windows

Unter Windows lädt der Befehl `toutwaf-backup.exe` auf dieselbe Weise herunter, prüft und ersetzt es, startet den Dienst aber nicht neu: starten Sie ihn selbst neu (oder führen Sie den Installer erneut aus). Das Aktualisieren der Systempakete von `install.sh` gibt es nur unter Linux.
