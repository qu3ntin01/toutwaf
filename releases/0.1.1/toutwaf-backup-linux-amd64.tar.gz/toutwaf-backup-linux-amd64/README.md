# ToutWAF Backup

An independent backup system in one static binary: a **server** that stores deduplicated, compressed, client-side-encrypted backups (in the spirit of Proxmox Backup Server), a **client** that
backs up files, directories and database dumps, a **web interface**, and a documented **link to ToutWAF**. It installs on its own server, needs nothing from ToutWAF to work, and plugs into the ToutWAF
backup section later as a new engine, `toutwaf-backup`.

*(Résumé en français en bas de page. Pages in ten languages: [`docs/i18n/`](docs/i18n/README.md).)*

* **Your data is encrypted before it leaves your machine** (XChaCha20-Poly1305, key derived from your passphrase with Argon2id). The server never has the key and cannot read file names, contents or the tree.
* **Deduplication and compression**: content-defined chunks (FastCDC style, keyed), SHA-256 content addressing, zstd. A second backup of unchanged data sends nothing; a changed 256 KiB region of an 8 MiB file sends
  about one chunk. Across clients that share a key, the same data is stored once.
* **Ransomware-resistant**: writer tokens cannot read or delete; datastores and tokens can be *append-only* (switching it off needs the server machine itself); an immutability period; verification and scrub
  jobs; offsite copy by sync to a second server or disk; notifications when a backup is late or a check fails.
* **Complete client**: include/exclude, `--one-file-system`, fast incremental (change cache, resumes after an interruption), permissions, owners, extended attributes and POSIX ACLs, symlinks, hard links, sparse files,
  `mysqldump | toutwaf-backup client backup --stdin`, pre/post scripts, partial and verified restore, `ls`/`find`/`cat` of any snapshot without restoring, bandwidth limits, systemd timer or Windows task generation.
* **Quotas and limits**: per token and per namespace byte quotas (soft warning, hard refusal), snapshot and chunk counts, bandwidth caps; visible in the UI, the API and the CLI.
* **S3 backups, first class** (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO, any S3-compatible service): keep a datastore **in a bucket**, schedule an **offsite copy to S3** of any datastore (bandwidth cap, read-back
  verification), and **resume from S3** on a new server when the old one and its disk are lost. Keys typed in the web interface are kept 0600 on the server and never shown again; connection test (list, write, read, delete, Object Lock);
  optional Object Lock immutability and storage class; multipart upload, retries, rebuildable metadata mirror. See `docs/S3.md`.
* **Mount a snapshot** read-only on Linux (`client mount`, FUSE) and browse it with ordinary tools; on Windows use `ls`/`find`/`cat`/`restore`.
* **HTTPS/HTTP-2 API** with scoped tokens (admin, writer, reader, audit), pinned self-signed certificate, rate limiting, hash-chained audit log, Prometheus metrics, health endpoint.
* **Web interface in ten languages** (English, French, Spanish, German, Italian, Portuguese, Dutch, Russian, Chinese, Arabic with right-to-left layout; light and dark; keyboard and screen-reader friendly): datastores and usage, clients, snapshot browser with file download, jobs, verify/prune/GC, tokens, users, settings, audit. The command line (`--lang`, `LANG`), the installers and the notifications speak the same ten languages; JSON output, exit codes and error codes never change. The translations are machine-written and have not been reviewed by native speakers.

**Install policy.** ToutWAF Backup is optional. The **server runs on a different machine than ToutWAF** (the installers and `server run` refuse otherwise, in the language of the user); `--with-backup-client` on the ToutWAF side installs only the client.
Distribution: the `toutwaf-backup` branch of the public ToutWAF repository (signed with the same Ed25519 key as ToutWAF), see `docs/INSTALL-LINUX.md`.

Status: **0.1.1.** See `docs/TESTING.md` for exactly what was tested and what was not (notably: nothing was run on a real Windows machine). No third-party security audit.
The license is **not chosen yet** (`LICENSE` is a placeholder the owner must replace).

## Quick start

```sh
# on the backup server
sudo ./install.sh --role server --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start    # prints the admin token and the fingerprint
toutwaf-backup server token create --name web1 --role writer --datastore main --append-only

# on the machine to protect
sudo ./install.sh --role client
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --create-key   # prints the PAPER KEY: keep it safe
toutwaf-backup client backup --path /etc --path /var/www --id web1
toutwaf-backup client snapshots
toutwaf-backup client restore host/web1/latest --target /tmp/restore --verify
```
`toutwaf-backup --help` and `toutwaf-backup <command> --help` document every option.

## Documentation

| | |
|---|---|
| `docs/INSTALL-LINUX.md`, `docs/INSTALL-WINDOWS.md` | installation, first steps, upgrade, release layout, building |
| `docs/i18n/<lang>/` | README, installation, S3, restore, security summary and ToutWAF link in en fr es de it pt nl ru zh ar (machine-written, English documents are the reference) |
| `docs/S3.md` | **S3 object storage**: datastore in a bucket, offsite copy to S3, resume from S3, keys, Object Lock, API |
| `docs/RESTORE.md` | restore and **disaster-recovery runbook** (lost key, lost server, lost server with an S3 copy, damaged datastore, the drill) |
| `docs/ARCHITECTURE.md` | **repository format specification** (versioned), API reference |
| `docs/SECURITY.md` | threat model, what the server can and cannot see, key management |
| `docs/TOUTWAF-LINK.md` | the ToutWAF link contract and the engine contract (JSON events, exit codes) |
| `docs/PERFORMANCE.md` | measured throughput and deduplication, how to reproduce |
| `docs/TESTING.md` | what is tested, how, and what is not |
| `CHANGELOG.md`, `THIRD-PARTY-NOTICES.md`, `LICENSE` | |

## Layout of the repository

```
cmd/toutwaf-backup/        main
internal/format  crypto  cdc  catalog  store  retention  cron    the format and the engine (no network)
internal/api  remote  server  client  cli  ui  s3  mountfs                         API types, HTTP client, server, client, command line, embedded web UI
internal/e2e               end-to-end tests (real servers and clients), performance report
deploy/                    install.sh, install.ps1, systemd units       tools/   build-release.sh, smoke.sh, test-installer.sh, e2e-ui (browser), fake-s3, demo-seed
docs/  third_party/licenses/  .gitlab-ci.yml
```
Dependencies (all BSD-3-Clause, no cgo): `klauspost/compress` (zstd), `golang.org/x/crypto`, `golang.org/x/sys`, `golang.org/x/term`, `hanwen/go-fuse` (Linux mount only; `-tags nofuse` leaves it out). The S3 client is standard library only. No database engine.

## Résumé (français)

ToutWAF Backup est un outil de sauvegarde **indépendant** (un seul binaire statique) : un serveur qui stocke des sauvegardes dédupliquées, compressées et **chiffrées côté client** (le serveur n'a jamais la clé),
un client (fichiers, répertoires, dumps de bases de données, restauration partielle ou complète vérifiée, `ls`/`find`/`cat` sans restaurer), une interface web en dix langues (en fr es de it pt nl ru zh ar), des jetons à rôles (admin, écrivain, lecteur, audit),
le mode *ajout seul* (un client compromis ne peut pas supprimer les sauvegardes), la vérification et la copie hors site, les alertes par courriel et webhook, et une **liaison documentée avec ToutWAF**
(`docs/TOUTWAF-LINK.md`) pour s'y brancher comme moteur `toutwaf-backup`. Installation : `install.sh --role server|client` (Linux, testé) ou `install.ps1` (Windows, **non testé sur une vraie machine Windows**).
**Gardez la clé, la phrase secrète et la clé papier hors de la machine sauvegardée** : sans elles, aucune restauration n'est possible, par personne. Procédure de reprise après sinistre : `docs/RESTORE.md`.
La licence reste à choisir par le propriétaire.
Politique d'installation : ToutWAF Backup est **optionnel** ; le **serveur doit tourner sur une autre machine que ToutWAF** (l'installateur et `server run` refusent sinon, avec un message dans la langue de l'utilisateur) ; l'option `--with-backup-client` de ToutWAF n'installe que le client.
Nouveautés de cette version : quotas par jeton et par espace de noms (alerte douce, refus dur, nombre de sauvegardes, débit), **sauvegarde S3** de première classe (AWS, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO : datastore dans un bucket, copie hors site vers S3 planifiée, reprise depuis S3 sur un nouveau serveur ; clés saisies dans l'interface, gardées en 0600 sur le serveur, jamais réaffichées ; test de connexion ; Object Lock ; `docs/S3.md`), montage en lecture seule d'un instantané sous Linux (`client mount`, FUSE ; sous Windows : `ls`/`find`/`cat`/`restore`).
