[English](../en/README.md) | [Français](../fr/README.md) | [Español](../es/README.md) | [Deutsch](../de/README.md) | [Italiano](../it/README.md) | [Português](../pt/README.md) | [Nederlands](../nl/README.md) | [Русский](../ru/README.md) | **中文** | [العربية](../ar/README.md)

# ToutWAF Backup

一个独立的备份系统，只有一个静态可执行文件：**服务器**存储经过去重、压缩并在客户端加密的备份；**客户端**备份文件、目录和数据库转储；还有**网页界面**，以及有文档说明的**与 ToutWAF 的关联**。它安装在自己的服务器上，运行不依赖 ToutWAF 的任何部分。

* **数据在离开您的机器之前就已加密**（XChaCha20-Poly1305，密钥由您的口令经 Argon2id 派生）。服务器从不持有密钥，无法读取文件名、内容或目录结构。
* **去重与压缩**：按内容划分数据块，SHA-256 内容寻址，zstd。对未变化的数据再次备份不会发送任何内容；共享同一密钥的多个客户端，相同数据只存储一份。
* **抵御勒索软件**：写入令牌既不能读取也不能删除；数据存储和令牌可设为*仅追加*（要关闭必须在服务器本机操作）；不可变期；验证与 scrub 作业；异地副本；备份延迟或检查失败时发送通知。
* **功能完整的客户端**：包含与排除规则、快速增量备份、权限、所有者、扩展属性和 ACL、`mysqldump | toutwaf-backup client backup --stdin`、前置与后置脚本、部分且经过验证的恢复、无需恢复即可对任意快照执行 `ls`、`find` 和 `cat`、带宽限制、生成 systemd 定时器或 Windows 任务。
* **配额与限制**：按令牌和按命名空间的字节配额（软性告警、硬性拒绝）、快照和数据块数量、带宽上限；在界面、API 和命令行中均可见。
* **S3 备份是一等功能**（AWS S3、Backblaze B2、Wasabi、Scaleway、OVH、Cloudflare R2、MinIO 以及任何兼容 S3 的服务）：把数据存储**放在存储桶中**，为任何数据存储安排**到 S3 的异地副本**（带宽上限、回读验证），旧服务器丢失时在新服务器上**从 S3 恢复**。在界面中输入的密钥保存在服务器上，不会再次显示；支持连接测试；可选 Object Lock。参见 `S3.md`。
* 在 Linux 上以只读方式**挂载快照**（`client mount`，FUSE），用常规工具浏览；在 Windows 上使用 `ls`、`find`、`cat` 和 `restore`。
* **HTTPS 与 HTTP/2 API**：带作用域的令牌（admin、writer、reader、audit）、固定的自签名证书、速率限制、哈希链审计日志、Prometheus 指标和健康检查端点。
* **十种语言的网页界面**（英语、法语、西班牙语、德语、意大利语、葡萄牙语、荷兰语、俄语、中文、阿拉伯语并支持从右到左排版），浅色与深色主题，支持键盘与读屏软件：数据存储与用量、客户端、可下载文件的快照浏览器、作业、验证、清理与垃圾回收、令牌、用户、设置、审计。命令行、安装程序和通知使用同样的十种语言。

**安装策略。** ToutWAF Backup 是可选的。**服务器必须运行在与 ToutWAF 不同的机器上**（否则安装程序和 `server run` 会拒绝）：存放在被保护机器本身的备份，无法在该机器丢失时幸存。ToutWAF 一侧的 `--with-backup-client` 只安装客户端。发布版使用与 ToutWAF 相同的 Ed25519 密钥签名，发布在 ToutWAF 公共仓库的 `toutwaf-backup` 分支上。

**状态：版本 0.1.1。** 所有内容都在 Linux 上测试过；没有在真实的 Windows 机器上运行过；S3 是针对进程内模拟服务测试的，而不是针对真实提供商（参见英文文档中的 `TESTING.md`）。未经第三方安全审计。许可证尚未确定。

## 快速开始

```sh
# on the backup server
sudo ./install.sh --role server --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start
toutwaf-backup server token create --name web1 --role writer --datastore main --append-only

# on the machine to protect
sudo ./install.sh --role client
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --create-key
toutwaf-backup client backup --path /etc --path /var/www --id web1
toutwaf-backup client snapshots
toutwaf-backup client restore host/web1/latest --target /tmp/restore --verify
```

`toutwaf-backup --help` 和 `toutwaf-backup <命令> --help` 会以您系统的语言（或 `--lang fr`、`--lang es` ...）说明每个选项。

## 文档

| 页面 | 内容 |
|---|---|
| [INSTALL.md](INSTALL.md) | 在 Linux 和 Windows 上安装、初次使用、升级 |
| [S3.md](S3.md) | S3 对象存储：存储桶中的数据存储、异地副本、恢复、密钥、Object Lock |
| [RESTORE.md](RESTORE.md) | 恢复与灾难恢复手册、演练 |
| [SECURITY.md](SECURITY.md) | 服务器能看到什么、不能看到什么，威胁模型，密钥 |
| [TOUTWAF-LINK.md](TOUTWAF-LINK.md) | 与 ToutWAF 控制台配对，为每台机器选择本地或 S3 数据存储 |
| [英文文档](../../) | 完整参考：仓库格式、API、性能、测试 |

## 语言

这些页面提供十种语言版本。译文由机器撰写，**未经母语人士审校**：如果某句话读起来别扭或细节不一致，请以 `docs/` 中的英文文档为准。欢迎提出更正。
