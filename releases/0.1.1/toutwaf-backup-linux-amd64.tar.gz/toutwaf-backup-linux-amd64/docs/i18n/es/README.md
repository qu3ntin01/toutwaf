[English](../en/README.md) | [Français](../fr/README.md) | **Español** | [Deutsch](../de/README.md) | [Italiano](../it/README.md) | [Português](../pt/README.md) | [Nederlands](../nl/README.md) | [Русский](../ru/README.md) | [中文](../zh/README.md) | [العربية](../ar/README.md)

# ToutWAF Backup

Un sistema de copias de seguridad independiente en un único binario estático: un **servidor** que almacena copias deduplicadas, comprimidas y cifradas en el cliente, un **cliente** que copia archivos, directorios y volcados de bases de datos, una **interfaz web** y un **enlace documentado con ToutWAF**. Se instala en su propio servidor y no necesita nada de ToutWAF para funcionar.

* **Sus datos se cifran antes de salir de su máquina** (XChaCha20-Poly1305, clave derivada de su frase de contraseña con Argon2id). El servidor nunca tiene la clave y no puede leer nombres de archivo, contenidos ni el árbol.
* **Deduplicación y compresión**: fragmentos delimitados por el contenido, direccionamiento por SHA-256, zstd. Una segunda copia de datos sin cambios no envía nada; entre clientes que comparten una clave, el mismo dato se almacena una sola vez.
* **Resistente al ransomware**: los tokens de escritura no pueden leer ni borrar; los datastores y los tokens pueden ser de *solo añadir* (desactivarlo exige la propia máquina del servidor); un periodo de inmutabilidad; tareas de verificación y de scrub; copias externas; notificaciones cuando una copia se retrasa o falla una comprobación.
* **Cliente completo**: reglas de inclusión y exclusión, incremental rápido, permisos, propietarios, atributos extendidos y ACL, `mysqldump | toutwaf-backup client backup --stdin`, scripts previos y posteriores, restauración parcial y verificada, `ls`, `find` y `cat` de cualquier instantánea sin restaurar, límites de ancho de banda, generación de temporizador systemd o tarea de Windows.
* **Cuotas y límites**: cuotas de bytes por token y por espacio de nombres (aviso flexible, rechazo estricto), número de instantáneas y de fragmentos, límites de ancho de banda; visibles en la interfaz, la API y la línea de comandos.
* **Copias en S3, de primera clase** (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO, cualquier servicio compatible con S3): mantener un datastore **en un bucket**, programar una **copia externa a S3** de cualquier datastore (límite de ancho de banda, verificación por relectura) y **reanudar desde S3** en un servidor nuevo cuando el anterior se pierde. Las claves escritas en la interfaz se guardan en el servidor y no se vuelven a mostrar; prueba de conexión; Object Lock opcional. Véase `S3.md`.
* **Montar una instantánea** en solo lectura en Linux (`client mount`, FUSE) y explorarla con las herramientas habituales; en Windows use `ls`, `find`, `cat` y `restore`.
* **API HTTPS y HTTP/2** con tokens de ámbito limitado (admin, escritor, lector, auditoría), certificado autofirmado fijado, limitación de peticiones, registro de auditoría encadenado por hash, métricas Prometheus, punto de salud.
* **Interfaz web en diez idiomas** (inglés, francés, español, alemán, italiano, portugués, neerlandés, ruso, chino, árabe con diseño de derecha a izquierda), clara y oscura, utilizable con teclado y lector de pantalla: datastores y uso, clientes, explorador de instantáneas con descarga de archivos, tareas, verificación, depuración y liberación de espacio, tokens, usuarios, ajustes, auditoría. La línea de comandos, los instaladores y las notificaciones hablan los mismos diez idiomas.

**Política de instalación.** ToutWAF Backup es opcional. El **servidor se ejecuta en una máquina distinta de la de ToutWAF** (los instaladores y `server run` lo rechazan en caso contrario): una copia guardada en la máquina que protege no sobrevive a la pérdida de esa máquina. La opción `--with-backup-client` del lado de ToutWAF instala solo el cliente. Las versiones se firman con la misma clave Ed25519 que ToutWAF y se publican en la rama `toutwaf-backup` del repositorio público de ToutWAF.

**Estado: versión 0.1.1.** Todo se probó en Linux; nada se ejecutó en una máquina Windows real, y S3 se probó contra un S3 simulado en memoria, no contra un proveedor real (véase `TESTING.md` en la documentación en inglés). Sin auditoría de seguridad de terceros. La licencia aún no está elegida.

## Inicio rápido

```sh
# on the backup server
sudo ./install.sh --role server --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start
toutwaf-backup server token create --name web1 --role writer --datastore main --append-only

# on the machine to protect
sudo ./install.sh --role client
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --create-key
toutwaf-backup client backup --path /etc --path /var/www --id web1
toutwaf-backup client snapshots
toutwaf-backup client restore host/web1/latest --target /tmp/restore --verify
```

`toutwaf-backup --help` y `toutwaf-backup <comando> --help` documentan cada opción, en el idioma de su sistema (o `--lang fr`, `--lang es` ...).

## Documentación

| Página | Contenido |
|---|---|
| [INSTALL.md](INSTALL.md) | instalación en Linux y Windows, primeros pasos, actualización |
| [S3.md](S3.md) | almacenamiento de objetos S3: datastore en un bucket, copia externa, reanudación, claves, Object Lock |
| [RESTORE.md](RESTORE.md) | restauración y procedimiento de recuperación ante desastres, el simulacro |
| [SECURITY.md](SECURITY.md) | lo que el servidor puede y no puede ver, modelo de amenazas, claves |
| [TOUTWAF-LINK.md](TOUTWAF-LINK.md) | emparejamiento con una consola ToutWAF, datastore local o S3 por máquina |
| [Documentación en inglés](../../) | la referencia completa: formato del repositorio, API, rendimiento, pruebas |

## Idiomas

Estas páginas existen en diez idiomas. Las traducciones las ha escrito una máquina y **no las han revisado hablantes nativos**: si una frase suena rara o un detalle difiere, la documentación en inglés de `docs/` es la referencia. Se agradecen las correcciones.
