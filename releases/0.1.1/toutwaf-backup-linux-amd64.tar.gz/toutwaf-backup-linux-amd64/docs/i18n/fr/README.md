[English](../en/README.md) | **Français** | [Español](../es/README.md) | [Deutsch](../de/README.md) | [Italiano](../it/README.md) | [Português](../pt/README.md) | [Nederlands](../nl/README.md) | [Русский](../ru/README.md) | [中文](../zh/README.md) | [العربية](../ar/README.md)

# ToutWAF Backup

Un système de sauvegarde indépendant dans un seul binaire statique : un **serveur** qui stocke des sauvegardes dédupliquées, compressées et chiffrées côté client, un **client** qui sauvegarde fichiers, répertoires et dumps de bases de données, une **interface web**, et une **liaison documentée avec ToutWAF**. Il s'installe sur son propre serveur et n'a besoin de rien de ToutWAF pour fonctionner.

* **Vos données sont chiffrées avant de quitter votre machine** (XChaCha20-Poly1305, clé dérivée de votre phrase secrète avec Argon2id). Le serveur n'a jamais la clé et ne peut lire ni les noms de fichiers, ni les contenus, ni l'arborescence.
* **Déduplication et compression** : fragments délimités par le contenu, adressage par SHA-256, zstd. Une deuxième sauvegarde de données inchangées n'envoie rien ; entre clients qui partagent une clé, une même donnée n'est stockée qu'une fois.
* **Résistant aux rançongiciels** : les jetons d'écriture ne peuvent ni lire ni supprimer ; les datastores et les jetons peuvent être en *ajout seul* (le désactiver exige la machine du serveur elle-même) ; une période d'immuabilité ; des tâches de vérification et de scrub ; des copies hors site ; des notifications quand une sauvegarde est en retard ou qu'un contrôle échoue.
* **Client complet** : règles d'inclusion et d'exclusion, incrémental rapide, permissions, propriétaires, attributs étendus et ACL, `mysqldump | toutwaf-backup client backup --stdin`, scripts avant et après, restauration partielle et vérifiée, `ls`, `find` et `cat` de n'importe quel instantané sans restaurer, limites de débit, génération de minuteur systemd ou de tâche Windows.
* **Quotas et limites** : quotas d'octets par jeton et par espace de noms (alerte douce, refus dur), nombre d'instantanés et de fragments, plafonds de débit ; visibles dans l'interface, l'API et la ligne de commande.
* **Sauvegarde S3 de première classe** (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO, tout service compatible S3) : garder un datastore **dans un bucket**, planifier une **copie hors site vers S3** de n'importe quel datastore (plafond de débit, vérification par relecture), et **reprendre depuis S3** sur un nouveau serveur quand l'ancien est perdu. Les clés saisies dans l'interface sont gardées sur le serveur et jamais réaffichées ; test de connexion ; Object Lock optionnel. Voir `S3.md`.
* **Monter un instantané** en lecture seule sous Linux (`client mount`, FUSE) et le parcourir avec les outils habituels ; sous Windows, utilisez `ls`, `find`, `cat` et `restore`.
* **API HTTPS et HTTP/2** avec jetons à portée limitée (admin, écrivain, lecteur, audit), certificat autosigné épinglé, limitation de débit des requêtes, journal d'audit chaîné par hachage, métriques Prometheus, point de santé.
* **Interface web en dix langues** (anglais, français, espagnol, allemand, italien, portugais, néerlandais, russe, chinois, arabe avec mise en page de droite à gauche), clair et sombre, utilisable au clavier et avec un lecteur d'écran : datastores et utilisation, clients, navigateur d'instantanés avec téléchargement de fichiers, tâches, vérification, élagage et libération d'espace, jetons, utilisateurs, paramètres, audit. La ligne de commande, les installeurs et les notifications parlent les mêmes dix langues.

**Politique d'installation.** ToutWAF Backup est optionnel. Le **serveur tourne sur une autre machine que ToutWAF** (les installeurs et `server run` refusent sinon) : une sauvegarde stockée sur la machine qu'elle protège ne survit pas à la perte de cette machine. L'option `--with-backup-client` côté ToutWAF n'installe que le client. Les versions sont signées avec la même clé Ed25519 que ToutWAF et publiées sur la branche `toutwaf-backup` du dépôt public de ToutWAF.

**État : version 0.1.1.** Tout a été testé sous Linux ; rien n'a été exécuté sur une vraie machine Windows, et S3 a été testé contre un faux S3 en mémoire, pas contre un vrai fournisseur (voir `TESTING.md` dans la documentation anglaise). Aucun audit de sécurité par un tiers. La licence n'est pas encore choisie.

## Démarrage rapide

```sh
# on the backup server
sudo ./install.sh --role server --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start
toutwaf-backup server token create --name web1 --role writer --datastore main --append-only

# on the machine to protect
sudo ./install.sh --role client
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --create-key
toutwaf-backup client backup --path /etc --path /var/www --id web1
toutwaf-backup client snapshots
toutwaf-backup client restore host/web1/latest --target /tmp/restore --verify
```

`toutwaf-backup --help` et `toutwaf-backup <commande> --help` documentent chaque option, dans la langue de votre système (ou `--lang fr`, `--lang es` ...).

## Documentation

| Page | Contenu |
|---|---|
| [INSTALL.md](INSTALL.md) | installation sous Linux et Windows, premiers pas, mise à jour |
| [S3.md](S3.md) | stockage objet S3 : datastore dans un bucket, copie hors site, reprise, clés, Object Lock |
| [RESTORE.md](RESTORE.md) | restauration et procédure de reprise après sinistre, l'exercice |
| [SECURITY.md](SECURITY.md) | ce que le serveur peut et ne peut pas voir, modèle de menaces, clés |
| [TOUTWAF-LINK.md](TOUTWAF-LINK.md) | appairage avec une console ToutWAF, datastore local ou S3 par machine |
| [Documentation anglaise](../../) | la référence complète : format du dépôt, API, performances, tests |

## Langues

Ces pages existent en dix langues. Les traductions ont été rédigées par une machine et **n'ont pas été relues par des locuteurs natifs** : si une phrase paraît étrange ou si un détail diffère, la documentation anglaise de `docs/` fait foi. Les corrections sont les bienvenues.
