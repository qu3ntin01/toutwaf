**English** | [Français](../fr/README.md) | [Español](../es/README.md) | [Deutsch](../de/README.md) | [Italiano](../it/README.md) | [Português](../pt/README.md) | [Nederlands](../nl/README.md) | [Русский](../ru/README.md) | [中文](../zh/README.md) | [العربية](../ar/README.md)

# ToutWAF Backup

An independent backup system in one static binary: a **server** that stores deduplicated, compressed, client-side-encrypted backups, a **client** that backs up files, directories and database dumps, a **web interface**, and a documented **link to ToutWAF**. It installs on its own server and needs nothing from ToutWAF to work.

* **Your data is encrypted before it leaves your machine** (XChaCha20-Poly1305, key derived from your passphrase with Argon2id). The server never has the key and cannot read file names, contents or the tree.
* **Deduplication and compression**: content-defined chunks, SHA-256 content addressing, zstd. A second backup of unchanged data sends nothing; across clients that share a key, the same data is stored once.
* **Ransomware-resistant**: writer tokens cannot read or delete; datastores and tokens can be *append-only* (switching it off needs the server machine itself); an immutability period; verification and scrub jobs; offsite copies; notifications when a backup is late or a check fails.
* **Complete client**: include and exclude rules, fast incremental backups, permissions, owners, extended attributes and ACLs, `mysqldump | toutwaf-backup client backup --stdin`, pre and post scripts, partial and verified restore, `ls`, `find` and `cat` of any snapshot without restoring, bandwidth limits, systemd timer or Windows task generation.
* **Quotas and limits**: per token and per namespace byte quotas (soft warning, hard refusal), snapshot and chunk counts, bandwidth caps; visible in the interface, the API and the command line.
* **S3 backups, first class** (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO, any S3-compatible service): keep a datastore **in a bucket**, schedule an **offsite copy to S3** of any datastore (bandwidth cap, read-back verification), and **resume from S3** on a new server when the old one is lost. Keys typed in the interface are stored on the server and never shown again; connection test; optional Object Lock. See `S3.md`.
* **Mount a snapshot** read-only on Linux (`client mount`, FUSE) and browse it with ordinary tools; on Windows use `ls`, `find`, `cat` and `restore`.
* **HTTPS and HTTP/2 API** with scoped tokens (admin, writer, reader, audit), pinned self-signed certificate, rate limiting, hash-chained audit log, Prometheus metrics, health endpoint.
* **Web interface in ten languages** (English, French, Spanish, German, Italian, Portuguese, Dutch, Russian, Chinese, Arabic with right-to-left layout), light and dark, keyboard and screen-reader friendly: datastores and usage, clients, snapshot browser with file download, jobs, verify, prune and garbage collection, tokens, users, settings, audit. The command line, the installers and the notifications speak the same ten languages.

**Install policy.** ToutWAF Backup is optional. The **server runs on a different machine than ToutWAF** (the installers and `server run` refuse otherwise): a backup stored on the machine it protects does not survive the loss of that machine. `--with-backup-client` on the ToutWAF side installs only the client. Releases are signed with the same Ed25519 key as ToutWAF and published on the `toutwaf-backup` branch of the public ToutWAF repository.

**Status: version 0.1.1.** Everything was tested on Linux; nothing was run on a real Windows machine, and S3 was tested against an in-process fake, not against a real provider (see `TESTING.md` in the English documentation). No third-party security audit. The license is not chosen yet.

## Quick start

```sh
# on the backup server
sudo ./install.sh --role server --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start
toutwaf-backup server token create --name web1 --role writer --datastore main --append-only

# on the machine to protect
sudo ./install.sh --role client
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --create-key
toutwaf-backup client backup --path /etc --path /var/www --id web1
toutwaf-backup client snapshots
toutwaf-backup client restore host/web1/latest --target /tmp/restore --verify
```

`toutwaf-backup --help` and `toutwaf-backup <command> --help` document every option, in the language of your system (or `--lang fr`, `--lang es` ...).

## Documentation

| Page | Content |
|---|---|
| [INSTALL.md](INSTALL.md) | installation on Linux and Windows, first steps, upgrade |
| [S3.md](S3.md) | S3 object storage: datastore in a bucket, offsite copy, resume, keys, Object Lock |
| [RESTORE.md](RESTORE.md) | restore and disaster-recovery runbook, the drill |
| [SECURITY.md](SECURITY.md) | what the server can and cannot see, threat model, keys |
| [TOUTWAF-LINK.md](TOUTWAF-LINK.md) | pairing with a ToutWAF console, local or S3 datastore per machine |
| [English documentation](../../) | the complete reference: repository format, API, performance, tests |

## Languages

These pages exist in ten languages. The translations were written by a machine and have **not been reviewed by native speakers**: if a sentence reads oddly or a detail differs, the English documentation in `docs/` is the reference. Corrections are welcome.
