[English](../en/README.md) | [Français](../fr/README.md) | [Español](../es/README.md) | **Deutsch** | [Italiano](../it/README.md) | [Português](../pt/README.md) | [Nederlands](../nl/README.md) | [Русский](../ru/README.md) | [中文](../zh/README.md) | [العربية](../ar/README.md)

# ToutWAF Backup

Ein unabhängiges Backup-System in einer einzigen statischen Programmdatei: ein **Server**, der deduplizierte, komprimierte, clientseitig verschlüsselte Sicherungen speichert, ein **Client**, der Dateien, Verzeichnisse und Datenbank-Dumps sichert, eine **Weboberfläche** und eine dokumentierte **Anbindung an ToutWAF**. Es wird auf einem eigenen Server installiert und braucht nichts von ToutWAF, um zu funktionieren.

* **Ihre Daten werden verschlüsselt, bevor sie Ihren Rechner verlassen** (XChaCha20-Poly1305, aus Ihrer Passphrase mit Argon2id abgeleiteter Schlüssel). Der Server hat den Schlüssel nie und kann weder Dateinamen noch Inhalte noch die Verzeichnisstruktur lesen.
* **Deduplizierung und Kompression**: inhaltsbasierte Chunks, SHA-256-Adressierung, zstd. Eine zweite Sicherung unveränderter Daten sendet nichts; zwischen Clients mit gemeinsamem Schlüssel wird dieselbe Datenmenge nur einmal gespeichert.
* **Ransomware-resistent**: Schreib-Tokens können weder lesen noch löschen; Datastores und Tokens können *nur anhängen* (zum Abschalten braucht es den Server-Rechner selbst); eine Unveränderlichkeitsfrist; Prüf- und Scrub-Aufträge; externe Kopien; Benachrichtigungen, wenn eine Sicherung überfällig ist oder eine Prüfung fehlschlägt.
* **Vollständiger Client**: Ein- und Ausschlussregeln, schnelle inkrementelle Sicherung, Berechtigungen, Besitzer, erweiterte Attribute und ACLs, `mysqldump | toutwaf-backup client backup --stdin`, Vor- und Nachskripte, teilweise und geprüfte Wiederherstellung, `ls`, `find` und `cat` für jeden Snapshot ohne Wiederherstellung, Bandbreitenlimits, Erzeugung von systemd-Timern oder Windows-Aufgaben.
* **Kontingente und Limits**: Byte-Kontingente pro Token und pro Namensraum (weiche Warnung, harte Ablehnung), Anzahl von Snapshots und Chunks, Bandbreitenlimits; sichtbar in der Oberfläche, in der API und auf der Kommandozeile.
* **S3-Sicherungen als vollwertige Funktion** (AWS S3, Backblaze B2, Wasabi, Scaleway, OVH, Cloudflare R2, MinIO, jeder S3-kompatible Dienst): einen Datastore **in einem Bucket** halten, eine **externe Kopie nach S3** für jeden Datastore planen (Bandbreitenlimit, Prüfung durch Zurücklesen) und auf einem neuen Server **aus S3 fortsetzen**, wenn der alte verloren ist. In der Oberfläche eingegebene Schlüssel bleiben auf dem Server und werden nie wieder angezeigt; Verbindungstest; optional Object Lock. Siehe `S3.md`.
* **Einen Snapshot schreibgeschützt einbinden** unter Linux (`client mount`, FUSE) und mit gewohnten Werkzeugen durchsuchen; unter Windows `ls`, `find`, `cat` und `restore` verwenden.
* **HTTPS- und HTTP/2-API** mit eingeschränkten Tokens (admin, writer, reader, audit), gepinntem selbstsigniertem Zertifikat, Ratenbegrenzung, hashverkettetem Audit-Protokoll, Prometheus-Metriken und Health-Endpunkt.
* **Weboberfläche in zehn Sprachen** (Englisch, Französisch, Spanisch, Deutsch, Italienisch, Portugiesisch, Niederländisch, Russisch, Chinesisch, Arabisch mit Rechts-nach-links-Layout), hell und dunkel, per Tastatur und Screenreader bedienbar: Datastores und Nutzung, Clients, Snapshot-Browser mit Dateidownload, Aufträge, Prüfung, Bereinigung und Speicherbereinigung, Tokens, Benutzer, Einstellungen, Audit. Kommandozeile, Installer und Benachrichtigungen sprechen dieselben zehn Sprachen.

**Installationsrichtlinie.** ToutWAF Backup ist optional. Der **Server läuft auf einem anderen Rechner als ToutWAF** (die Installer und `server run` lehnen es sonst ab): Eine Sicherung auf dem Rechner, den sie schützt, übersteht dessen Verlust nicht. `--with-backup-client` auf der ToutWAF-Seite installiert nur den Client. Releases sind mit demselben Ed25519-Schlüssel wie ToutWAF signiert und im Branch `toutwaf-backup` des öffentlichen ToutWAF-Repositorys veröffentlicht.

**Stand: Version 0.1.1.** Alles wurde unter Linux getestet; nichts lief auf einem echten Windows-Rechner, und S3 wurde gegen eine In-Process-Attrappe getestet, nicht gegen einen echten Anbieter (siehe `TESTING.md` in der englischen Dokumentation). Kein Sicherheitsaudit durch Dritte. Die Lizenz ist noch nicht gewählt.

## Schnellstart

```sh
# on the backup server
sudo ./install.sh --role server --external-url https://backup.example.net:8007 --datastore main=/srv/backups/main --start
toutwaf-backup server token create --name web1 --role writer --datastore main --append-only

# on the machine to protect
sudo ./install.sh --role client
toutwaf-backup client init --server https://backup.example.net:8007 --tofu --token twb_... --datastore main --create-key
toutwaf-backup client backup --path /etc --path /var/www --id web1
toutwaf-backup client snapshots
toutwaf-backup client restore host/web1/latest --target /tmp/restore --verify
```

`toutwaf-backup --help` und `toutwaf-backup <Befehl> --help` dokumentieren jede Option, in der Sprache Ihres Systems (oder `--lang fr`, `--lang es` ...).

## Dokumentation

| Seite | Inhalt |
|---|---|
| [INSTALL.md](INSTALL.md) | Installation unter Linux und Windows, erste Schritte, Aktualisierung |
| [S3.md](S3.md) | S3-Objektspeicher: Datastore im Bucket, externe Kopie, Fortsetzung, Schlüssel, Object Lock |
| [RESTORE.md](RESTORE.md) | Wiederherstellung und Notfallplan, die Übung |
| [SECURITY.md](SECURITY.md) | was der Server sehen kann und was nicht, Bedrohungsmodell, Schlüssel |
| [TOUTWAF-LINK.md](TOUTWAF-LINK.md) | Kopplung mit einer ToutWAF-Konsole, lokaler oder S3-Datastore pro Rechner |
| [Englische Dokumentation](../../) | die vollständige Referenz: Repository-Format, API, Leistung, Tests |

## Sprachen

Diese Seiten gibt es in zehn Sprachen. Die Übersetzungen wurden maschinell erstellt und **nicht von Muttersprachlern geprüft**: Wirkt ein Satz seltsam oder weicht ein Detail ab, gilt die englische Dokumentation in `docs/`. Korrekturen sind willkommen.
